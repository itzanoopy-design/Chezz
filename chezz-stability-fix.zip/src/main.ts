import { Chess, type Square, type Move } from 'chess.js';
import './styles.css';

const app = document.querySelector<HTMLDivElement>('#app');
if (!app) throw new Error('CHEZZ app root not found');

const game = new Chess();
const files = 'abcdefgh';
type DetailLevel = 'realistic' | 'extreme' | 'super' | 'very' | 'detailed' | 'normal' | 'simplified';
const detailLevels: Array<{ id: DetailLevel; label: string; hint: string }> = [
  { id: 'realistic', label: 'Realistic', hint: 'Sculpted chessmen with polished highlights, deep shadows, and a warm wood board option' },
  { id: 'extreme', label: 'Extreme Detailed', hint: 'Maximum 2D depth, layered lighting, glossy highlights and dramatic shadows' },
  { id: 'super', label: 'Super Detailed', hint: 'Maximum ornament and shine' },
  { id: 'very', label: 'Very Detailed', hint: 'Extra carved accents' },
  { id: 'detailed', label: 'Detailed', hint: 'Rich default look' },
  { id: 'normal', label: 'Normal', hint: 'Clean classic pieces' },
  { id: 'simplified', label: 'Simplified', hint: 'Lightweight for low-end devices' },
];
function readDetailSetting(key: string, fallback: DetailLevel): DetailLevel {
  try {
    const value = localStorage.getItem(key);
    return detailLevels.some(level => level.id === value) ? value as DetailLevel : fallback;
  } catch {
    return fallback;
  }
}
let pieceDetail = readDetailSetting('chezz-piece-detail', 'detailed');
let boardDetail = readDetailSetting('chezz-board-detail', 'detailed');
let showHomeScreen = true;
let showMatchHistory = false;
type SavedMatch = { id: string; pgn: string; mode: GameMode; bot: string; playerColor: 'w' | 'b'; result: string; moves: number; createdAt: number };
function loadMatchHistory(): SavedMatch[] { try { const value = JSON.parse(localStorage.getItem('chezz-match-history') ?? '[]') as unknown; return Array.isArray(value) ? value.filter((item): item is SavedMatch => Boolean(item && typeof item.id === 'string' && typeof item.pgn === 'string' && typeof item.createdAt === 'number')).slice(0, 30) : []; } catch { return []; } }
let matchHistory: SavedMatch[] = loadMatchHistory();
let matchSavedForCurrentGame = false;
let showAllHomeBots = false;
let showColorChoice = false;
let colorChoiceBot: BotId = 'rookie';
let coinFlipBusy = false;
let playerColor: 'w' | 'b' = 'w';
let resumeAvailable = (() => { try { return Boolean(localStorage.getItem('chezz-active-game')); } catch { return false; } })();
let showMoveReplicator = false;
let replicatorGame = new Chess();
let replicatorSelected: Square | null = null;
let replicatorSideToMove: 'w' | 'b' = 'w';
let replicatorTool: 'move' | 'place' | 'erase' = 'move';
let replicatorPiece = 'wP';
let replicatorError = '';
let replicatorFocusBoard = false;
let boardFullscreenOnly = false;
let replicatorSuggestion: { from: Square; to: Square; san: string; reason: string; score: number; line: string[]; depth: number; nodes: number } | null = null;
let replicatorMovesInput = '';
let activeGame: 'chess' | 'checkers' | 'tictactoe' | 'connect4' = 'chess';
type CheckerMode = 'bot' | 'local';
let checkerMode: CheckerMode = 'bot';
let checkerTurn: 'w' | 'b' = 'w';
let checkerSelected: number | null = null;
let checkerChainSquare: number | null = null;
let checkerNote = 'Choose a move for Red. Captures are mandatory.';
let checkerHint: { from: number; to: number; score: number; depth: number; line: string } | null = null;
let checkerBotId = 'tactician';
let checkerBoard: Array<string | null> = [];
let checkerLastMove: { from: number; to: number } | null = null;
let checkerReplayFrames: Array<Array<string | null>> = [];
let checkerReplayBoard: Array<string | null> | null = null;
let checkerReplayIndex = 0;
let checkerReplayTimer: number | null = null;
let checkerReplayPaused = false;
let checkerThinking = false;
let chessReplayActive = false;
let chessReplayPaused = false;
let chessReplayMoves: string[] = [];
let chessReplayIndex = 0;
let chessReplayTimer: number | null = null;
const checkerBots = [
  { id: 'rookie', name: 'Rookie', tier: 'Beginner', style: 'Forgiving moves while you learn the basics', icon: '🌱' },
  { id: 'trickster', name: 'Trickster', tier: 'Casual', style: 'Unpredictable choices and occasional mistakes', icon: '🌀' },
  { id: 'scout', name: 'Scout', tier: 'Easy', style: 'Looks for captures and safe forward progress', icon: '🔎' },
  { id: 'tactician', name: 'Tactician', tier: 'Medium', style: 'Finds forced captures and short tactical lines', icon: '🎯' },
  { id: 'guardian', name: 'Guardian', tier: 'Medium', style: 'Values safe pieces and stable formations', icon: '🛡️' },
  { id: 'raider', name: 'Raider', tier: 'Hard', style: 'Pushes for promotions and active kings', icon: '⚔️' },
  { id: 'veteran', name: 'Veteran', tier: 'Hard', style: 'Searches deeper and punishes loose pieces', icon: '🧠' },
  { id: 'strategist', name: 'Strategist', tier: 'Expert', style: 'Plans exchanges, space, and endgames', icon: '♟️' },
  { id: 'master', name: 'Master', tier: 'Expert+', style: 'Deeper tactical search with careful move ordering', icon: '🏆' },
  { id: 'grandmaster', name: 'Grandmaster', tier: 'Very hard', style: 'Deep search for captures, promotions, and traps', icon: '👑' },
  { id: 'nightmare', name: 'Nightmare', tier: 'Extreme', style: 'Brutal depth and tight move ordering', icon: '☠️' },
  { id: 'chinook', name: 'Chinook', tier: 'Legend', style: 'World-class engine style · mobility, tempo, and endgame squeeze', icon: '🧊' },
  { id: 'tinsley', name: 'Tinsley', tier: 'Mythic', style: 'Inspired by the greatest human checker player · near-perfect play', icon: '👑' },
];
type ArcadeMode = 'bot' | 'local';
type ArcadeMark = 'X' | 'O' | null;
let arcadeMode: ArcadeMode = 'bot';
let arcadeBotId = 'tactician';
let arcadeLastMove: number | null = null;
let arcadeBoard: ArcadeMark[] = Array(42).fill(null);
let arcadeTurn: ArcadeMark = 'X';
let arcadeNote = 'X starts. Pick a square.';
let arcadeWinner: ArcadeMark | 'draw' | null = null;
const arcadeBots = [
  { id: 'rookie', name: 'Rookie', style: 'Random legal moves', icon: '🌱' },
  { id: 'tactician', name: 'Tactician', style: 'Takes wins and blocks threats', icon: '🎯' },
  { id: 'guardian', name: 'Guardian', style: 'Defensive and patient', icon: '🛡️' },
  { id: 'raider', name: 'Raider', style: 'Aggressive winning lines', icon: '⚔️' },
  { id: 'trickster', name: 'Trickster', style: 'Unpredictable choices', icon: '🌀' },
  { id: 'grandmaster', name: 'Grandmaster', style: 'Deep search · hard to surprise', icon: '👑' },
  { id: 'perfect', name: 'Perfect', style: 'Near-optimal play · max depth search', icon: '💎' },
];
let showMoves = false;
let showGraphics = false;
let showShop = false;
let showDevConsole = false;
let devCodeInput = '';
let devCodeStatus = '';
let devUnlockBusy = false;
let devTapCount = 0;
let lastDevTapAt = 0;
type GameMode = 'bot' | 'local' | 'gemini' | 'battle' | 'lasting' | 'trainer';
let gameMode: GameMode = 'bot';
let geminiConfigured = false;
let geminiStatusChecked = false;
type VoxLevel = 'easy' | 'normal' | 'hard' | 'expert' | 'master';
const voxLevels: Array<{ id: VoxLevel; label: string; hint: string }> = [
  { id: 'easy', label: 'Easy', hint: 'Casual local play · shallow search, more mistakes' },
  { id: 'normal', label: 'Normal', hint: 'Solid club-level local engine' },
  { id: 'hard', label: 'Hard', hint: 'Deeper search · fewer free blunders' },
  { id: 'expert', label: 'Expert', hint: 'Strong tactical pressure offline' },
  { id: 'master', label: 'Master', hint: 'Deep local search · toughest offline Vox' },
];
let voxLevel: VoxLevel = 'normal';
let dismissedResultForCurrentGame = false;
let grandmasterMoreThinking = true;
let lastingKingComplete = false;
let showTrainerGuide = false;
let trainerFeedback = 'Welcome to Bot Trainer. Make a move and I will explain the idea.';
type GameStrategy = 'center' | 'kingside' | 'queenside' | 'solid' | 'endgame';
const strategyNames: Record<GameStrategy, string> = { center: 'Central Clamp', kingside: 'Kingside Pressure', queenside: 'Queenside Expansion', solid: 'Fortress First', endgame: 'Endgame Squeeze' };
let gameStrategy: GameStrategy = 'center';
function rollGameStrategy(): GameStrategy {
  const choices: GameStrategy[] = ['center', 'kingside', 'queenside', 'solid', 'endgame'];
  return choices[Math.floor(Math.random() * choices.length)];
}
function resetGameStrategy(): void { gameStrategy = rollGameStrategy(); }
const pieceName: Record<string, string> = {
  k: 'king', q: 'queen', r: 'rook', b: 'bishop', n: 'knight', p: 'pawn',
};
const pieceValue: Record<string, number> = {
  p: 100, n: 320, b: 335, r: 500, q: 900, k: 20000,
};
type SkinId = 'classic' | 'obsidian' | 'frost' | 'ember' | 'cyber' | 'royal' | 'verdant';
type SkinPalette = { metal: string; edge: string; shade: string; glint: string };
const skinCatalog: Array<{id: SkinId; name: string; price: number; description: string}> = [
  {id:'classic', name:'Classic Ivory', price:0, description:'The original ivory and charcoal set'},
  {id:'obsidian', name:'Obsidian Gold', price:150, description:'Black stone, polished gold, and warm highlights'},
  {id:'frost', name:'Frost Guard', price:225, description:'Glacial white against deep blue ice'},
  {id:'ember', name:'Ember Forge', price:250, description:'Forged bronze and volcanic red'},
  {id:'cyber', name:'Neon Circuit', price:300, description:'Electric cyan and neon violet'},
  {id:'royal', name:'Royal Mythic', price:450, description:'Regal gold and royal purple'},
  {id:'verdant', name:'Verdant Dragon', price:600, description:'Jade green and deep forest metal'},
];
const skinPalettes: Record<SkinId, {white: SkinPalette; black: SkinPalette}> = {
  classic: {white:{metal:'#f4ead0',edge:'#9a8155',shade:'#c8b184',glint:'#fff9e9'},black:{metal:'#303a39',edge:'#111817',shade:'#171f20',glint:'#6d7c78'}},
  obsidian: {white:{metal:'#f3df9b',edge:'#6f5120',shade:'#b28a39',glint:'#fff4c1'},black:{metal:'#15191f',edge:'#05070a',shade:'#394454',glint:'#91a2bb'}},
  frost: {white:{metal:'#f2fdff',edge:'#76a8bb',shade:'#b6dfe8',glint:'#ffffff'},black:{metal:'#3d6f9b',edge:'#18364e',shade:'#244b73',glint:'#92edff'}},
  ember: {white:{metal:'#ffd0a0',edge:'#8a3e20',shade:'#ce6936',glint:'#fff0d1'},black:{metal:'#642b28',edge:'#24100f',shade:'#341719',glint:'#ff9478'}},
  cyber: {white:{metal:'#b8fff4',edge:'#167f80',shade:'#5cc8c4',glint:'#efffff'},black:{metal:'#582c8c',edge:'#1f1036',shade:'#311755',glint:'#ff8cfa'}},
  royal: {white:{metal:'#ffe9a8',edge:'#9b7420',shade:'#c89c40',glint:'#fff8d6'},black:{metal:'#483066',edge:'#1c112a',shade:'#291a3b',glint:'#d4b8ff'}},
  verdant: {white:{metal:'#d1f3b5',edge:'#4e753c',shade:'#83b15e',glint:'#f5ffde'},black:{metal:'#203d32',edge:'#0b1a14',shade:'#14261e',glint:'#80c9a2'}},
};
function loadVuzz(): number { try { const raw = localStorage.getItem('chezz-vuzz'); if (raw === null) { localStorage.setItem('chezz-vuzz','250'); return 250; } const value = Number(raw); return Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0; } catch { return 250; } }
function loadVuzzUnlimited(): boolean { try { return localStorage.getItem('chezz-vuzz-unlimited') === 'true'; } catch { return false; } }
function loadOwnedSkins(): SkinId[] { try { const parsed = JSON.parse(localStorage.getItem('chezz-owned-skins') ?? '["classic"]') as unknown; if (!Array.isArray(parsed)) return ['classic']; const valid = parsed.filter((id): id is SkinId => typeof id === 'string' && skinCatalog.some(skin => skin.id === id)); return Array.from(new Set<SkinId>(['classic', ...valid])); } catch { return ['classic']; } }
function loadSelectedSkin(): SkinId { try { const id = localStorage.getItem('chezz-selected-skin') as SkinId | null; return id && skinCatalog.some(skin => skin.id === id) && loadOwnedSkins().includes(id) ? id : 'classic'; } catch { return 'classic'; } }
let vuzzBalance = loadVuzz();
let vuzzUnlimited = loadVuzzUnlimited();
let ownedSkins: SkinId[] = loadOwnedSkins();
let selectedPieceSkin: SkinId = loadSelectedSkin();
let vuzzAwardedForGame = false;
function saveEconomy(): void { try { localStorage.setItem('chezz-vuzz', String(vuzzBalance)); localStorage.setItem('chezz-vuzz-unlimited', String(vuzzUnlimited)); localStorage.setItem('chezz-owned-skins', JSON.stringify(ownedSkins)); localStorage.setItem('chezz-selected-skin', selectedPieceSkin); } catch { /* Economy remains available for this session. */ } }

async function unlockDeveloperMode(): Promise<void> {
  if (devUnlockBusy) return;
  devUnlockBusy = true;
  devCodeStatus = 'Checking developer code…';
  render();
  try {
    // Intentionally simple local developer code as requested. Not secure; remove before public release.
    const response = { data: { unlocked: devCodeInput.trim().toLocaleLowerCase() === 'chezz' } };
    if (response.data?.unlocked === true) {
      vuzzUnlimited = true;
      vuzzBalance = Number.MAX_SAFE_INTEGER;
      ownedSkins = skinCatalog.map(skin => skin.id);
      saveEconomy();
      selectedPieceSkin = selectedPieceSkin || 'classic';
      devCodeInput = '';
      devCodeStatus = '';
      devUnlockBusy = false;
      showDevConsole = false;
      showShop = true;
      note = 'Developer mode unlocked: all piece skins are owned and Vuzz is unlimited.';
      render();
      return;
    }
    devCodeStatus = 'That developer code is not valid.';
  } catch {
    devCodeStatus = 'The code check could not reach the server. Try again while online.';
  }
  devUnlockBusy = false;
  render();
}
function sculptedPiece(color: 'w' | 'b', type: string, detail: DetailLevel = pieceDetail, skin: SkinId = selectedPieceSkin): string {
  const light = color === 'w';
  const colors = (skinPalettes[skin] ?? skinPalettes.classic)[light ? 'white' : 'black'];
  const metal = colors.metal;
  const edge = colors.edge;
  const shade = colors.shade;
  const glint = colors.glint;
  const base = detail === 'simplified'
    ? `<ellipse cx="50" cy="90" rx="25" ry="3" fill="#000" opacity=".18"/><path d="M28 79 H72 L78 88 H22 Z" fill="${metal}" stroke="${edge}" stroke-width="2"/>`
    : `<ellipse cx="50" cy="91" rx="28" ry="4" fill="#000" opacity=".24"/><path d="M25 82 L75 82 L81 91 L19 91 Z" fill="${shade}" stroke="${edge}" stroke-width="2.5"/><path d="M22 82 L78 82 L75 87 L25 87 Z" fill="${metal}" stroke="${edge}" stroke-width="2"/><path d="M29 77 L71 77 L75 82 L25 82 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/>`;
  const body: Record<string, string> = {
    p: `<path d="M36 76 L40 64 L60 64 L64 76 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M40 64 L44 57 L56 57 L60 64 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/><path d="M42 72 L50 67 L58 72" fill="none" stroke="${glint}" stroke-width="2"/><circle cx="50" cy="43" r="12" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M41 40 Q50 32 59 40" fill="none" stroke="${glint}" stroke-width="2"/>`,
    n: `<path d="M31 77 L38 62 L62 62 L69 77 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M37 65 L35 48 L39 28 L52 17 L67 22 L71 34 L63 45 L60 59 Z" fill="${metal}" stroke="${edge}" stroke-width="3" stroke-linejoin="round"/><path d="M39 29 L31 20 L43 22 L52 17 L58 27 L52 37 L42 42 Z" fill="${shade}" stroke="${edge}" stroke-width="2.5"/><path d="M42 27 L51 23 L59 28 L52 31 Z" fill="${glint}"/><path d="M54 39 L67 35 L62 43 L54 44 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/><circle cx="58" cy="32" r="2.5" fill="${light ? '#59452b' : '#e5d19d'}"/><path d="M43 51 L56 45 L59 57 L46 62 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/>`,
    b: `<path d="M32 77 L38 63 L62 63 L68 77 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M40 63 L43 52 L57 52 L60 63 Z" fill="${shade}" stroke="${edge}" stroke-width="2.5"/><path d="M39 51 L43 37 L50 24 L57 37 L61 51 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M50 28 L55 38 L50 46 L45 38 Z" fill="${shade}"/><path d="M50 25 L50 48" stroke="${glint}" stroke-width="2"/><circle cx="50" cy="19" r="5" fill="${metal}" stroke="${edge}" stroke-width="2"/>`,
    r: `<path d="M30 77 L34 56 L66 56 L70 77 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M35 56 L35 34 L42 34 L42 40 L48 40 L48 31 L54 31 L54 40 L60 40 L60 34 L66 34 L66 56 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M42 49 L58 49 L58 57 L42 57 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/><path d="M39 61 L61 61 M37 68 L63 68" stroke="${glint}" stroke-width="2"/>`,
    q: `<path d="M31 77 L35 62 L65 62 L69 77 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M38 62 L42 49 L58 49 L62 62 Z" fill="${shade}" stroke="${edge}" stroke-width="2.5"/><path d="M37 48 L32 30 L43 39 L50 22 L57 39 L68 30 L63 48 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5" stroke-linejoin="round"/><circle cx="32" cy="28" r="4" fill="${metal}" stroke="${edge}" stroke-width="2"/><circle cx="50" cy="20" r="4" fill="${metal}" stroke="${edge}" stroke-width="2"/><circle cx="68" cy="28" r="4" fill="${metal}" stroke="${edge}" stroke-width="2"/><path d="M42 53 L50 47 L58 53 L50 60 Z" fill="${glint}"/>`,
    k: `<path d="M31 77 L35 62 L65 62 L69 77 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M38 62 L41 49 L59 49 L62 62 Z" fill="${shade}" stroke="${edge}" stroke-width="2.5"/><path d="M40 49 L40 37 L60 37 L60 49 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M47 35 L47 12 L53 12 L53 35 Z" fill="${metal}" stroke="${edge}" stroke-width="2.5"/><path d="M41 20 L59 20 M50 11 L50 3" stroke="${glint}" stroke-width="2.5" stroke-linecap="round"/><path d="M41 41 L50 36 L59 41" fill="none" stroke="${glint}" stroke-width="2"/>`
  };
  const simplifiedBody: Record<string, string> = {
    p: `<circle cx="50" cy="42" r="11" fill="${metal}"/><path d="M39 57 H61 L68 79 H32 Z" fill="${metal}"/>`,
    n: `<path d="M35 77 L40 56 L39 37 L49 23 L65 27 L69 40 L57 51 L60 63 L66 77 Z" fill="${metal}"/><path d="M49 24 L42 16 L55 20 L61 28 Z" fill="${shade}"/>`,
    b: `<path d="M35 78 L41 56 L43 37 L50 23 L57 37 L59 56 L65 78 Z" fill="${metal}"/>`,
    r: `<path d="M32 78 V39 H39 V48 H46 V35 H54 V48 H61 V39 H68 V78 Z" fill="${metal}"/>`,
    q: `<path d="M33 78 L38 56 L32 34 L44 44 L50 23 L56 44 L68 34 L62 56 L67 78 Z" fill="${metal}"/>`,
    k: `<path d="M33 78 L38 56 H62 L67 78 Z M40 55 V37 H60 V55 Z M47 36 V14 H53 V36 Z" fill="${metal}"/>`
  };
  const horseKnight = `<path d="M30 78 L37 61 L35 45 L39 30 L52 18 L68 24 L74 37 L64 49 L60 62 L68 78 Z" fill="${metal}" stroke="${edge}" stroke-width="2.8" stroke-linejoin="round"/><path d="M42 29 Q26 25 25 10 Q38 16 45 21 Q43 9 51 4 Q56 18 59 22 Q70 17 79 22 Q69 28 67 35" fill="${shade}" stroke="${edge}" stroke-width="2.3" stroke-linejoin="round"/><path d="M44 29 L53 24 L63 29 L54 34 Z" fill="${glint}"/><path d="M57 40 L70 36 L65 44 L56 46 Z" fill="${shade}" stroke="${edge}" stroke-width="1.8"/><circle cx="62" cy="31" r="2.8" fill="${light ? '#59452b' : '#f4d79a'}"/><path d="M42 51 Q53 45 58 57 L48 64 Z" fill="${shade}" stroke="${edge}" stroke-width="2"/><path d="M33 35 Q25 41 30 52 M38 30 Q32 23 31 17 M42 27 Q39 18 44 12" fill="none" stroke="${glint}" stroke-width="2" stroke-linecap="round"/>`;
  const detailOrnaments = detail === 'extreme' ? `<path d="M30 78 L70 78 M33 73 L67 73 M36 68 L64 68" stroke="${glint}" stroke-width="1.8" fill="none"/><path d="M36 59 L42 54 L50 59 L58 54 L64 59" fill="none" stroke="${glint}" stroke-width="1.8"/><circle cx="50" cy="76" r="3" fill="${glint}"/>` : detail === 'super'
    ? `<path d="M32 78 L68 78 M35 73 L65 73 M38 68 L62 68" stroke="${glint}" stroke-width="1.6" fill="none"/><path d="M36 59 L42 54 L50 59 L58 54 L64 59" fill="none" stroke="${glint}" stroke-width="1.6"/><circle cx="50" cy="76" r="2.5" fill="${glint}"/><path d="M29 84 L34 87 L39 84 M61 84 L66 87 L71 84" fill="none" stroke="${glint}" stroke-width="1.3"/>`
    : detail === 'very'
      ? `<path d="M34 78 L66 78 M38 70 L62 70 M40 59 L46 55 L54 55 L60 59" stroke="${glint}" stroke-width="1.5" fill="none"/><circle cx="50" cy="76" r="2" fill="${glint}"/>`
      : detail === 'detailed'
        ? `<path d="M38 78 L62 78 M40 60 L46 56 L54 56 L60 60" stroke="${glint}" stroke-width="1.3" fill="none"/>`
        : '';
  const emblem = type === 'n' && detail !== 'simplified' ? `<path d="M43 57 L50 51 L57 57 L50 63 Z" fill="${glint}" stroke="${edge}" stroke-width="1.5"/>` : '';
  const detailLines = detail === 'extreme' ? `<path d="M25 80 L75 80 M29 76 L71 76 M34 70 L39 66 M61 66 L66 70" fill="none" stroke="${glint}" stroke-width="2"/><circle cx="30" cy="85" r="1.7" fill="${glint}"/><circle cx="70" cy="85" r="1.7" fill="${glint}"/>` : detail === 'super'
    ? `<path d="M25 80 L75 80 M29 76 L71 76 M34 70 L39 66 M61 66 L66 70" fill="none" stroke="${glint}" stroke-width="1.8"/><circle cx="30" cy="85" r="1.5" fill="${glint}"/><circle cx="70" cy="85" r="1.5" fill="${glint}"/><path d="M35 58 L39 54 M61 54 L65 58" stroke="${glint}" stroke-width="1.5"/>`
    : detail === 'very'
      ? `<path d="M28 80 L72 80 M34 70 L39 66 M61 66 L66 70" fill="none" stroke="${glint}" stroke-width="1.6"/><circle cx="30" cy="85" r="1.3" fill="${glint}"/><circle cx="70" cy="85" r="1.3" fill="${glint}"/>`
      : detail === 'detailed'
        ? `<path d="M30 80 L70 80 M35 70 L40 66 M60 66 L65 70" fill="none" stroke="${glint}" stroke-width="1.3"/>`
        : '';
  const finish = detail === 'simplified'
    ? `<path d="M28 84 L72 84" stroke="${glint}" stroke-width="1" opacity=".55"/>`
    : `<path d="M28 84 L72 84" stroke="${glint}" stroke-width="1.5" opacity=".9"/>`;
  const selectedBody = detail === 'simplified' ? simplifiedBody[type] : type === 'n' && detail === 'super' ? horseKnight : (body[type] ?? body.p);
  return `<svg class="sculpted-piece sculpted-${type} detail-${detail}" viewBox="0 0 100 96" aria-hidden="true" focusable="false"><defs><linearGradient id="metal-${color}-${type}" x1="0" y1="0" x2="1" y2=".8"><stop offset="0" stop-color="${glint}"/><stop offset=".38" stop-color="${metal}"/><stop offset="1" stop-color="${shade}"/></linearGradient></defs>${base}<g fill="url(#metal-${color}-${type})">${selectedBody}</g>${detailOrnaments}${detailLines}${emblem}${finish}</svg>`;
}

type BotId = 'hikaru' | 'chatgpt-style' | 'human-style' | 'rookie' | 'blitz' | 'guardian' | 'scholar' | 'wildcard' | 'mastermind' | 'grandmaster' | 'strategist' | 'patient-pawn' | 'puzzle-panda' | 'rush-rocket' | 'queen-raider' | 'fork-falcon' | 'pin-phantom' | 'skewer-shark' | 'iron-fortress' | 'shieldmaiden' | 'center-sage' | 'bishop-duo' | 'gambit-ghost' | 'tempo-thief' | 'endgame-ace' | 'iron-calculator' | 'grand-architect' | 'storm-emperor' | 'endgame-oracle' | 'tactical-titan' | 'mythic-vuzz' | 'mahoraga' | 'custom';
type BotProfile = {
  id: BotId;
  name: string;
  title: string;
  style: string;
  difficulty: string;
  depth: number;
  mistakeMargin: number;
  icon: string;
  description: string;
  className?: string;
};
const bots: BotProfile[] = [
  { id: 'hikaru', name: 'Hikaru Nakamura Style', title: 'The Speed Tactician', style: 'Dynamic tactics, initiative, practical complications, and rapid counterplay', difficulty: 'LEGEND', depth: 9, mistakeMargin: 0, icon: '⚡', className: 'Legends', description: 'A CHEZZ-created style profile inspired by Hikaru Nakamura’s public playing reputation: tactical alertness, initiative, active pieces, and practical complications. It is not trained on his private data or a replica of his exact decisions.' },
  { id: 'chatgpt-style', name: 'ChatGPT Strategist', title: 'The Helpful Analyst', style: 'Calm tactical and positional analysis', difficulty: 'EXPERT', depth: 5, mistakeMargin: 8, icon: '✦', className: 'Strategic', description: 'A local chess persona inspired by ChatGPT, using CHEZZ move search only. It is not connected to the ChatGPT model.' },
  { id: 'human-style', name: 'Human Challenger', title: 'The Natural Player', style: 'Human-like plans with realistic imperfections', difficulty: 'CLUB', depth: 3, mistakeMargin: 95, icon: '♟️', className: 'Trickster', description: 'Balances development, captures, king safety and occasional imperfect choices to create a more human-feeling game.' },
  { id: 'rookie', name: 'Rookie Ray', title: 'The Newbie', style: 'Casual & forgiving', difficulty: 'EASY', depth: 1, mistakeMargin: 650, icon: '♟', className: 'Newbie', description: 'A relaxed opponent who makes imperfect choices. Great for learning.' },
  { id: 'blitz', name: 'Blitz', title: 'The Attacker', style: 'Aggressive & tactical', difficulty: 'MEDIUM', depth: 2, mistakeMargin: 90, icon: '⚡', className: 'Aggressive', description: 'Looks for checks, captures, and quick attacks.' },
  { id: 'guardian', name: 'Sentinel', title: 'The Defender', style: 'Careful & defensive', difficulty: 'MEDIUM', depth: 2, mistakeMargin: 45, icon: '🛡', className: 'Defensive', description: 'Prefers safe development and protecting material.' },
  { id: 'scholar', name: 'Scholar', title: 'The Strategist', style: 'Balanced & calculating', difficulty: 'HARD', depth: 3, mistakeMargin: 0, icon: '♜', className: 'Strategic', description: 'Searches ahead and favors sound, central positions.' },
  { id: 'wildcard', name: 'Wildcard', title: 'The Unpredictable', style: 'Chaotic & surprising', difficulty: 'UNPREDICTABLE', depth: 1, mistakeMargin: 260, icon: '✦', className: 'Trickster', description: 'Chooses from a wider range of moves. Never quite the same game.' },
  { id: 'mastermind', name: 'MASTERMIND', title: 'The Grand Tactician', style: 'Deep search & cold calculation', difficulty: 'INSANE', depth: 4, mistakeMargin: 0, icon: '◈', className: 'Tactical', description: 'A ruthless tactical opponent with a deep local search.' },
  { id: 'grandmaster', name: 'GRANDMASTER', title: 'The Final Boss', style: 'Positional strategy, tactics & endgames', difficulty: 'ULTIMATE', depth: 9, mistakeMargin: 0, icon: '♛', className: 'Pro', description: 'CHEZZ’s strongest local profile: prioritizes tactics, king safety, piece activity, and pawn advancement. More Thinking allows up to 10 seconds per move, but no local engine can calculate every possible continuation.' },
  { id: 'strategist', name: 'STRATEGIST', title: 'The Master Planner', style: 'Deterministic strategy, tactics & endgames', difficulty: 'ELITE', depth: 12, mistakeMargin: 0, icon: '♜', className: 'Strategic', description: 'CHEZZ’s strategy-first offline opponent. Uses deeper search, king-safety and passed-pawn evaluation, values safe castling, and always chooses its top-scored move rather than adding randomness. Strength is limited by its local search and thinking budget.' },
  { id: 'patient-pawn', name: 'Patient Pawn', title: 'The Careful Beginner', style: 'Slow, solid development', difficulty: 'BEGINNER+', depth: 2, mistakeMargin: 180, icon: '🌱', className: 'Newbie', description: 'Builds a simple position and avoids rushing pieces.' },
  { id: 'puzzle-panda', name: 'Puzzle Panda', title: 'The Curious Learner', style: 'Basic tactics and safe trades', difficulty: 'BEGINNER+', depth: 2, mistakeMargin: 130, icon: '🐼', className: 'Newbie', description: 'Practises simple forks, captures, and piece safety.' },
  { id: 'rush-rocket', name: 'Rush Rocket', title: 'The Speed Attacker', style: 'Fast kingside pressure', difficulty: 'CLUB', depth: 3, mistakeMargin: 55, icon: '🚀', className: 'Aggressive', description: 'Looks for forcing checks and quick attacks, sometimes at a positional cost.' },
  { id: 'queen-raider', name: 'Queen Raider', title: 'The Royal Hunter', style: 'Queen-led attacking play', difficulty: 'CLUB+', depth: 3, mistakeMargin: 35, icon: '👑', className: 'Aggressive', description: 'Uses queen activity to target loose pieces and exposed kings.' },
  { id: 'fork-falcon', name: 'Fork Falcon', title: 'The Fork Specialist', style: 'Knight tactics and double attacks', difficulty: 'ADVANCED', depth: 4, mistakeMargin: 0, icon: '🦅', className: 'Tactical', description: 'Searches for forks, checks, and tactical piece wins.' },
  { id: 'pin-phantom', name: 'Pin Phantom', title: 'The Pin Artist', style: 'Pins and overloaded defenders', difficulty: 'ADVANCED', depth: 4, mistakeMargin: 0, icon: '🪡', className: 'Tactical', description: 'Prioritizes moves that attack pinned pieces and overloaded defenders.' },
  { id: 'skewer-shark', name: 'Skewer Shark', title: 'The X-Ray Hunter', style: 'Skewers and discovered attacks', difficulty: 'ADVANCED+', depth: 4, mistakeMargin: 0, icon: '🦈', className: 'Tactical', description: 'Looks for lines where a valuable piece must move and expose another target.' },
  { id: 'iron-fortress', name: 'Iron Fortress', title: 'The Unbreakable Wall', style: 'Safe king and defended pieces', difficulty: 'ADVANCED', depth: 4, mistakeMargin: 0, icon: '🏰', className: 'Defensive', description: 'Prefers safer structures, castling, and defending weaknesses before attacking.' },
  { id: 'shieldmaiden', name: 'Shieldmaiden', title: 'The Counterpuncher', style: 'Defend, then strike back', difficulty: 'ADVANCED+', depth: 5, mistakeMargin: 0, icon: '🛡️', className: 'Defensive', description: 'Tries to neutralize threats before launching a counterattack.' },
  { id: 'center-sage', name: 'Center Sage', title: 'The Space Controller', style: 'Central squares and piece activity', difficulty: 'EXPERT', depth: 5, mistakeMargin: 0, icon: '☯️', className: 'Strategic', description: 'Values space, central control, and routes for its minor pieces.' },
  { id: 'bishop-duo', name: 'Bishop Duo', title: 'The Diagonal Planner', style: 'Bishop pair and open diagonals', difficulty: 'EXPERT', depth: 5, mistakeMargin: 0, icon: '♝', className: 'Strategic', description: 'Works toward active bishops and long diagonal pressure.' },
  { id: 'gambit-ghost', name: 'Gambit Ghost', title: 'The Sacrifice Seeker', style: 'Dynamic play and initiative', difficulty: 'EXPERT', depth: 4, mistakeMargin: 20, icon: '👻', className: 'Aggressive', description: 'Looks for attacking initiative and gambit-like ideas. Not every sacrifice is sound.' },
  { id: 'tempo-thief', name: 'Tempo Thief', title: 'The Trickster', style: 'Probes, threats, and initiative', difficulty: 'EXPERT', depth: 4, mistakeMargin: 0, icon: '🎭', className: 'Trickster', description: 'Looks for moves that gain time by creating a threat the opponent must answer.' },
  { id: 'endgame-ace', name: 'Endgame Ace', title: 'The Simplifier', style: 'King activity and passed pawns', difficulty: 'MASTER', depth: 5, mistakeMargin: 0, icon: '♟️', className: 'Endgame', description: 'Shines most in simplified positions, advancing passed pawns and activating its king.' },
  { id: 'iron-calculator', name: 'Iron Calculator', title: 'The Club Master', style: 'Balanced calculation', difficulty: 'MASTER', depth: 6, mistakeMargin: 0, icon: '🧮', className: 'Pro', description: 'A more demanding all-rounder using deeper local search and fewer deliberate mistakes.' },
  { id: 'grand-architect', name: 'Grand Architect', title: 'Legend I · The Position Sculptor', style: 'Long-term structure and piece harmony', difficulty: 'LEGEND I', depth: 8, mistakeMargin: 0, icon: '🏛️', className: 'Legends', description: 'A high-difficulty target that prizes coordination, space, king safety, and strong squares.' },
  { id: 'storm-emperor', name: 'Storm Emperor', title: 'Legend II · The Attack Master', style: 'Relentless tactical pressure', difficulty: 'LEGEND II', depth: 8, mistakeMargin: 0, icon: '🌩️', className: 'Legends', description: 'An aggressive Legend profile that leans into forcing lines and king attacks.' },
  { id: 'endgame-oracle', name: 'Endgame Oracle', title: 'Legend III · The Endgame Sage', style: 'King activity and pawn races', difficulty: 'LEGEND III', depth: 9, mistakeMargin: 0, icon: '🔮', className: 'Legends', description: 'A tougher endgame specialist built to value passed pawns and active kings.' },
  { id: 'tactical-titan', name: 'Tactical Titan', title: 'Legend IV · The Combination Hunter', style: 'Deep forcing-line search', difficulty: 'LEGEND IV', depth: 9, mistakeMargin: 0, icon: '⚔️', className: 'Legends', description: 'The most tactical Legend profile, prioritizing forcing moves and concrete threats.' },
  { id: 'mythic-vuzz', name: 'Mythic Vuzz', title: 'Legend V · The Final Trial', style: 'Strategy, tactics, and endgame pressure', difficulty: 'LEGEND V', depth: 10, mistakeMargin: 0, icon: '🐉', className: 'Legends', description: 'CHEZZ’s ultimate local challenge profile. It searches deeply within a capped budget, but is not a proven superhuman engine.' },
  { id: 'mahoraga', name: 'MAHORAGA', title: 'The Adaptive Nemesis', style: 'Persistent memory · live counter-strategy', difficulty: 'ADAPTIVE', depth: 5, mistakeMargin: 0, icon: '🎡', className: 'Legends', description: 'Studies your moves, adapts its counter-strategy during the match, and remembers your tendencies across sessions on this device.' },
  { id: 'custom', name: 'CUSTOM BOT', title: 'Your Rules', style: 'Tuned by you', difficulty: 'CUSTOM', depth: 4, mistakeMargin: 70, icon: '⚙', className: 'Custom', description: 'Your saved custom opponent. Adjust its thinking time, search depth, and mistake tolerance.' }
];

type AdaptationProfile = { moves: number; captures: number; checks: number; centerMoves: number; queenEarlyMoves: number; gamesObserved: number; lastWheel: number };
const blankAdaptationProfile = (): AdaptationProfile => ({ moves: 0, captures: 0, checks: 0, centerMoves: 0, queenEarlyMoves: 0, gamesObserved: 0, lastWheel: 0 });
function loadAdaptationProfile(): AdaptationProfile {
  try {
    const raw = localStorage.getItem('chezz-mahoraga-memory');
    if (!raw) return blankAdaptationProfile();
    const parsed = JSON.parse(raw) as Partial<AdaptationProfile>;
    const base = blankAdaptationProfile();
    for (const key of Object.keys(base) as Array<keyof AdaptationProfile>) {
      const value = Number(parsed[key]);
      if (Number.isFinite(value)) base[key] = Math.max(0, Math.min(100000, Math.floor(value)));
    }
    return base;
  } catch { return blankAdaptationProfile(); }
}
let mahoragaMemory = loadAdaptationProfile();
function saveMahoragaMemory(): void { try { localStorage.setItem('chezz-mahoraga-memory', JSON.stringify(mahoragaMemory)); } catch { /* Adaptation continues for this session if storage is unavailable. */ } }
function observePlayerMove(move: Move): void {
  if (gameMode !== 'bot' || selectedBot !== 'mahoraga' || move.color !== playerColor) return;
  mahoragaMemory.moves++;
  if (move.captured) mahoragaMemory.captures++;
  if (move.san.includes('+') || move.san.includes('#')) mahoragaMemory.checks++;
  const file = files.indexOf(move.to[0]);
  const rank = Number(move.to[1]);
  if (Math.abs(file - 3.5) + Math.abs(rank - 4.5) <= 2) mahoragaMemory.centerMoves++;
  if (move.piece === 'q' && game.history().length <= 12) mahoragaMemory.queenEarlyMoves++;
  mahoragaMemory.lastWheel = Math.floor(mahoragaMemory.moves / 3) % 8;
  saveMahoragaMemory();
}
function adaptationPercent(value: number): number { return mahoragaMemory.moves ? Math.round(value / mahoragaMemory.moves * 100) : 0; }

let selectedBot: BotId = 'rookie';
let activeSearchBot: BotId = 'rookie';
let botSearch = '';
let botClassFilter = 'All';
const botClasses = ['All','Newbie','Aggressive','Tactical','Defensive','Strategic','Trickster','Endgame','Pro','Legends','Custom'];
function botMatchesFilter(profile: BotProfile): boolean { const classMatch = botClassFilter === 'All' || profile.className === botClassFilter; const haystack = `${profile.name} ${profile.title} ${profile.style} ${profile.className ?? ''} ${profile.difficulty}`.toLowerCase(); return classMatch && haystack.includes(botSearch.trim().toLowerCase()); }
let whiteBattleBot: BotId = 'scholar';
let blackBattleBot: BotId = 'grandmaster';
type BoardTheme = 'forest' | 'ocean' | 'royal' | 'neon' | 'sand' | 'ice' | 'realistic';
const boardThemes: Array<{ id: BoardTheme; label: string; hint: string }> = [
  { id: 'realistic', label: 'Realistic Wood', hint: 'Warm maple and walnut squares with a polished wooden frame' },
  { id: 'forest', label: 'Forest Classic', hint: 'The original green and ivory' },
  { id: 'ocean', label: 'Ocean Blue', hint: 'Actual blue and white squares with cyan accents' },
  { id: 'ice', label: 'Glacier Ice', hint: 'Icy blue and snow-white squares with frosted highlights' },
  { id: 'royal', label: 'Royal Violet', hint: 'Purple tones and gold highlights' },
  { id: 'neon', label: 'Neon Cyber', hint: 'Electric teal with deep midnight squares' },
  { id: 'sand', label: 'Desert Sand', hint: 'Warm sand and terracotta colors' },
];
function readSaved<T extends string>(key: string, allowed: T[], fallback: T): T {
  try { const value = localStorage.getItem(key); return allowed.includes(value as T) ? value as T : fallback; } catch { return fallback; }
}
const skinThemeMap: Record<SkinId, BoardTheme> = { classic: 'forest', obsidian: 'royal', frost: 'ice', ember: 'sand', cyber: 'neon', royal: 'royal', verdant: 'forest' };
let boardTheme = selectedPieceSkin === 'classic' ? readSaved<BoardTheme>('chezz-theme', boardThemes.map(theme => theme.id), 'forest') : skinThemeMap[selectedPieceSkin];
type ClockPreset = 'untimed' | '3+2' | '5+0' | '10+0' | '15+10';
const clockPresets: Array<{ id: ClockPreset; label: string; base: number; increment: number }> = [
  { id: 'untimed', label: 'Untimed', base: 0, increment: 0 },
  { id: '3+2', label: '3 + 2 Blitz', base: 180, increment: 2 },
  { id: '5+0', label: '5 + 0 Blitz', base: 300, increment: 0 },
  { id: '10+0', label: '10 + 0 Rapid', base: 600, increment: 0 },
  { id: '15+10', label: '15 + 10 Rapid', base: 900, increment: 10 },
];
let clockPreset = readSaved<ClockPreset>('chezz-clock-preset', clockPresets.map(preset => preset.id), '10+0');
let whiteTimeMs = 600_000;
let blackTimeMs = 600_000;
let clockLastTick = Date.now();
let clockFlagged: 'w' | 'b' | null = null;
type CustomBotSettings = { thinkSeconds: number; depth: number; mistakeMargin: number; aggression: number; defense: number; positional: number; centerControl: number; kingSafety: number; development: number; randomness: number };
function customSettings(): CustomBotSettings {
  const defaults: CustomBotSettings = { thinkSeconds: 5, depth: 4, mistakeMargin: 70, aggression: 65, defense: 60, positional: 55, centerControl: 65, kingSafety: 70, development: 60, randomness: 10 };
  try { const raw = localStorage.getItem('chezz-custom-bot'); if (raw) { const parsed = JSON.parse(raw) as Partial<CustomBotSettings>; for (const key of Object.keys(defaults) as Array<keyof CustomBotSettings>) { const max = key === 'thinkSeconds' || key === 'depth' ? 10 : key === 'mistakeMargin' ? 800 : 100; const min = key === 'thinkSeconds' || key === 'depth' ? 1 : 0; const val = Number(parsed[key]); if (Number.isFinite(val)) defaults[key] = Math.max(min, Math.min(max, val)); } } } catch { /* Use defaults if saved settings are unavailable. */ }
  return defaults;
}
let customBotSettings: CustomBotSettings = customSettings();
function formatClock(milliseconds: number): string {
  const safe = Math.max(0, Math.ceil(milliseconds / 1000));
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}
function syncClock(): void {
  if (clockPreset === 'untimed' || clockFlagged || game.isGameOver()) { clockLastTick = Date.now(); return; }
  const now = Date.now();
  const elapsed = now - clockLastTick;
  if (elapsed > 0) {
    if (game.turn() === 'w') whiteTimeMs = Math.max(0, whiteTimeMs - elapsed);
    else blackTimeMs = Math.max(0, blackTimeMs - elapsed);
    if (whiteTimeMs <= 0) { clockFlagged = 'w'; note = 'White ran out of time. Black wins on time.'; }
    if (blackTimeMs <= 0) { clockFlagged = 'b'; note = 'Black ran out of time. White wins on time.'; }
  }
  clockLastTick = now;
}
function resetClocks(): void {
  const preset = clockPresets.find(item => item.id === clockPreset) ?? clockPresets[3];
  whiteTimeMs = preset.base * 1000;
  blackTimeMs = preset.base * 1000;
  clockFlagged = null;
  clockLastTick = Date.now();
}
function saveCompletedMatch(): void {
  if (matchSavedForCurrentGame || (!game.isGameOver() && !clockFlagged) || !game.history().length) return;
  const pgn = game.pgn();
  if (!pgn) return;
  const result = clockFlagged ? 'Time forfeit' : game.isCheckmate() ? (game.turn() === 'w' ? 'Black wins' : 'White wins') : game.isDraw() ? 'Draw' : 'Game complete';
  const record: SavedMatch = { id: `${Date.now()}-${game.history().length}`, pgn, mode: gameMode, bot: gameMode === 'battle' ? `${whiteBattleBot} vs ${blackBattleBot}` : selectedBot, playerColor, result, moves: game.history().length, createdAt: Date.now() };
  matchHistory = [record, ...matchHistory].slice(0, 30);
  try { localStorage.setItem('chezz-match-history', JSON.stringify(matchHistory)); } catch { /* The current game remains playable if storage is full. */ }
  matchSavedForCurrentGame = true;
}
function updateClockDisplay(): void {
  if (!app || showHomeScreen || showMoveReplicator) return;
  const cards = app.querySelectorAll<HTMLElement>('.clock-card');
  const blackCard = cards[0];
  const whiteCard = cards[1];
  const blackStrong = blackCard?.querySelector('strong');
  const whiteStrong = whiteCard?.querySelector('strong');
  if (blackStrong) blackStrong.textContent = clockPreset === 'untimed' ? '∞' : formatClock(blackTimeMs);
  if (whiteStrong) whiteStrong.textContent = clockPreset === 'untimed' ? '∞' : formatClock(whiteTimeMs);
  blackCard?.classList.toggle('clock-active', game.turn() === 'b' && !game.isGameOver() && !clockFlagged);
  whiteCard?.classList.toggle('clock-active', game.turn() === 'w' && !game.isGameOver() && !clockFlagged);
  blackCard?.classList.toggle('clock-flagged', clockFlagged === 'b');
  whiteCard?.classList.toggle('clock-flagged', clockFlagged === 'w');
}
function updateStatusNote(): void { const status = app?.querySelector<HTMLElement>('.status-box p'); if (status) status.textContent = note; }
function saveActiveGame(): void {
  if (showHomeScreen || showMoveReplicator || game.isGameOver() || !game.history().length) return;
  try { localStorage.setItem('chezz-active-game', JSON.stringify({ pgn: game.pgn(), mode: gameMode, bot: selectedBot, clockPreset, whiteTimeMs, blackTimeMs, playerColor, savedAt: Date.now() })); resumeAvailable = true; } catch { /* Current game continues if storage is unavailable. */ }
}
function resumeSavedGame(): boolean {
  try {
    const saved = JSON.parse(localStorage.getItem('chezz-active-game') ?? 'null') as { pgn?: string; mode?: GameMode; bot?: string; clockPreset?: ClockPreset; whiteTimeMs?: number; blackTimeMs?: number; playerColor?: 'w' | 'b' } | null;
    if (!saved?.pgn) return false;
    game.reset(); game.loadPgn(saved.pgn);
    if (saved.mode && ['bot','local','gemini','battle','lasting','trainer'].includes(saved.mode)) gameMode = saved.mode;
    if (saved.bot && bots.some(bot => bot.id === saved.bot)) selectedBot = saved.bot as BotId;
    if (saved.clockPreset && clockPresets.some(item => item.id === saved.clockPreset)) clockPreset = saved.clockPreset;
    playerColor = saved.playerColor === 'b' ? 'b' : 'w'; whiteTimeMs = Number(saved.whiteTimeMs ?? 600000); blackTimeMs = Number(saved.blackTimeMs ?? 600000); clockFlagged = null; clockLastTick = Date.now();
    showHomeScreen = false; selected = null; targets = []; lastMove = null; thinking = false; animating = false; pendingPromotion = null; dismissedResultForCurrentGame = false;
    const history = game.history({ verbose: true }); const last = history[history.length - 1]; if (last) lastMove = { from: last.from, to: last.to };
    resumeAvailable = false; note = 'Game resumed from your local autosave.'; render();
    ensureBotToMove();
    return true;
  } catch { return false; }
}
let selected: Square | null = null;
let targets: Square[] = [];
let thinking = false;
let animating = false;
let impactSquare: Square | null = null;
let pendingPromotion: { from: Square; to: Square } | null = null;
let lastMove: { from: Square; to: Square } | null = null;
let activeMoveAnimation: { to: Square; token: number; overlay: HTMLElement } | null = null;
let moveAnimationToken = 0;
let queuedPremove: { from: Square; to: Square; promotion?: 'q' | 'r' | 'b' | 'n' } | null = null;
let suppressNextSquareClick = false;
function scheduleChessMoveAnimation(_from: Square, _to: Square): void {
  // Stable movement baseline: commit the authoritative board once, without cloned DOM pieces or animation timers.
  activeMoveAnimation?.overlay.remove();
  activeMoveAnimation = null;
  moveAnimationToken++;
}

function legalTargetsForPiece(square: Square, color: 'w' | 'b'): Square[] {
  const piece = game.get(square);
  if (!piece || piece.color !== color) return [];
  if (color === game.turn()) return game.moves({ square, verbose: true }).map(move => move.to);
  const fenParts = game.fen().split(' ');
  fenParts[1] = color;
  try {
    const previewGame = new Chess(fenParts.join(' '));
    return previewGame.moves({ square, verbose: true }).map(move => move.to);
  } catch {
    return [];
  }
}

function tryExecuteQueuedPremove(): boolean {
  if (!queuedPremove || gameMode !== 'bot' || game.turn() !== playerColor) return false;
  const premove = queuedPremove;
  queuedPremove = null;
  const legal = game.moves({ verbose: true }).some(move =>
    move.from === premove.from && move.to === premove.to && (!premove.promotion || move.promotion === premove.promotion),
  );
  if (!legal) {
    selected = null;
    targets = [];
    note = 'Premove cancelled because that move is no longer legal.';
    render();
    return true;
  }
  makePlayerMove(premove.from, premove.to, premove.promotion);
  return true;
}
let note = 'Your move. White starts.';
let turnToken = 0;
let searchDeadline = 0;
let searchNodes = 0;
const SEARCH_TIMEOUT = Symbol('search-timeout');
const thinkingBudgets: Partial<Record<BotId, number>> = {
  hikaru: 9000,
  'chatgpt-style': 3600,
  'human-style': 2200,
  rookie: 550,
  blitz: 800,
  guardian: 950,
  scholar: 1300,
  wildcard: 700,
  mastermind: 1400,
  grandmaster: grandmasterMoreThinking ? 10000 : 6500,
  strategist: 10000,
  custom: customBotSettings.thinkSeconds * 1000,
};
const searchDepthCaps: Partial<Record<BotId, number>> = {
  hikaru: 9,
  'chatgpt-style': 6,
  'human-style': 4,
  rookie: 3,
  blitz: 4,
  guardian: 4,
  scholar: 6,
  wildcard: 3,
  mastermind: 5,
  grandmaster: grandmasterMoreThinking ? 10 : 8,
  strategist: 12,
  custom: customBotSettings.depth,
};

function currentBot(): BotProfile {
  if (gameMode === 'gemini') return voxBotProfile();
  const id = gameMode === 'battle' ? (game.turn() === 'w' ? whiteBattleBot : blackBattleBot) : selectedBot;
  if (id === 'custom') return { ...bots[bots.length - 1], depth: customBotSettings.depth, mistakeMargin: customBotSettings.mistakeMargin, description: `Custom profile · ${customBotSettings.thinkSeconds}s · depth ${customBotSettings.depth}` };
  return bots.find(bot => bot.id === id) ?? bots[0];
}
function botForSide(side: 'w' | 'b'): BotProfile {
  if (gameMode === 'gemini') return voxBotProfile();
  const id = gameMode === 'battle' ? (side === 'w' ? whiteBattleBot : blackBattleBot) : selectedBot;
  if (id === 'custom') return { ...bots[bots.length - 1], depth: customBotSettings.depth, mistakeMargin: customBotSettings.mistakeMargin, description: `Custom profile · ${customBotSettings.thinkSeconds}s · depth ${customBotSettings.depth}` };
  return bots.find(bot => bot.id === id) ?? bots[0];
}


/** Kick the engine when it is the bot's turn (e.g. player chose Black). */
function ensureBotToMove(): void {
  if (showHomeScreen || game.isGameOver() || clockFlagged) return;
  if (gameMode === 'battle') {
    window.setTimeout(computerMove, 260);
    return;
  }
  if (gameMode === 'bot' || gameMode === 'trainer' || gameMode === 'lasting') {
    if (game.turn() !== playerColor) window.setTimeout(computerMove, 280);
    return;
  }
  if (gameMode === 'gemini' && game.turn() === 'b') {
    window.setTimeout(() => requestGeminiMove(), 280);
  }
}

function animeSprite(color: 'w' | 'b', type: string): string {
  const white = color === 'w';
  const palette = white
    ? { hair: '#f5d987', shadowHair: '#b98237', outfit: '#f4eee0', accent: '#4e9c76', skin: '#f2c7a7', metal: '#d4b76d' }
    : { hair: '#27334f', shadowHair: '#111827', outfit: '#2b243e', accent: '#d65d78', skin: '#d99b80', metal: '#8da4db' };
  const hair = palette.hair;
  const outfit = palette.outfit;
  const accent = palette.accent;
  const skin = palette.skin;

  const hairShape: Record<string, string> = {
    p: 'M22 34 L17 18 L29 24 L31 8 L41 20 L53 6 L55 23 L67 16 L60 36 Z',
    n: 'M22 32 L17 19 L28 20 L25 9 L39 18 L48 5 L53 19 L66 12 L60 34 Z',
    b: 'M24 34 Q16 18 29 9 Q43 0 58 13 L64 29 L56 24 Q50 35 42 30 L32 25 Z',
    r: 'M22 32 L20 16 L30 20 L30 7 L39 17 L47 7 L50 19 L63 15 L60 35 Z',
    q: 'M22 33 Q14 12 32 8 Q48 0 61 15 L63 37 L56 29 L54 50 L47 41 L43 25 L35 42 L31 29 Z',
    k: 'M22 32 L17 16 L29 21 L34 5 L43 18 L55 5 L55 22 L67 15 L60 35 Z'
  };
  const hairShadow = `<path d="${hairShape[type] ?? hairShape.p}" fill="${palette.shadowHair}" stroke="#172016" stroke-width="2.5" transform="translate(0 2)"/>`;
  const hairFront = `<path d="${hairShape[type] ?? hairShape.p}" fill="${hair}" stroke="#172016" stroke-width="2.5"/>`;
  const headband = ['p', 'n', 'k'].includes(type)
    ? `<path d="M25 27 Q42 32 59 26 L59 32 Q42 38 25 33 Z" fill="${palette.metal}" stroke="#172016" stroke-width="2"/><path d="M37 29 L42 27 L47 30 L42 33 Z" fill="${accent}" stroke="#172016" stroke-width="1.2"/>`
    : '';
  const cheekMarks = type === 'p'
    ? `<path d="M28 41 L34 39 M28 45 L34 43 M50 39 L56 41 M50 43 L56 45" stroke="${accent}" stroke-width="2.2" stroke-linecap="round"/>`
    : type === 'n'
      ? `<path d="M29 42 L35 39 M49 39 L55 42" stroke="${accent}" stroke-width="2.5" stroke-linecap="round"/>`
      : '';
  const headDetail = type === 'q'
    ? `<path d="M28 22 L23 10 L34 17 L40 6 L46 17 L57 10 L53 24 Z" fill="${palette.metal}" stroke="#172016" stroke-width="2"/>`
    : type === 'r'
      ? `<path d="M25 22 V11 H33 V17 H41 V10 H49 V17 H57 V11 H64 V25 Z" fill="${palette.metal}" stroke="#172016" stroke-width="2"/>`
      : type === 'b'
        ? `<path d="M43 7 L49 18 L43 22 L37 18 Z" fill="${palette.metal}" stroke="#172016" stroke-width="2"/>`
        : type === 'k'
          ? `<path d="M31 20 L29 9 L39 16 L44 4 L49 16 L59 8 L56 23 Z" fill="${palette.metal}" stroke="#172016" stroke-width="2"/>`
          : '';
  const crestShape: Record<string, string> = {
    p: '<path d="M0 -7 L5 -1 L0 6 L-5 -1 Z" fill="#f8f4d9"/><circle r="2" fill="#172016"/>',
    n: '<path d="M0 -8 L3 -2 L8 0 L3 2 L0 8 L-3 2 L-8 0 L-3 -2 Z" fill="#f8f4d9"/>',
    b: '<path d="M0 -8 L6 0 L0 8 L-6 0 Z" fill="#f8f4d9"/><path d="M0 -4 V4" stroke="#172016" stroke-width="1.5"/>',
    r: '<path d="M-7 -5 H7 V5 H-7 Z" fill="#f8f4d9"/><path d="M-4 -2 H4 V2 H-4 Z" fill="#172016"/>',
    q: '<path d="M-7 4 L-5 -5 L0 0 L5 -5 L7 4 Z" fill="#f8f4d9"/><circle cy="5" r="1.5" fill="#172016"/>',
    k: '<path d="M-1 -8 H1 V-1 H8 V1 H1 V8 H-1 V1 H-8 V-1 H-1 Z" fill="#f8f4d9"/>'
  };
  const crest = crestShape[type] ?? crestShape.p;
  const weapon = ['p', 'n', 'q'].includes(type)
    ? `<path d="M62 49 L72 24" stroke="${palette.metal}" stroke-width="3.5" stroke-linecap="round"/><path d="M68 21 L75 16 L73 27 Z" fill="#fff5d9"/>`
    : '';
  const cape = `<path d="M22 53 Q12 62 17 79 L42 84 L67 79 Q72 62 62 53 L54 59 L42 65 L30 59 Z" fill="${palette.shadowHair}" stroke="#172016" stroke-width="2"/><path d="M42 68 L49 75 L42 81 L35 75 Z" fill="${accent}" stroke="#172016" stroke-width="1.5"/><g transform="translate(42 75) scale(.72)">${crest}</g>`;
  const armor = ['r', 'b'].includes(type)
    ? `<path d="M27 51 L42 57 L57 51 L54 68 L42 77 L30 68 Z" fill="${accent}" stroke="#172016" stroke-width="2"/>`
    : `<path d="M31 55 L42 64 L53 55 L49 78 L35 78 Z" fill="${accent}" opacity=".95"/>`;
  const signatureCostume = white
    ? `<path d="M29 57 L42 65 L55 57 L51 79 L33 79 Z" fill="#f18a28" stroke="#172016" stroke-width="2"/><path d="M25 27 Q42 32 59 26 L59 33 Q42 39 25 34 Z" fill="#e8e9e6" stroke="#172016" stroke-width="2"/><path d="M36 31 Q42 25 48 31 Q42 37 36 31 Z" fill="#4b8b5a" stroke="#172016" stroke-width="1.2"/><path d="M39 31 Q44 27 46 31 Q43 35 39 31" fill="none" stroke="#f4f0d8" stroke-width="1.2"/>`
    : `<path d="M29 57 L42 65 L55 57 L51 79 L33 79 Z" fill="#c9413b" stroke="#172016" stroke-width="2"/><path d="M17 18 Q42 11 67 18 L64 23 Q42 18 20 23 Z" fill="#d9a94d" stroke="#5b3825" stroke-width="2.5"/><path d="M28 17 Q42 4 56 17 L57 20 L27 20 Z" fill="#e8c46d" stroke="#5b3825" stroke-width="2.5"/><path d="M27 20 Q42 24 57 20" fill="none" stroke="#a94d35" stroke-width="2"/>`;

  return `<svg class="character-sprite ${white ? 'sprite-white' : 'sprite-black'} role-${type}" viewBox="0 0 84 90" aria-hidden="true" focusable="false">
    <ellipse cx="42" cy="84" rx="23" ry="4" fill="#000" opacity=".16"/>
    ${cape}
    <path d="M24 80 Q23 62 31 53 L53 53 Q62 63 60 80 Z" fill="${outfit}" stroke="#172016" stroke-width="2.5"/>
    ${armor}
    ${signatureCostume}
    <rect x="35" y="43" width="14" height="13" rx="5" fill="${skin}"/>
    <path d="M25 32 Q23 12 42 12 Q62 12 59 33 L56 43 Q52 53 42 53 Q31 53 27 42 Z" fill="${skin}" stroke="#172016" stroke-width="2.5"/>
    ${hairShadow}
    ${hairFront}
    ${headband}
    <path d="M29 35 L38 35 M46 35 L55 35" stroke="#172016" stroke-width="3" stroke-linecap="round"/>
    <circle cx="34" cy="39" r="2" fill="#172016"/><circle cx="50" cy="39" r="2" fill="#172016"/>
    <path d="M37 46 Q42 49 47 45" fill="none" stroke="#9c5b4c" stroke-width="2" stroke-linecap="round"/>
    ${cheekMarks}${headDetail}
    ${weapon}
    <path d="M25 59 L17 70 M59 59 L66 69" stroke="${skin}" stroke-width="6" stroke-linecap="round"/>
    <path d="M30 80 L28 85 M54 80 L56 85" stroke="#172016" stroke-width="5" stroke-linecap="round"/>
  </svg>`;
}

function animateCapture(_square: Square, callback: () => void): void {
  // Captures use the same immediate commit path; no delayed visual lock.
  animating = false;
  impactSquare = null;
  callback();
}

function evaluate(): number {
  if (game.isCheckmate()) return game.turn() === 'b' ? 100000 : -100000;
  if (game.isDraw()) return 0;
  let score = 0;
  const board = game.board();
  for (let rankIndex = 0; rankIndex < 8; rankIndex++) {
    for (let fileIndex = 0; fileIndex < 8; fileIndex++) {
      const piece = board[rankIndex][fileIndex];
      if (!piece) continue;
      const sign = piece.color === 'w' ? 1 : -1;
      const rank = piece.color === 'w' ? 7 - rankIndex : rankIndex;
      const center = 3.5 - (Math.abs(fileIndex - 3.5) + Math.abs(rankIndex - 3.5)) / 2;
      let positional = 0;
      if (piece.type === 'p') positional = rank * 7 + Math.max(0, 3 - Math.abs(fileIndex - 3.5)) * 5;
      if (piece.type === 'n') positional = center * 17;
      if (piece.type === 'b') positional = center * 10;
      if (piece.type === 'q') positional = center * 3;
      if (piece.type === 'r') positional = rank * 2 + (rank === 6 ? 12 : 0);
      if (piece.type === 'k') positional = rank < 2 ? 14 : -Math.max(0, 5 - rank) * 8;
      score += sign * ((pieceValue[piece.type] ?? 0) + positional);
    }
  }
  if (activeSearchBot === 'strategist') {
    const allPieces = board.flatMap(row => row.filter(piece => piece !== null));
    const queenCount = allPieces.filter(piece => piece.type === 'q').length;
    for (const color of ['w', 'b'] as const) {
      const sign = color === 'w' ? 1 : -1;
      const bishops = allPieces.filter(piece => piece.color === color && piece.type === 'b').length;
      if (bishops >= 2) score += sign * 32;
      let kingSquare: string | null = null;
      for (let rankIndex = 0; rankIndex < 8; rankIndex++) {
        for (let fileIndex = 0; fileIndex < 8; fileIndex++) {
          const piece = board[rankIndex][fileIndex];
          if (piece?.type === 'k' && piece.color === color) kingSquare = `${files[fileIndex]}${8 - rankIndex}`;
        }
      }
      if (queenCount > 0 && game.history().length >= 10 && kingSquare === (color === 'w' ? 'e1' : 'e8')) score -= sign * 24;
    }
    for (let rankIndex = 0; rankIndex < 8; rankIndex++) {
      for (let fileIndex = 0; fileIndex < 8; fileIndex++) {
        const piece = board[rankIndex][fileIndex];
        if (!piece) continue;
        const rank = 8 - rankIndex;
        const sign = piece.color === 'w' ? 1 : -1;
        if (piece.type === 'p') {
          const isPassed = !board.some((row, enemyRankIndex) => row.some((enemy, enemyFileIndex) => {
            if (enemy?.type !== 'p' || enemy.color === piece.color || Math.abs(enemyFileIndex - fileIndex) > 1) return false;
            const enemyRank = 8 - enemyRankIndex;
            return piece.color === 'w' ? enemyRank > rank : enemyRank < rank;
          }));
          if (isPassed) {
            const advance = piece.color === 'w' ? rank - 1 : 8 - rank;
            score += sign * Math.max(0, advance) * Math.max(0, advance) * 1.8;
          }
        }
        if (piece.type === 'r' && board.every(row => row[fileIndex]?.type !== 'p')) score += sign * 16;
      }
    }
  }
  const mobility = game.moves().length;
  score += (game.turn() === 'w' ? 1 : -1) * Math.min(30, mobility) * 1.4;
  if (game.isCheck()) score += game.turn() === 'w' ? -28 : 28;
  return score;
}

function search(depth: number, alpha: number, beta: number, ply = 0): number {
  searchNodes++;
  if ((searchNodes & 127) === 0 && Date.now() >= searchDeadline) throw SEARCH_TIMEOUT;
  if (game.isCheckmate()) return game.turn() === 'w' ? -100000 + ply : 100000 - ply;
  if (game.isDraw()) return 0;
  if (depth <= 0) return evaluate();
  const moves = game.moves({ verbose: true }).sort((a, b) => {
    const priority = (move: Move) => (move.captured ? 1000 + (pieceValue[move.captured] ?? 0) : 0) + (move.promotion ? 900 : 0) + (move.san.includes('#') ? 100000 : 0) + (move.san.includes('+') ? 120 : 0);
    return priority(b) - priority(a);
  });
  if (game.turn() === 'w') {
    let best = -Infinity;
    for (const move of moves) {
      game.move(move);
      let score: number;
      try { score = search(depth - 1, alpha, beta, ply + 1); }
      finally { game.undo(); }
      best = Math.max(best, score);
      alpha = Math.max(alpha, best);
      if (beta <= alpha) break;
    }
    return best;
  }
  let best = Infinity;
  for (const move of moves) {
    game.move(move);
    let score: number;
    try { score = search(depth - 1, alpha, beta, ply + 1); }
    finally { game.undo(); }
    best = Math.min(best, score);
    beta = Math.min(beta, best);
    if (beta <= alpha) break;
  }
  return best;
}

function strategicBias(move: Move): number {
  const piece = game.get(move.from);
  if (!piece) return 0;
  const sign = piece.color === 'w' ? 1 : -1;
  const file = files.indexOf(move.to[0]);
  const rank = Number(move.to[1]);
  const center = Math.max(0, 4 - (Math.abs(file - 3.5) + Math.abs(rank - 4.5)));
  let score = center * 3.5 * sign;
  if (move.flags.includes('k') || move.flags.includes('q')) score += sign * (game.history().length < 24 ? 55 : 15);
  if (move.promotion) score += sign * 800;
  if (move.san.includes('#')) score += sign * 100000;
  else if (move.san.includes('+')) score += sign * 10;
  if (piece.type === 'n' || piece.type === 'b') {
    const homeRank = piece.color === 'w' ? '1' : '8';
    if (move.from[1] === homeRank) score += sign * 12;
  }
  if (piece.type === 'k' && !move.flags.includes('k') && !move.flags.includes('q') && game.history().length < 20) score -= sign * 18;
  return score;
}

function styleBias(move: Move, bot: BotProfile): number {
  // Scores are from White's perspective, so negative values favor Black.
  const piece = game.get(move.from);
  if (bot.id === 'custom') {
    const sign = piece?.color === 'w' ? 1 : -1;
    const file = files.indexOf(move.to[0]); const rank = Number(move.to[1]);
    const center = Math.max(0, 4 - (Math.abs(file - 3.5) + Math.abs(rank - 4.5)));
    let value = 0;
    if (move.captured) value -= sign * (pieceValue[move.captured] ?? 0) * customBotSettings.aggression * 0.0022;
    if (move.flags.includes('k') || move.flags.includes('q')) value += sign * (game.history().length < 24 ? 40 : 12);
    if (move.san.includes('+')) value -= sign * customBotSettings.aggression * 0.55;
    if (move.san.includes('#')) value -= sign * 100000;
    value -= sign * center * customBotSettings.centerControl * 0.22;
    if (piece?.type === 'k' && !move.flags.includes('k') && !move.flags.includes('q')) value += sign * customBotSettings.kingSafety * 0.18;
    if (piece?.type === 'p' && (rank === 7 || rank === 2)) value -= sign * customBotSettings.positional * 0.12;
    if (piece && ['n', 'b'].includes(piece.type) && ((piece.color === 'w' && move.from[1] === '1') || (piece.color === 'b' && move.from[1] === '8'))) value -= sign * customBotSettings.development * 0.2;
    if (move.captured) value -= sign * customBotSettings.defense * 0.04;
    value += (Math.random() - 0.5) * customBotSettings.randomness * 2.2;
    return value;
  }
  let bias = 0;
  if (move.flags.includes('k') || move.flags.includes('q')) bias += piece?.color === 'w' ? 40 : -40;
  const toFile = files.indexOf(move.to[0]);
  const toRank = Number(move.to[1]);
  const centerDistance = Math.abs(toFile - 3.5) + Math.abs(toRank - 4.5);
  const centerBonus = Math.max(0, 4 - centerDistance) * 5;

  if (bot.id === 'mahoraga') {
    const sign = piece?.color === 'w' ? 1 : -1;
    const centerRate = adaptationPercent(mahoragaMemory.centerMoves);
    const captureRate = adaptationPercent(mahoragaMemory.captures);
    const checkRate = adaptationPercent(mahoragaMemory.checks);
    const queenRushRate = adaptationPercent(mahoragaMemory.queenEarlyMoves);
    // Adaptation changes strategic preferences, while the normal search still evaluates legal moves.
    if (centerRate >= 35) bias += sign * centerBonus * 1.8;
    if (captureRate >= 25 && move.captured) bias += sign * 20;
    if (checkRate >= 18 && (move.flags.includes('k') || move.flags.includes('q'))) bias += sign * 28;
    if (queenRushRate >= 10 && piece && ['n', 'b', 'r'].includes(piece.type)) {
      const queenSquare = game.board().flat().find(square => square?.color === 'w' && square.type === 'q');
      if (queenSquare) {
        const queenFile = files.indexOf(queenSquare.square[0]);
        const queenRank = Number(queenSquare.square[1]);
        const distanceBefore = Math.abs(files.indexOf(move.from[0]) - queenFile) + Math.abs(Number(move.from[1]) - queenRank);
        const distanceAfter = Math.abs(toFile - queenFile) + Math.abs(toRank - queenRank);
        if (distanceAfter < distanceBefore) bias -= sign * Math.min(18, (distanceBefore - distanceAfter) * 4);
      }
    }
    if (mahoragaMemory.moves >= 3) bias += sign * ((mahoragaMemory.lastWheel % 2 === 0) ? 3 : -3);
  }

  if (bot.id === 'blitz') {
    if (move.captured) bias -= (pieceValue[move.captured] ?? 0) * 0.18;
    if (move.san.includes('+') || move.san.includes('#')) bias -= 95;
    if (move.promotion) bias -= 800;
    if (piece && ['n', 'b', 'q'].includes(piece.type)) bias -= 8;
  } else if (bot.id === 'guardian') {
    if (move.captured) bias -= (pieceValue[move.captured] ?? 0) * 0.08;
    if (move.san.includes('+')) bias -= 18;
    if (piece?.type === 'p' && (toRank === 7 || toRank === 2)) bias -= 8;
    if (piece?.type === 'k' && !move.flags.includes('k') && !move.flags.includes('q')) bias += 14;
    bias += centerBonus * 0.25;
  } else if (bot.id === 'scholar') {
    bias -= centerBonus;
    if (piece && ['n', 'b'].includes(piece.type) && move.from[1] === '8') bias -= 16;
    if (move.captured) bias -= (pieceValue[move.captured] ?? 0) * 0.12;
    if (move.san.includes('+')) bias -= 14;
  } else if (bot.id === 'wildcard') {
    bias += (Math.random() - 0.5) * 220;
    if (move.captured) bias -= (pieceValue[move.captured] ?? 0) * 0.1;
  } else if (bot.id === 'rookie') {
    bias += (Math.random() - 0.5) * 240;
  }
  if (bot.id === 'grandmaster' || bot.id === 'mastermind' || bot.id === 'scholar') {
    const file = files.indexOf(move.to[0]);
    const rank = Number(move.to[1]);
    const center = Math.max(0, 4 - (Math.abs(file - 3.5) + Math.abs(rank - 4.5)));
    if (move.san.includes('#')) bias += piece?.color === 'w' ? -100000 : 100000;
    else if (move.san.includes('+')) bias += piece?.color === 'w' ? -16 : 16;
    if (bot.id === 'grandmaster') {
      if (gameStrategy === 'center') bias += (piece?.color === 'w' ? -1 : 1) * center * 3.2;
      if (gameStrategy === 'kingside' && file >= 5) bias += piece?.color === 'w' ? -7 : 7;
      if (gameStrategy === 'queenside' && file <= 2) bias += piece?.color === 'w' ? -7 : 7;
      if (gameStrategy === 'solid' && piece?.type === 'k' && !move.flags.includes('k') && !move.flags.includes('q')) bias += piece.color === 'w' ? 18 : -18;
      if (gameStrategy === 'endgame' && piece?.type === 'k') bias += piece.color === 'w' ? -4 : 4;
    }
  }
  const sideSign = piece?.color === 'w' ? 1 : -1;
  const className = bot.className ?? 'Strategic';
  if (className === 'Aggressive') { if (move.captured) bias += sideSign * 18; if (move.san.includes('+')) bias += sideSign * 24; if (move.promotion) bias += sideSign * 80; }
  else if (className === 'Tactical') { if (move.captured) bias += sideSign * ((pieceValue[move.captured] ?? 0) * 0.08); if (move.san.includes('+')) bias += sideSign * 18; if (move.san.includes('#')) bias += sideSign * 100000; }
  else if (className === 'Defensive') { if (move.flags.includes('k') || move.flags.includes('q')) bias += sideSign * 32; if (piece?.type === 'k' && !move.flags.includes('k') && !move.flags.includes('q')) bias -= sideSign * 24; }
  else if (className === 'Strategic') { const center = Math.max(0, 4 - (Math.abs(files.indexOf(move.to[0]) - 3.5) + Math.abs(Number(move.to[1]) - 4.5))); bias += sideSign * center * 4; }
  else if (className === 'Trickster') { if (move.san.includes('+') || move.captured) bias += sideSign * 14; bias += (Math.random() - 0.5) * 8; }
  else if (className === 'Endgame') { if (piece?.type === 'k') bias += sideSign * (game.history().length > 40 ? 14 : -3); if (piece?.type === 'p' && (move.to[1] === '7' || move.to[1] === '2')) bias += sideSign * 18; }
  else if (className === 'Legends') { if (move.san.includes('#')) bias += sideSign * 100000; if (move.promotion) bias += sideSign * 100; if (move.flags.includes('k') || move.flags.includes('q')) bias += sideSign * 28; if (move.captured) bias += sideSign * ((pieceValue[move.captured] ?? 0) * 0.04); }
  else if (className === 'Pro') { if (move.captured) bias += sideSign * ((pieceValue[move.captured] ?? 0) * 0.04); if (move.flags.includes('k') || move.flags.includes('q')) bias += sideSign * 25; }
  if (bot.id === 'hikaru') {
    const sign = piece?.color === 'w' ? 1 : -1;
    if (move.captured) bias += sign * ((pieceValue[move.captured] ?? 0) * 0.10);
    if (move.san.includes('+')) bias += sign * 22;
    if (move.san.includes('#')) bias += sign * 100000;
    if (piece && ['n', 'b', 'r', 'q'].includes(piece.type)) bias += sign * centerBonus * 0.65;
    if (move.flags.includes('k') || move.flags.includes('q')) bias += sign * 18;
    if (game.history().length < 30 && piece?.type === 'q' && !move.captured && !move.san.includes('+')) bias -= sign * 12;
  }
  return bias;
}

function beginChessReplay(moves: string[]): void {
  if (chessReplayTimer !== null) window.clearInterval(chessReplayTimer);
  chessReplayMoves = moves.slice();
  chessReplayIndex = 0;
  chessReplayActive = true;
  chessReplayPaused = false;
  dismissedResultForCurrentGame = true;
  lastMove = null;
  selected = null;
  targets = [];
  thinking = false;
  animating = false;
  turnToken++;
  game.reset();
  render();
  chessReplayTimer = window.setInterval(() => {
    if (chessReplayPaused || !chessReplayActive) return;
    if (chessReplayIndex < chessReplayMoves.length) {
      try { const move = game.move(chessReplayMoves[chessReplayIndex]); lastMove = { from: move.from, to: move.to }; chessReplayIndex++; render(); }
      catch { if (chessReplayTimer !== null) window.clearInterval(chessReplayTimer); chessReplayTimer = null; chessReplayActive = false; render(); }
    } else { if (chessReplayTimer !== null) window.clearInterval(chessReplayTimer); chessReplayTimer = null; chessReplayActive = false; render(); }
  }, 850);
}
function finishGame(): void {
  if (game.isCheckmate()) {
    note = gameMode === 'local'
      ? (game.turn() === 'w' ? 'Checkmate. Black wins!' : 'Checkmate. White wins!')
      : (game.turn() === 'w' ? 'Checkmate. Black wins this round.' : 'Checkmate. You win!');
  } else if (game.isStalemate()) note = 'Stalemate. It is a draw.';
  else if (game.isThreefoldRepetition()) note = 'Draw by repetition.';
  else if (game.isInsufficientMaterial()) note = 'Draw by insufficient material.';
  else if (game.isDraw()) note = 'Draw game.';
  saveCompletedMatch();
  const playerWon = (game.isCheckmate() && game.turn() === 'b') || clockFlagged === 'b';
  const eligibleMode = ['bot', 'gemini', 'trainer', 'lasting'].includes(gameMode);
  if (playerWon && eligibleMode && !vuzzAwardedForGame) {
    const opponent = bots.find(profile => profile.id === selectedBot) ?? bots[0];
    const reward = gameMode === 'gemini' ? 60 : opponent.className === 'Legends' ? 160 : opponent.className === 'Pro' ? 100 : 30 + opponent.depth * 8;
    vuzzBalance += reward;
    vuzzAwardedForGame = true;
    saveEconomy();
    note += ` · +${reward} Vuzz`;
  }
}

function computerMove(): void {
  const side = game.turn();
  if (gameMode !== 'battle' && side === playerColor) return;
  if (game.isGameOver()) {
    finishGame();
    render();
    return;
  }
  thinking = true;
  const thisTurn = ++turnToken;
  const bot = botForSide(side);
  activeSearchBot = bot.id;
  const thinkingStartedAt = Date.now();
  const legalAtStart = game.moves({ verbose: true });
  const tacticalPressure = legalAtStart.some(move => Boolean(move.captured) || move.san.includes('+') || move.san.includes('#'));
  const baseBudget = bot.id === 'custom' ? customBotSettings.thinkSeconds * 1000 : (thinkingBudgets[bot.id] ?? Math.min(10000, Math.max(500, bot.depth * 650)));
  const isHighDifficulty = ['ULTIMATE', 'ELITE', 'MASTER', 'EXPERT', 'INSANE'].includes(bot.difficulty) || bot.difficulty.startsWith('LEGEND');
  const difficultyFactor = bot.id === 'human-style' ? 0.7 : bot.difficulty === 'EASY' || bot.difficulty === 'MEDIUM' ? 0.55 : isHighDifficulty ? 1 : 0.78;
  const positionFactor = game.isCheck() ? 1.65 : tacticalPressure ? 1.25 : legalAtStart.length < 12 ? 1.1 : 0.68;
  const thinkingBudget = Math.max(250, Math.min(10000, Math.round(baseBudget * difficultyFactor * positionFactor)));
  searchDeadline = thinkingStartedAt + thinkingBudget;
  searchNodes = 0;
  note = `${side === 'w' ? 'White' : 'Black'} · ${bot.name} calculating… Depth 1${bot.id === 'grandmaster' ? ` · ${strategyNames[gameStrategy]}` : ''}`;
  render();

  window.setTimeout(() => {
    if (thisTurn !== turnToken || game.turn() !== side || game.isGameOver()) return;
    const moves = game.moves({ verbose: true });
    if (!moves.length) {
      thinking = false;
      finishGame();
      render();
      return;
    }

    const staticScores = moves.map(move => {
      const bias = styleBias(move, bot);
      game.move(move);
      const score = evaluate() + bias;
      game.undo();
      return { move, score };
    });
    let completedScores = staticScores;
    let iterationScores: Array<{ move: Move; score: number }> = [];
    let depth = 1;
    let index = 0;
    let iterationComplete = false;
    const finishThinking = () => {
      if (thisTurn !== turnToken || game.turn() !== side || game.isGameOver()) return;
      if (clockFlagged) return;
      const scored = completedScores;
      const bestScore = side === 'w' ? Math.max(...scored.map(item => item.score)) : Math.min(...scored.map(item => item.score));
      const candidates = scored.filter(item => side === 'w' ? item.score >= bestScore - bot.mistakeMargin : item.score <= bestScore + bot.mistakeMargin);
      let choice: { move: Move; score: number } | undefined;
      if (bot.id === 'strategist' || bot.id === 'chatgpt-style') {
        const ranked = [...scored].sort((a, b) => side === 'w' ? b.score - a.score : a.score - b.score);
        choice = ranked[0];
      } else if (bot.id === 'rookie') {
        choice = candidates[Math.floor(Math.random() * candidates.length)];
      } else if (bot.id === 'wildcard') {
        const widerPool = scored.filter(item => side === 'w' ? item.score >= bestScore - 520 : item.score <= bestScore + 520);
        choice = widerPool[Math.floor(Math.random() * widerPool.length)];
      } else if (bot.id === 'human-style') {
        const naturalPool = candidates.filter(item => Math.random() > 0.18);
        const pool = naturalPool.length ? naturalPool : candidates;
        choice = pool[Math.floor(Math.random() * pool.length)];
      } else {
        choice = candidates[Math.floor(Math.random() * candidates.length)];
      }

      if (choice) {
        syncClock();
        if (clockFlagged) { thinking = false; render(); return; }
        const played = game.move({ from: choice.move.from, to: choice.move.to, promotion: 'q' });
        lastMove = { from: played.from, to: played.to };
        scheduleChessMoveAnimation(played.from, played.to);
        selected = null;
        targets = [];
        if (played.captured || played.flags.includes('e')) {
          animateCapture(played.to, () => {
            thinking = false;
            if (tryExecuteQueuedPremove()) return;
            finishGame();
            if (gameMode === 'lasting' && game.history().length >= 40 && !game.isGameOver()) {
              lastingKingComplete = true;
              note = 'LASTING KING CLEARED! You survived 20 full moves against Grandmaster.';
              render();
              return;
            }
            if (!game.isGameOver()) {
              if (game.turn() === playerColor) note = game.isCheck() ? 'Check! Your king is under attack.' : 'Your move.';
              else note = game.isCheck() ? 'Check! King under attack.' : `${side === 'w' ? 'White' : 'Black'} · ${bot.name} played.`;
            }
            render();
            if ((gameMode === 'battle' || ((gameMode === 'bot' || gameMode === 'trainer' || gameMode === 'lasting') && game.turn() !== playerColor)) && !game.isGameOver() && !clockFlagged) {
              window.setTimeout(computerMove, 260);
            }
          });
          return;
        }
      }
      thinking = false;
      selected = null;
      targets = [];
      if (tryExecuteQueuedPremove()) return;
      finishGame();
      if (gameMode === 'lasting' && game.history().length >= 40 && !game.isGameOver()) {
        lastingKingComplete = true;
        note = 'LASTING KING CLEARED! You survived 20 full moves against Grandmaster.';
        render();
        return;
      }
      if (!game.isGameOver()) {
        if (gameMode === 'local') note = game.turn() === 'w' ? 'White to move. Pass the device to Player 1.' : 'Black to move. Pass the device to Player 2.';
        else if (game.turn() === playerColor) note = game.isCheck() ? 'Check! Your king is under attack.' : 'Your move.';
        else note = game.isCheck() ? 'Check! King under attack.' : `${side === 'w' ? 'White' : 'Black'} · ${bot.name} played.`;
      }
      render();
      if ((gameMode === 'battle' || ((gameMode === 'bot' || gameMode === 'trainer' || gameMode === 'lasting') && game.turn() !== playerColor)) && !game.isGameOver() && !clockFlagged) {
        window.setTimeout(computerMove, 260);
      }
    };

    const scoreNextMove = () => {
      if (thisTurn !== turnToken || game.turn() !== side || game.isGameOver()) return;
      if (Date.now() >= searchDeadline) {
        finishThinking();
        return;
      }
      const move = moves[index];
      if (move) {
        const bias = bot.id === 'strategist' ? strategicBias(move) : styleBias(move, bot);
        game.move(move);
        let score: number | null = null;
        try {
          score = search(depth - 1, -Infinity, Infinity) + bias;
        } catch (error) {
          if (error !== SEARCH_TIMEOUT) throw error;
        } finally {
          game.undo();
        }
        if (score === null) {
          finishThinking();
          return;
        }
        iterationScores.push({ move, score });
        index++;
      }
      if (index < moves.length) {
        if (Date.now() >= searchDeadline) finishThinking();
        else window.setTimeout(scoreNextMove, 0);
        return;
      }
      completedScores = iterationScores;
      iterationComplete = true;
      if (Date.now() >= searchDeadline || depth >= (bot.id === 'custom' ? customBotSettings.depth : (searchDepthCaps[bot.id] ?? bot.depth))) {
        finishThinking();
        return;
      }
      depth++;
      index = 0;
      iterationScores = [];
      note = `${bot.name} calculating… Depth ${depth} · ${searchNodes.toLocaleString()} positions${bot.id === 'grandmaster' ? ` · ${strategyNames[gameStrategy]}` : ''}`;
      updateStatusNote();
      window.setTimeout(scoreNextMove, 0);
    };

    // Keep the last fully scored iteration if the budget expires mid-iteration.
    window.setTimeout(() => {
      if (!iterationComplete && completedScores === staticScores && Date.now() >= searchDeadline) finishThinking();
    }, thinkingBudget + 30);
    window.setTimeout(scoreNextMove, 0);
  }, 0);
}

function afterMove(): void {
  const preset = clockPresets.find(item => item.id === clockPreset) ?? clockPresets[3];
  if (!clockFlagged && preset.increment > 0) {
    if (game.turn() === 'b') whiteTimeMs += preset.increment * 1000;
    else blackTimeMs += preset.increment * 1000;
  }
  clockLastTick = Date.now();
  finishGame();
  if (gameMode === 'lasting' && game.history().length >= 40 && !game.isGameOver()) {
    lastingKingComplete = true;
    note = 'LASTING KING CLEARED! You survived 20 full moves against Grandmaster.';
    render();
    return;
  }
  if (game.isGameOver() || (gameMode === 'lasting' && lastingKingComplete)) { render(); return; }
  if ((gameMode === 'bot' && game.turn() !== playerColor) || gameMode === 'battle' || gameMode === 'trainer' || gameMode === 'lasting') {
    computerMove();
    return;
  }
  if (gameMode === 'gemini' && game.turn() === 'b') {
    requestGeminiMove();
    return;
  }
  note = gameMode === 'local'
    ? (game.turn() === 'w' ? 'White to move. Pass the device to Player 1.' : 'Black to move. Pass the device to Player 2.')
    : gameMode === 'trainer' ? trainerFeedback : 'Your move.';
  render();
}

function voxBotProfile(): BotProfile {
  const level = voxLevel;
  const configs: Record<VoxLevel, { depth: number; mistakeMargin: number; difficulty: string }> = {
    easy: { depth: 2, mistakeMargin: 180, difficulty: 'EASY' },
    normal: { depth: 4, mistakeMargin: 40, difficulty: 'MEDIUM' },
    hard: { depth: 5, mistakeMargin: 12, difficulty: 'HARD' },
    expert: { depth: 7, mistakeMargin: 0, difficulty: 'EXPERT' },
    master: { depth: 9, mistakeMargin: 0, difficulty: 'MASTER' },
  };
  const cfg = configs[level] ?? configs.normal;
  return {
    id: 'chatgpt-style',
    name: 'Vox',
    title: 'Local Vox Engine',
    style: 'Offline adaptive play tuned by difficulty',
    difficulty: cfg.difficulty,
    depth: cfg.depth,
    mistakeMargin: cfg.mistakeMargin,
    icon: '✦',
    className: 'Strategic',
    description: 'Fully offline Vox powered by the CHEZZ local engine. No API key or backend required.',
  };
}

function checkGeminiStatus(): void {
  geminiConfigured = true;
  geminiStatusChecked = true;
  if (gameMode === 'gemini') render();
}

function requestGeminiMove(): void {
  // Vox is fully local now — reuse the same search engine as other bots.
  computerMove();
}

function makePlayerMove(from: Square, to: Square, promotion?: 'q' | 'r' | 'b' | 'n'): void {
  try {
    syncClock();
    if (clockFlagged) { note = 'Time expired. Start a new game to play again.'; render(); return; }
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (gameMode === 'trainer') trainerFeedback = move.san.includes('#') ? 'Excellent! You found checkmate. Notice how your pieces coordinate to finish the king.' : move.captured ? `Good capture with ${move.san}. Check whether your own pieces are defended and whether the opponent has a forcing reply.` : move.san.includes('+') ? `Check! ${move.san} forces the king to respond. Look for checks, captures, and threats in that order.` : `You played ${move.san}. Trainer tip: scan for checks, captures, threats, king safety, and undefended pieces before choosing your next move.`;
    observePlayerMove(move);
    lastMove = { from: move.from, to: move.to };
    scheduleChessMoveAnimation(move.from, move.to);
    selected = null;
    targets = [];
    pendingPromotion = null;
    if (move.captured || move.flags.includes('e')) {
      animateCapture(move.to, afterMove);
      return;
    }
    afterMove();
    return;
  } catch {
    pendingPromotion = null;
    note = 'That move is not legal.';
  }
  render();
}

function onSquare(square: Square): void {
  const previewDuringThink = thinking && ((gameMode === 'bot' && game.turn() !== playerColor) || gameMode === 'battle');
  if ((thinking && !previewDuringThink) || animating || pendingPromotion || game.isGameOver() || clockFlagged || chessReplayActive) return;
  const piece = game.get(square);

  if (queuedPremove && square === queuedPremove.from && previewDuringThink) {
    queuedPremove = null;
    selected = null;
    targets = [];
    note = 'Premove cancelled.';
    render();
    return;
  }

  if (selected && targets.includes(square)) {
    const movingPiece = game.get(selected);
    if (gameMode === 'battle' && thinking) {
      note = `Analysis preview: ${movingPiece?.color === 'w' ? 'White' : 'Black'} could move ${selected} to ${square}. Bot battle continues automatically.`;
      render();
      return;
    }
    // In a bot match, the AI owns every piece opposite the player's chosen color.
    // Never allow an AI-side piece to be committed through taps, drags, or thinking previews.
    if (gameMode === 'bot' && movingPiece && movingPiece.color !== playerColor) {
      selected = null;
      targets = [];
      note = `That ${movingPiece.color === 'w' ? 'White' : 'Black'} piece belongs to the bot. Move only your ${playerColor === 'w' ? 'White' : 'Black'} pieces.`;
      render();
      return;
    }
    if (movingPiece && movingPiece.color !== game.turn()) {
      if (gameMode === 'bot' && thinking && movingPiece.color === playerColor) {
        queuedPremove = { from: selected, to: square, ...(movingPiece.type === 'p' && (square[1] === '8' || square[1] === '1') ? { promotion: 'q' as const } : {}) };
        selected = null;
        targets = [];
        note = `Premove queued: ${queuedPremove.from} → ${queuedPremove.to}. It will play automatically if it is still legal after the bot moves. Tap the origin square to cancel.`;
        render();
        return;
      }
      note = `Preview only. ${movingPiece.color === 'w' ? 'White' : 'Black'} could move there, but it is ${game.turn() === 'w' ? 'White' : 'Black'}'s turn.`;
      render();
      return;
    }
    // Final turn ownership guard, including the AI's thinking window.
    if (gameMode === 'bot' && (movingPiece?.color !== playerColor || game.turn() !== playerColor)) {
      selected = null;
      targets = [];
      note = 'Wait for your turn. The bot controls the opposite side.';
      render();
      return;
    }
    if (movingPiece?.type === 'p' && (square[1] === '8' || square[1] === '1')) {
      pendingPromotion = { from: selected, to: square };
      note = 'Choose your promotion character.';
      render();
      return;
    }
    makePlayerMove(selected, square);
    return;
  } else if (piece) {
    if (gameMode === 'bot' && piece.color !== playerColor && thinking) {
      // Bot pieces can be inspected, but are never draggable while the AI is thinking.
      selected = square;
      targets = legalTargetsForPiece(square, piece.color);
      note = 'Bot piece preview only. You cannot move the AI’s pieces.';
      render();
      return;
    }
    if (queuedPremove && previewDuringThink) queuedPremove = null;
    selected = square;
    targets = legalTargetsForPiece(square, piece.color);
    if (piece.color !== game.turn()) {
      note = targets.length
        ? gameMode === 'bot' && thinking && piece.color === playerColor
          ? `Premove preview: ${pieceName[piece.type]} can move to the highlighted squares. Choose a target to queue it.`
          : `Preview only: ${piece.color === 'w' ? 'White' : 'Black'} ${pieceName[piece.type]} legal moves. It is ${game.turn() === 'w' ? 'White' : 'Black'}'s turn.`
        : 'Preview only: this piece has no legal moves in the current position.';
    } else {
      const side = piece.color === 'w' ? 'White' : 'Black';
      note = targets.length ? `Selected ${side} ${pieceName[piece.type]}. Choose a highlighted square.` : 'That piece has no legal moves.';
    }
  } else {
    selected = null;
    targets = [];
    note = gameMode === 'local'
      ? `Select a ${game.turn() === 'w' ? 'white' : 'black'} piece for this turn.`
      : `Select one of your ${playerColor === 'w' ? 'white' : 'black'} pieces.`;
  }
  render();
}

function checkerResetBoard(): void {
  checkerHint = null;
  checkerBoard = Array(64).fill(null);
  for (let row = 0; row < 3; row++) for (let col = 0; col < 8; col++) if ((row + col) % 2 === 1) checkerBoard[row * 8 + col] = 'b';
  for (let row = 5; row < 8; row++) for (let col = 0; col < 8; col++) if ((row + col) % 2 === 1) checkerBoard[row * 8 + col] = 'w';
  checkerTurn = 'w'; checkerSelected = null; checkerChainSquare = null;
  checkerLastMove = null; checkerReplayFrames = [checkerBoard.slice()]; checkerReplayBoard = null; checkerReplayIndex = 0; checkerReplayPaused = false;
  if (checkerReplayTimer !== null) window.clearInterval(checkerReplayTimer); checkerReplayTimer = null;
  checkerNote = checkerMode === 'local' ? 'White moves first. Pass the device after your turn.' : `New game vs ${checkerBots.find(bot => bot.id === checkerBotId)?.name ?? 'Tactician'}. White starts.`;
}
type CheckerMove = { from: number; to: number; capture: number | null };
type CheckerSearchBudget = { nodes: number; maxNodes: number };

function checkerMovesFor(index: number, board = checkerBoard, side: 'w' | 'b' = checkerTurn): CheckerMove[] {
  const piece = board[index];
  if (!piece || piece.toLowerCase() !== side) return [];
  const row = Math.floor(index / 8), col = index % 8;
  const dirs = piece === 'W' || piece === 'B' ? [-1, 1] : piece === 'w' ? [-1] : [1];
  const moves: CheckerMove[] = [];
  for (const dr of dirs) for (const dc of [-1, 1]) {
    const nr = row + dr, nc = col + dc;
    if (nr < 0 || nr > 7 || nc < 0 || nc > 7) continue;
    const next = nr * 8 + nc;
    if (!board[next]) moves.push({ from: index, to: next, capture: null });
    else if (board[next]!.toLowerCase() !== side) {
      const jr = row + dr * 2, jc = col + dc * 2;
      if (jr >= 0 && jr < 8 && jc >= 0 && jc < 8 && !board[jr * 8 + jc]) moves.push({ from: index, to: jr * 8 + jc, capture: next });
    }
  }
  return moves;
}
function checkerLegalMoves(side: 'w' | 'b' = checkerTurn, board = checkerBoard, forcedFrom: number | null = null): CheckerMove[] {
  const indices = forcedFrom === null ? board.map((piece,index) => piece && piece.toLowerCase() === side ? index : -1).filter(index => index >= 0) : [forcedFrom];
  const moves = indices.flatMap(index => checkerMovesFor(index,board,side));
  if (forcedFrom !== null) return moves.filter(move => move.capture !== null);
  const captures = moves.filter(move => move.capture !== null);
  return captures.length ? captures : moves;
}
function checkerCount(color: 'w' | 'b'): number { return checkerBoard.filter(piece => piece && piece.toLowerCase() === color).length; }
function checkerApply(move: CheckerMove): void {
  if (checkerReplayBoard) return;
  checkerHint = null;
  checkerThinking = false;
  const piece = checkerBoard[move.from];
  if (!piece) return;
  checkerLastMove = { from: move.from, to: move.to };
  checkerBoard[move.from] = null; checkerBoard[move.to] = piece;
  if (move.capture !== null) checkerBoard[move.capture] = null;
  const row = Math.floor(move.to / 8);
  const crownedNow = (piece === 'w' && row === 0) || (piece === 'b' && row === 7);
  if (piece === 'w' && row === 0) checkerBoard[move.to] = 'W';
  if (piece === 'b' && row === 7) checkerBoard[move.to] = 'B';
  if (move.capture !== null && !crownedNow) {
    checkerSelected = move.to;
    checkerTurn = piece.toLowerCase() as 'w' | 'b';
    if (checkerMovesFor(move.to,checkerBoard,checkerTurn).some(next => next.capture !== null)) {
      checkerChainSquare = move.to;
      checkerNote = 'Combo jump! Continue with the same glowing piece.';
      render();
      if (checkerMode === 'bot' && checkerTurn === 'b') { checkerThinking = true; const bn = checkerBots.find(b => b.id === checkerBotId)?.name ?? 'Bot'; checkerNote = `${bn} is calculating…`; render(); window.setTimeout(checkerBotMove, 280); }
      return;
    }
  }
  checkerChainSquare = null; checkerSelected = null;
  checkerTurn = checkerTurn === 'w' ? 'b' : 'w';
  checkerReplayFrames.push(checkerBoard.slice());
  const white = checkerCount('w'), black = checkerCount('b');
  if (!white || !black || !checkerLegalMoves().length) {
    checkerNote = !white ? 'Black wins! White has no pieces left.' : !black ? 'White wins! Black has no pieces left.' : checkerTurn === 'w' ? 'Black wins! White has no legal moves.' : 'White wins! Black has no legal moves.';
    render(); return;
  }
  checkerNote = checkerMode === 'local' ? `${checkerTurn === 'w' ? 'White' : 'Black'} to move. Pass the device.` : checkerTurn === 'w' ? 'Your turn, White.' : `${checkerBots.find(bot => bot.id === checkerBotId)?.name ?? 'Tactician'} is thinking…`;
  render();
  if (checkerMode === 'bot' && checkerTurn === 'b') { checkerThinking = true; const bn = checkerBots.find(b => b.id === checkerBotId)?.name ?? 'Bot'; checkerNote = `${bn} is calculating…`; render(); window.setTimeout(checkerBotMove, 420); }
}
function checkerEvaluate(board: Array<string | null>): number {
  let score = 0;
  let whiteMen = 0, blackMen = 0, whiteKings = 0, blackKings = 0;
  // Material + positional
  for (let index = 0; index < 64; index++) {
    const piece = board[index];
    if (!piece) continue;
    const side = piece.toLowerCase() as 'w' | 'b';
    const row = Math.floor(index / 8);
    const col = index % 8;
    const king = piece === 'W' || piece === 'B';
    const progress = side === 'b' ? row : 7 - row;
    const center = 3.5 - Math.abs(col - 3.5);
    if (side === 'w') { if (king) whiteKings++; else whiteMen++; }
    else { if (king) blackKings++; else blackMen++; }

    let value = king ? 280 : 100;
    // Advancement for men (runaway path value)
    if (!king) value += progress * 8 + (progress >= 5 ? 18 : progress >= 4 ? 10 : 0);
    // Kings love the center and mobility corridors
    if (king) value += center * 9 + (row >= 2 && row <= 5 ? 12 : 0);
    else value += center * 4;
    // Hold the back rank (prevent easy crowning)
    if (!king && (side === 'b' ? row === 0 : row === 7)) value += 22;
    // Near-promotion pressure
    if (!king && (side === 'b' ? row === 6 : row === 1)) value += 20;
    // Edge is safer for men, weaker for active kings midgame
    if (col === 0 || col === 7) value += king ? 2 : 7;
    // Dog-hole / weak square avoidance simplified: pieces on very forward edges without support
    score += side === 'b' ? value : -value;
  }
  // Light mobility proxy (avoid full move-gen on every leaf — was freezing UI)
  let blackLoose = 0, whiteLoose = 0;
  for (let i = 0; i < 64; i++) {
    const p = board[i];
    if (!p) continue;
    const r = Math.floor(i / 8), c = i % 8;
    const s = p.toLowerCase();
    const dirs = (p === 'W' || p === 'B') ? [-1, 1] : s === 'w' ? [-1] : [1];
    for (const dr of dirs) for (const dc of [-1, 1]) {
      const nr = r + dr, nc = c + dc;
      if (nr < 0 || nr > 7 || nc < 0 || nc > 7) continue;
      if (!board[nr * 8 + nc]) { if (s === 'b') blackLoose++; else whiteLoose++; }
    }
  }
  score += (blackLoose - whiteLoose) * 4;
  // Tempo / opposition when kings dominate
  if (whiteKings + blackKings >= 2 && whiteMen + blackMen <= 4) {
    score += (blackKings - whiteKings) * 35;
    score += (blackMoves - whiteMoves) * 4;
  }
  // Trade when ahead in material (simplified)
  const blackMat = blackMen * 100 + blackKings * 280;
  const whiteMat = whiteMen * 100 + whiteKings * 280;
  if (blackMat > whiteMat + 80) score += 15;
  if (whiteMat > blackMat + 80) score -= 15;
  // No-move terminal already handled in search
  return score;
}
function checkerSimulateMove(board: Array<string|null>,move: CheckerMove,side:'w'|'b'):{board:Array<string|null>;followUp:boolean;crowned:boolean} {
  const next=board.slice(), piece=next[move.from];
  if (!piece) return {board:next,followUp:false,crowned:false};
  next[move.from]=null; next[move.to]=piece;
  if (move.capture!==null) next[move.capture]=null;
  const row=Math.floor(move.to/8), crowned=(piece==='w'&&row===0)||(piece==='b'&&row===7);
  if (piece==='w'&&row===0) next[move.to]='W';
  if (piece==='b'&&row===7) next[move.to]='B';
  const followUp=move.capture!==null&&!crowned&&checkerMovesFor(move.to,next,side).some(candidate=>candidate.capture!==null);
  return {board:next,followUp,crowned};
}
function checkerMoveOrderScore(move: CheckerMove, board: Array<string | null>): number {
  const piece = board[move.from];
  const row = Math.floor(move.to / 8);
  const crown = piece && ((piece === 'w' && row === 0) || (piece === 'b' && row === 7)) ? 320 : 0;
  const victim = move.capture === null ? 0 : (board[move.capture] === 'W' || board[move.capture] === 'B' ? 240 : 110);
  // Prefer multi-jump potential destinations slightly (central landing)
  const centerBias = 4 - Math.abs(move.to % 8 - 3.5);
  return (move.capture === null ? 0 : 700 + victim) + crown + centerBias * 3;
}
function checkerSearch(board:Array<string|null>,side:'w'|'b',depth:number,alpha:number,beta:number,forcedFrom:number|null,budget:CheckerSearchBudget):number {
  budget.nodes++;
  const moves=checkerLegalMoves(side,board,forcedFrom);
  if (!moves.length) return side==='b'?-50000-depth:50000+depth;
  if ((depth<=0&&forcedFrom===null)||budget.nodes>=budget.maxNodes) return checkerEvaluate(board);
  const maximizing=side==='b';
  const ordered=moves.slice().sort((a,b)=>checkerMoveOrderScore(b,board)-checkerMoveOrderScore(a,board));
  let best=maximizing?-Infinity:Infinity;
  for (const move of ordered) {
    const result=checkerSimulateMove(board,move,side);
    const nextSide=result.followUp?side:side==='b'?'w':'b';
    const value=checkerSearch(result.board,nextSide,depth-1,alpha,beta,result.followUp?move.to:null,budget);
    if (maximizing) {best=Math.max(best,value);alpha=Math.max(alpha,best);}
    else {best=Math.min(best,value);beta=Math.min(beta,best);}
    if (beta<=alpha||budget.nodes>=budget.maxNodes) break;
  }
  return best;
}
function checkerBotMove(): void {
  if (activeGame !== 'checkers' || checkerMode !== 'bot' || checkerTurn !== 'b') return;
  const moves = checkerLegalMoves('b', checkerBoard, checkerChainSquare);
  if (!moves.length) { checkerNote = 'White wins! Black has no legal moves.'; checkerThinking = false; render(); return; }
  const botName = checkerBots.find(b => b.id === checkerBotId)?.name ?? 'Bot';
  if (checkerBotId === 'rookie' || checkerBotId === 'trickster' || checkerBotId === 'scout') {
    const noise=checkerBotId==='rookie'?260:checkerBotId==='trickster'?180:90;
    const scored=moves.map(move=>{const result=checkerSimulateMove(checkerBoard,move,'b');return {move,score:checkerEvaluate(result.board)+(move.capture!==null?180:0)+Math.random()*noise};}).sort((a,b)=>b.score-a.score);
    checkerApply(scored[0]?.move??moves[0]);return;
  }

  // Iterative deepening keeps the best fully searched move if a deeper pass reaches its budget.
  checkerThinking = true;
  checkerNote = `${botName} is calculating…`;
  render();
  // Yield one frame so the UI can show thinking state
  // (search still runs sync for strength)
    const maxDepth = checkerBotId === 'tinsley' ? 12 : checkerBotId === 'chinook' ? 11 : checkerBotId === 'nightmare' ? 10 : checkerBotId === 'grandmaster' ? 9 : checkerBotId === 'master' ? 8 : checkerBotId === 'strategist' || checkerBotId === 'veteran' ? 7 : checkerBotId === 'raider' || checkerBotId === 'guardian' ? 6 : 5;
  const perPassNodes = checkerBotId === 'tinsley' ? 55000 : checkerBotId === 'chinook' ? 48000 : checkerBotId === 'nightmare' ? 40000 : checkerBotId === 'grandmaster' ? 32000 : checkerBotId === 'master' ? 28000 : 24000;
  const totalNodeLimit = checkerBotId === 'tinsley' ? 180000 : checkerBotId === 'chinook' ? 150000 : checkerBotId === 'nightmare' ? 120000 : checkerBotId === 'grandmaster' ? 165000 : checkerBotId === 'master' ? 135000 : 105000;
  const ordered=moves.slice().sort((a,b)=>checkerMoveOrderScore(b,checkerBoard)-checkerMoveOrderScore(a,checkerBoard));
  let totalNodes=0;
  let bestCompleted:CheckerMove[]=ordered.length?[ordered[0]]:[];
  for (let depth=1;depth<=maxDepth&&totalNodes<totalNodeLimit;depth++) {
    const budget:CheckerSearchBudget={nodes:0,maxNodes:Math.min(perPassNodes,totalNodeLimit-totalNodes)};
    let iterationBestScore=-Infinity;
    let iterationBest:CheckerMove[]=[];
    let alpha=-Infinity;
    let complete=true;
    for (let i=0;i<ordered.length;i++) {
      const move=ordered[i];
      const result=checkerSimulateMove(checkerBoard,move,'b');
      const score=checkerSearch(result.board,result.followUp?'b':'w',depth-1,alpha,Infinity,result.followUp?move.to:null,budget);
      const bonus = checkerBotId === 'raider' ? (7 - Math.floor(move.to / 8)) * 1.5
        : checkerBotId === 'guardian' && move.capture === null ? 3
        : (checkerBotId === 'tinsley' || checkerBotId === 'chinook') && move.capture !== null ? 4
        : 0;
      const total=score+bonus;
      if (total>iterationBestScore) {iterationBestScore=total;iterationBest=[move];}
      else if (Math.abs(total-iterationBestScore)<0.5) iterationBest.push(move);
      alpha=Math.max(alpha,iterationBestScore);
      if (budget.nodes>=budget.maxNodes&&i<ordered.length-1) {complete=false;break;}
    }
    totalNodes+=budget.nodes;
    if (!complete) break;
    bestCompleted=iterationBest.length?iterationBest:bestCompleted;
  }
  checkerThinking = false;
  checkerApply(bestCompleted[Math.floor(Math.random() * bestCompleted.length)] ?? moves[0]);
}
function checkerAnalyzeMove():void {
  const legal=checkerLegalMoves(checkerTurn,checkerBoard,checkerChainSquare);
  if (!legal.length) {checkerHint=null;checkerNote='No legal moves are available to analyze.';render();return;}
  const depth = legal.length <= 4 ? 8 : legal.length <= 8 ? 7 : 6;
  const budget: CheckerSearchBudget = { nodes: 0, maxNodes: 80000 };
  let best:{move:CheckerMove;score:number}|null=null,alpha=-Infinity,beta=Infinity;
  for (const move of legal) {
    const result=checkerSimulateMove(checkerBoard,move,checkerTurn);
    const nextSide=result.followUp?checkerTurn:checkerTurn==='b'?'w':'b';
    const score=checkerSearch(result.board,nextSide,depth-1,alpha,beta,result.followUp?move.to:null,budget);
    if (!best||(checkerTurn==='b'?score>best.score:score<best.score)) best={move,score};
    if (checkerTurn==='b') alpha=Math.max(alpha,score); else beta=Math.min(beta,score);
    if (budget.nodes>=budget.maxNodes) break;
  }
  if (best) {
    const m=best.move,from=`${String.fromCharCode(97+m.from%8)}${8-Math.floor(m.from/8)}`,to=`${String.fromCharCode(97+m.to%8)}${8-Math.floor(m.to/8)}`;
    checkerHint={from:m.from,to:m.to,score:best.score,depth,line:`${from} ${m.capture!==null?'×':'→'} ${to}`};
    checkerNote=`Move Generator suggests ${checkerHint.line}. Search estimate only.`;
  }
  render();
}
function onCheckerSquare(index: number): void {
  if (checkerMode === 'bot' && checkerTurn === 'b') return;
  const piece = checkerBoard[index];
  const legal = checkerLegalMoves();
  if (checkerSelected !== null) {
    const chosen = legal.find(move => move.from === checkerSelected && move.to === index);
    if (chosen) { checkerApply(chosen); return; }
  }
  if (piece && piece.toLowerCase() === checkerTurn && (checkerChainSquare === null || checkerChainSquare === index)) {
    checkerSelected = index;
    const available = legal.filter(move => move.from === index);
    checkerNote = available.some(move => move.capture !== null) ? 'Capture available: jump the opponent piece.' : 'Piece selected. Choose a highlighted square.';
  } else {
    checkerSelected = checkerChainSquare;
    checkerNote = checkerChainSquare !== null ? 'Finish the combo jump with the same piece.' : 'Choose a piece of the side whose turn it is.';
  }
  render();
}
function arcadeReset(kind: 'tictactoe' | 'connect4' = activeGame as 'tictactoe' | 'connect4'): void {
  arcadeLastMove = null;
  activeGame = kind;
  arcadeBoard = Array(kind === 'tictactoe' ? 9 : 42).fill(null);
  arcadeTurn = 'X'; arcadeWinner = null;
  arcadeNote = arcadeMode === 'local' ? 'X moves first. Pass the device after your turn.' : `New game vs ${arcadeBots.find(bot => bot.id === arcadeBotId)?.name ?? 'Tactician'}. You are X.`;
}
function arcadeLines(): number[][] {
  if (activeGame === 'tictactoe') return [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const lines: number[][] = [];
  for (let r = 0; r < 6; r++) for (let c = 0; c < 7; c++) {
    const start = r * 7 + c;
    for (const [dr, dc] of [[0,1],[1,0],[1,1],[-1,1]]) {
      const endR = r + dr * 3, endC = c + dc * 3;
      if (endR >= 0 && endR < 6 && endC >= 0 && endC < 7) lines.push([0,1,2,3].map(step => (r + dr * step) * 7 + c + dc * step));
    }
  }
  return lines;
}
function arcadeWinnerFor(board: ArcadeMark[]): ArcadeMark | 'draw' | null {
  for (const line of arcadeLines()) if (board[line[0]] && line.every(index => board[index] === board[line[0]])) return board[line[0]];
  return board.every(Boolean) ? 'draw' : null;
}
function arcadeAvailableMoves(): number[] {
  if (activeGame === 'tictactoe') return arcadeBoard.flatMap((cell, index) => cell ? [] : [index]);
  return Array.from({ length: 7 }, (_, col) => col).filter(col => arcadeBoard[col] === null || arcadeBoard[7 * 5 + col] === null).filter(col => { for (let row = 0; row < 6; row++) if (!arcadeBoard[row * 7 + col]) return true; return false; });
}
function arcadeDropIndex(col: number): number {
  if (activeGame === 'tictactoe') return col;
  for (let row = 5; row >= 0; row--) if (!arcadeBoard[row * 7 + col]) return row * 7 + col;
  return -1;
}
function arcadePlay(index: number): void {
  if (arcadeWinner || !arcadeBoard[index] === false) return;
  if (activeGame === 'connect4') { const col = index % 7; index = arcadeDropIndex(col); }
  if (index < 0 || arcadeBoard[index] || (arcadeMode === 'bot' && arcadeTurn === 'O')) return;
  arcadeBoard[index] = arcadeTurn;
  arcadeLastMove = index;
  window.setTimeout(() => { if (arcadeLastMove === index) { arcadeLastMove = null; render(); } }, 460);
  arcadeWinner = arcadeWinnerFor(arcadeBoard);
  if (arcadeWinner) { arcadeNote = arcadeWinner === 'draw' ? 'Draw game. Nobody takes this round.' : `${arcadeWinner === 'X' ? 'X' : 'O'} wins!`; render(); return; }
  arcadeTurn = arcadeTurn === 'X' ? 'O' : 'X';
  arcadeNote = arcadeMode === 'local' ? `${arcadeTurn} to move. Pass the device.` : arcadeTurn === 'X' ? 'Your turn, X.' : `${arcadeBots.find(bot => bot.id === arcadeBotId)?.name ?? 'Bot'} is thinking…`;
  render();
  if (arcadeMode === 'bot' && arcadeTurn === 'O') window.setTimeout(arcadeBotMove, 240);
}
function arcadeSearch(board: ArcadeMark[], turn: ArcadeMark, depth: number, alpha: number, beta: number, budget: { nodes: number; maxNodes: number }): number {
  budget.nodes++;
  const winner = arcadeWinnerFor(board);
  if (winner === 'O') return 100000 + depth;
  if (winner === 'X') return -100000 - depth;
  if (winner === 'draw') return 0;
  if (depth <= 0 || budget.nodes >= budget.maxNodes) {
    let score = 0;
    for (const line of arcadeLines()) {
      const marks = line.map(index => board[index]);
      const own = marks.filter(mark => mark === 'O').length;
      const enemy = marks.filter(mark => mark === 'X').length;
      if (!enemy) score += [0, 2, 10, 55, 100000][own];
      if (!own) score -= [0, 2, 12, 65, 100000][enemy];
    }
    if (activeGame === 'connect4') for (let row = 0; row < 6; row++) { const mark = board[row * 7 + 3]; if (mark === 'O') score += 3; if (mark === 'X') score -= 3; }
    return score;
  }
  const moves = activeGame === 'tictactoe' ? board.flatMap((mark, index) => mark ? [] : [index]) : Array.from({ length: 7 }, (_, col) => col).filter(col => board[col] === null);
  const maximizing = turn === 'O';
  let best = maximizing ? -Infinity : Infinity;
  for (const move of moves) {
    let index = move;
    if (activeGame === 'connect4') { index = -1; for (let row = 5; row >= 0; row--) if (!board[row * 7 + move]) { index = row * 7 + move; break; } }
    if (index < 0 || board[index]) continue;
    const next = board.slice(); next[index] = turn;
    const score = arcadeSearch(next, turn === 'O' ? 'X' : 'O', depth - 1, alpha, beta, budget);
    if (maximizing) { best = Math.max(best, score); alpha = Math.max(alpha, best); }
    else { best = Math.min(best, score); beta = Math.min(beta, best); }
    if (beta <= alpha || budget.nodes >= budget.maxNodes) break;
  }
  return Number.isFinite(best) ? best : 0;
}
function arcadeBotMove(): void {
  if (!['tictactoe', 'connect4'].includes(activeGame) || arcadeMode !== 'bot' || arcadeTurn !== 'O' || arcadeWinner) return;
  const moves = arcadeAvailableMoves();
  if (!moves.length) return;
  const lines = arcadeLines();
  const chooseThreat = (mark: ArcadeMark): number | null => {
    for (const move of moves) {
      const idx = arcadeDropIndex(move);
      if (idx < 0 || arcadeBoard[idx]) continue;
      arcadeBoard[idx] = mark;
      const wins = arcadeWinnerFor(arcadeBoard) === mark;
      arcadeBoard[idx] = null;
      if (wins) return move;
    }
    return null;
  };
  if (!['rookie', 'trickster'].includes(arcadeBotId)) {
    const depth = activeGame === 'tictactoe'
      ? (arcadeBotId === 'perfect' || arcadeBotId === 'grandmaster' ? 9 : moves.length)
      : arcadeBotId === 'perfect' ? 8 : arcadeBotId === 'grandmaster' ? 7 : arcadeBotId === 'tactician' ? 5 : 4;
    const budget = { nodes: 0, maxNodes: activeGame === 'tictactoe' ? 120000 : arcadeBotId === 'perfect' ? 90000 : 40000 };
    let chosenBySearch = moves[0]; let bestScore = -Infinity; let alpha = -Infinity;
    for (const move of moves) {
      const index = activeGame === 'tictactoe' ? move : arcadeDropIndex(move);
      if (index < 0 || arcadeBoard[index]) continue;
      const next = arcadeBoard.slice(); next[index] = 'O';
      const score = arcadeSearch(next, 'X', depth - 1, alpha, Infinity, budget);
      if (score > bestScore) { bestScore = score; chosenBySearch = move; }
      alpha = Math.max(alpha, bestScore);
      if (budget.nodes >= budget.maxNodes) break;
    }
    arcadePlay(activeGame === 'connect4' ? arcadeDropIndex(chosenBySearch) : chosenBySearch);
    return;
  }
  let chosen = chooseThreat('O');
  if (chosen === null && ['tactician','guardian','raider','grandmaster'].includes(arcadeBotId)) chosen = chooseThreat('X');
  if (chosen === null && activeGame === 'tictactoe' && arcadeBotId !== 'rookie') chosen = moves.find(move => move === 4) ?? moves.find(move => [0,2,6,8].includes(move));
  if (chosen === null) {
    const scored = moves.map(move => {
      const idx = arcadeDropIndex(move);
      let score = Math.random() * (arcadeBotId === 'trickster' || arcadeBotId === 'rookie' ? 120 : 18);
      for (const line of lines) if (line.includes(idx)) { const marks = line.map(i => arcadeBoard[i]); if (!marks.includes('X')) score += marks.filter(mark => mark === 'O').length * (arcadeBotId === 'raider' ? 7 : 3); }
      return { move, score };
    }).sort((a,b) => b.score - a.score);
    chosen = scored[0]?.move ?? moves[0];
  }
  arcadePlay(arcadeDropIndex(chosen));
}
function renderArcadeGame(): void {
  const isTic = activeGame === 'tictactoe';
  const cells = arcadeBoard.map((mark, index) => `<button type="button" class="arcade-cell ${mark ? `mark-${mark.toLowerCase()}` : ''} ${mark && index === arcadeLastMove ? 'just-played' : ''}" data-arcade-cell="${index}" aria-label="${mark ?? 'Empty'} square ${index + 1}" ${mark || arcadeWinner || (arcadeMode === 'bot' && arcadeTurn === 'O') ? 'disabled' : ''}>${mark ?? ''}</button>`).join('');
  const bot = arcadeBots.find(item => item.id === arcadeBotId) ?? arcadeBots[1];
  app!.innerHTML = `<div class="home-screen checker-screen arcade-screen"><header class="home-topbar"><a href="#" class="brand" data-action="hub-home"><span class="brand-mark">🎲</span><span>${isTic ? 'TIC TAC TOE' : 'CONNECT FOUR'}</span></a><span class="offline-pill"><i></i> OFFLINE · LOCAL PLAY</span><button type="button" class="secondary-button" data-action="fullscreen">⛶ Fullscreen</button><button type="button" class="secondary-button" data-action="arcade-new">↻ New game</button></header><section class="home-hero checker-hero"><p class="eyebrow">CHEZZ BOARD GAME HUB</p><h1>${isTic ? 'Tic Tac Toe' : 'Connect Four'} <em>${arcadeMode === 'local' ? 'Co-op.' : 'Showdown.'}</em></h1><p>${isTic ? 'Three in a row wins. Fast rounds, no setup.' : 'Drop four counters into a row horizontally, vertically, or diagonally.'} Six bot personalities, plus local two-player pass-and-play.</p><div class="home-quick-actions"><button class="${arcadeMode === 'bot' ? 'primary-button' : 'secondary-button'}" data-action="arcade-bot-mode">🤖 Vs Bot</button><button class="${arcadeMode === 'local' ? 'primary-button' : 'secondary-button'}" data-action="arcade-local-mode">👥 Local 2 Player</button><select class="checker-bot-select" data-setting="arcade-bot" aria-label="Choose game bot">${arcadeBots.map(item => `<option value="${item.id}" ${arcadeBotId === item.id ? 'selected' : ''}>${item.icon} ${item.name}</option>`).join('')}</select></div></section><div class="arcade-layout"><section class="arcade-play"><div class="checker-status"><b>${arcadeWinner ? 'ROUND COMPLETE' : `${arcadeTurn} TO MOVE`}</b><span>${arcadeNote}</span></div><div class="arcade-board ${isTic ? 'tic-board' : 'connect-board'}" role="group" aria-label="${isTic ? 'Tic Tac Toe' : 'Connect Four'} board">${cells}</div><div class="checker-score"><span>✕ X: <b>${arcadeBoard.filter(mark => mark === 'X').length}</b></span><span>◯ O: <b>${arcadeBoard.filter(mark => mark === 'O').length}</b></span></div></section><aside class="checker-sidebar"><p class="eyebrow">${arcadeMode === 'local' ? 'LOCAL CO-OP' : 'BOT ROSTER'}</p><h2>${arcadeMode === 'local' ? 'Pass the device' : bot.name}</h2><p>${arcadeMode === 'local' ? 'Two people share this device. X goes first, then pass to O. No account or internet required.' : bot.style}</p>${arcadeMode === 'bot' ? arcadeBots.map(item => `<button class="checker-bot-card ${arcadeBotId === item.id ? 'selected' : ''}" data-arcade-bot="${item.id}"><span>${item.icon}</span><b>${item.name}</b><small>${item.style}</small></button>`).join('') : ''}<button class="secondary-button checker-back" data-action="hub-home">← All games</button></aside></div></div>`;
}

function renderCheckers(): void {
  const legal=checkerLegalMoves(checkerTurn,checkerBoard,checkerChainSquare);
  const targets=new Set(legal.filter(move=>move.from===checkerSelected).map(move=>move.to));
  const captureSources=new Set(legal.filter(move=>move.capture!==null).map(move=>move.from));
  const hasForcedCaptures=legal.some(move=>move.capture!==null);
  const boardToShow=checkerReplayBoard??checkerBoard;
  const squares=boardToShow.map((piece,index)=>{
    const row=Math.floor(index/8),col=index%8,playable=(row+col)%2===1;
    const label=piece?`${piece.toLowerCase()==='w'?'White':'Black'} ${piece==='W'||piece==='B'?'king':'checker'}`:'empty';
    const replayChanged=checkerReplayBoard!==null&&checkerReplayIndex>0&&checkerReplayFrames[checkerReplayIndex]?.[index]!==checkerReplayFrames[checkerReplayIndex-1]?.[index];
    const moveClass=checkerReplayBoard?(replayChanged?'current-move':''):checkerLastMove?.from===index?'previous-move':checkerLastMove?.to===index?'current-move':'';
    return `<button type="button" class="checker-square ${playable?'playable':''} ${piece?'has-piece':''} ${moveClass} ${checkerSelected===index?'chosen':''} ${checkerChainSquare===index?'forced-chain':''} ${!checkerReplayBoard&&hasForcedCaptures&&captureSources.has(index)?'capture-ready':''} ${checkerHint?.from===index?'analysis-from':''} ${checkerHint?.to===index?'analysis-to':''} ${targets.has(index)?'destination':''}" data-checker-square="${index}" aria-label="Row ${row+1}, column ${col+1}, ${label}${captureSources.has(index)?', capture available':''}">${piece?`<span class="checker-piece ${piece.toLowerCase()==='w'?'white':'black'} ${piece==='W'||piece==='B'?'king':''}" aria-hidden="true"><span class="checker-piece-inner"></span>${piece==='W'||piece==='B'?'<span class="checker-crown">♛</span>':''}</span>`:''}</button>`;
  }).join('');
  const selectedBot=checkerBots.find(bot=>bot.id===checkerBotId)??checkerBots[3];
  app!.innerHTML=`<div class="home-screen checker-screen"><header class="home-topbar"><a href="#" class="brand" data-action="hub-home"><span class="brand-mark">♟</span><span>CHEKERZ</span></a><span class="offline-pill"><i></i> OFFLINE · LOCAL PLAY</span><button type="button" class="secondary-button" data-action="fullscreen">⛶ Fullscreen</button><button type="button" class="secondary-button" data-action="checker-new">↻ New game</button></header><section class="home-hero checker-hero"><p class="eyebrow">CHEZZ BOARD GAME HUB</p><h1>Chekerz <em>${checkerMode==='local'?'Co-op.':'Showdown.'}</em></h1><p>English draughts with mandatory captures, multi-jumps, crowned kings, and <b>13 opponents</b> — including Chinook &amp; Tinsley-class engines that play like world champions.</p><div class="home-quick-actions"><button class="${checkerMode==='bot'?'primary-button':'secondary-button'}" data-action="checker-bot-mode">🤖 Vs Bot</button><button class="${checkerMode==='local'?'primary-button':'secondary-button'}" data-action="checker-local-mode">👥 Local 2 Player</button><select class="checker-bot-select" data-setting="checker-bot" aria-label="Choose checkers bot">${checkerBots.map(bot=>`<option value="${bot.id}" ${checkerBotId===bot.id?'selected':''}>${bot.icon} ${bot.name} · ${bot.tier}</option>`).join('')}</select></div></section><div class="checker-layout"><section class="checker-play"><div class="checker-status ${checkerThinking?'is-thinking':''}"><b>${checkerReplayBoard?`REPLAY · ${checkerReplayIndex}/${checkerReplayFrames.length-1}`:checkerThinking?`🧠 ${checkerBots.find(b=>b.id===checkerBotId)?.name??'BOT'} THINKING`:checkerChainSquare!==null?`COMBO JUMP · ${checkerTurn==='w'?'WHITE':'BLACK'}`:checkerTurn==='w'?'⚪ WHITE TO MOVE':'⚫ BLACK TO MOVE'}</b><span>${checkerReplayBoard?(checkerReplayPaused?'Replay paused.':'Replaying moves…'):checkerNote}</span></div><div class="checker-board" role="group" aria-label="Chekerz board">${squares}</div><div class="checker-score"><span>⚪ White: <b>${boardToShow.filter(p=>p&&p.toLowerCase()==='w').length}</b> <small>${boardToShow.filter(p=>p==='W').length}♔</small></span><span>⚫ Black: <b>${boardToShow.filter(p=>p&&p.toLowerCase()==='b').length}</b> <small>${boardToShow.filter(p=>p==='B').length}♔</small></span><span class="checker-legend"><i class="legend-dot capture-dot"></i> Capture available <i class="legend-dot move-dot"></i> Legal move</span></div>${checkerReplayBoard?`<div class="replay-controls"><button class="secondary-button" data-action="checker-replay-toggle">${checkerReplayPaused?'▶ Resume':'Ⅱ Pause'}</button><button class="secondary-button" data-action="checker-replay-exit">↩ Exit replay</button></div>`:checkerNote.includes('wins')&&checkerReplayFrames.length>1?'<div class="replay-controls"><button class="primary-button" data-action="checker-replay-start">▶ Replay Game</button></div>':''}</section><aside class="checker-sidebar"><p class="eyebrow">${checkerMode==='local'?'LOCAL CO-OP':'BOT ROSTER'}</p><h2>${checkerMode==='local'?'Pass the device':`Choose your rival · ${selectedBot.tier}`}</h2>${checkerMode==='local'?'<p>Two players share this device. White moves first, then pass the phone to Black. No account or internet required.</p>':`<div class="checker-bot-roster">${checkerBots.map(bot=>`<button class="checker-bot-card ${checkerBotId===bot.id?'selected':''}" data-checker-bot="${bot.id}"><span>${bot.icon}</span><b>${bot.name}<em>${bot.tier}</em></b><small>${bot.style}</small></button>`).join('')}</div>`}<details class="checker-rules"><summary>📘 Rules & winning tactics</summary><ul><li>Move one diagonal square forward onto an empty dark square.</li><li>Jump an adjacent opponent into an empty square beyond it. Captures are mandatory.</li><li>If another jump is available, keep using that same piece. Double, triple, and longer combos are allowed.</li><li>Reach the far edge to crown a king. Kings move and capture diagonally forward or backward.</li><li>Win by capturing every opposing piece or leaving the opponent with no legal move.</li><li><b>Tricks:</b> protect your back row, trade when ahead, lure a piece into a forced jump, and race for a king.</li><li><b>Elite bots:</b> Chinook &amp; Tinsley use deeper search, mobility scoring, and endgame tempo — expect long thinking on hard positions.</li></ul></details><button class="primary-button checker-analyze-button" data-action="checker-analyze">✨ Generate Move</button>${checkerHint?`<div class="checker-analysis-result"><b>RECOMMENDED MOVE</b><strong>${checkerHint.line}</strong><span>Depth ${checkerHint.depth} · score ${(checkerHint.score/100).toFixed(2)} (Black-positive)</span><small>Highlighted squares mark the recommendation. The board is unchanged.</small></div>`:''}<button class="secondary-button" data-action="fullscreen">⛶ Fullscreen</button><button class="secondary-button checker-back" data-action="hub-home">← All games</button></aside></div></div>`;
}
function replicatorEvaluate(): number {
  if (replicatorGame.isCheckmate()) return replicatorGame.turn() === 'w' ? -100000 : 100000;
  if (replicatorGame.isDraw()) return 0;
  let score = 0;
  const board = replicatorGame.board();
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const piece = board[r][c]; if (!piece) continue;
    const sign = piece.color === 'w' ? 1 : -1;
    const advance = piece.color === 'w' ? 7 - r : r;
    const center = 3.5 - (Math.abs(c - 3.5) + Math.abs(r - 3.5)) / 2;
    let positional = 0;
    if (piece.type === 'p') positional = advance * 7 + Math.max(0, 3 - Math.abs(c - 3.5)) * 5;
    if (piece.type === 'n') positional = center * 17;
    if (piece.type === 'b') positional = center * 10;
    if (piece.type === 'q') positional = center * 3;
    if (piece.type === 'r') positional = advance * 2;
    if (piece.type === 'k') positional = advance < 2 ? 12 : -Math.max(0, 5 - advance) * 7;
    score += sign * ((pieceValue[piece.type] ?? 0) + positional);
  }
  if (replicatorGame.isCheck()) score += replicatorGame.turn() === 'w' ? -28 : 28;
  return score;
}
function replicatorSearch(depth: number, alpha: number, beta: number, budget: { nodes: number; maxNodes: number }): { score: number; line: string[] } {
  budget.nodes++;
  if (replicatorGame.isCheckmate()) return { score: replicatorGame.turn() === 'w' ? -100000 + depth : 100000 - depth, line: [] };
  if (replicatorGame.isDraw()) return { score: 0, line: [] };
  if (depth <= 0 || budget.nodes >= budget.maxNodes) return { score: replicatorEvaluate(), line: [] };
  const maximizing = replicatorGame.turn() === 'w';
  const moves = replicatorGame.moves({ verbose: true }).sort((a, b) => {
    const priority = (m: Move) => (m.captured ? 1000 + (pieceValue[m.captured] ?? 0) : 0) + (m.promotion ? 900 : 0) + (m.san.includes('#') ? 100000 : 0) + (m.san.includes('+') ? 120 : 0);
    return priority(b) - priority(a);
  });
  let bestScore = maximizing ? -Infinity : Infinity; let bestLine: string[] = [];
  for (const move of moves) {
    replicatorGame.move(move);
    const child = replicatorSearch(depth - 1, alpha, beta, budget);
    replicatorGame.undo();
    if ((maximizing && child.score > bestScore) || (!maximizing && child.score < bestScore)) { bestScore = child.score; bestLine = [move.san, ...child.line]; }
    if (maximizing) alpha = Math.max(alpha, bestScore); else beta = Math.min(beta, bestScore);
    if (beta <= alpha || budget.nodes >= budget.maxNodes) break;
  }
  return { score: Number.isFinite(bestScore) ? bestScore : replicatorEvaluate(), line: bestLine };
}
function renderMoveReplicator(): void {
  const squares: string[] = [];
  for (let row = 0; row < 8; row++) for (let col = 0; col < 8; col++) {
    const square = `${files[col]}${8-row}` as Square;
    const piece = replicatorGame.get(square);
    const isLight = (row + col) % 2 === 0;
    const selectedHere = replicatorSelected === square;
    const suggestedFrom = replicatorSuggestion?.from === square;
    const suggestedTo = replicatorSuggestion?.to === square;
    const symbol = piece ? sculptedPiece(piece.color, piece.type, pieceDetail) : '';
    squares.push(`<button type="button" class="square ${isLight ? 'light' : 'dark'} ${selectedHere ? 'selected' : ''} ${suggestedFrom ? 'previous-move' : ''} ${suggestedTo ? 'current-move' : ''}" data-replicator-square="${square}" draggable="${Boolean(piece)}" aria-label="${piece ? `${piece.color === 'w' ? 'White' : 'Black'} ${pieceName[piece.type]}` : 'Empty'} ${square}"><span class="piece ${piece?.color === 'w' ? 'white-piece' : 'black-piece'}">${symbol}</span></button>`);
  }
  const arrow = replicatorSuggestion ? `<svg class="replicator-arrow" viewBox="0 0 800 800" aria-hidden="true"><defs><marker id="replicator-arrowhead" markerWidth="7" markerHeight="7" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#c6f277"/></marker></defs><line x1="${(files.indexOf(replicatorSuggestion.from[0])+.5)*100}" y1="${(8-Number(replicatorSuggestion.from[1])+.5)*100}" x2="${(files.indexOf(replicatorSuggestion.to[0])+.5)*100}" y2="${(8-Number(replicatorSuggestion.to[1])+.5)*100}" stroke="#c6f277" stroke-width="13" stroke-linecap="round" opacity=".92" marker-end="url(#replicator-arrowhead)"/></svg>` : '';
  app!.innerHTML = `<div class="home-screen replicator-screen ${replicatorFocusBoard ? 'replicator-board-focus' : ''}"><header class="home-topbar"><a href="#" class="brand" data-action="replicator-exit"><span class="brand-mark">♞</span><span>MOVE REPLICATOR</span></a><div class="replicator-header-actions"><button type="button" class="secondary-button" data-action="replicator-board-focus">▦ Board only</button><button type="button" class="secondary-button" data-action="fullscreen">⛶ Fullscreen</button><button type="button" class="secondary-button" data-action="replicator-exit">← Back to CHEZZ</button></div></header><section class="home-hero replicator-intro"><p class="eyebrow">PRACTICE · ANALYSIS · POST-GAME REVIEW</p><h1>Rebuild the <em>position.</em></h1><p>Enter a move sequence or edit the board manually, then generate a candidate move with a clear arrow. Use for study, review, or games where everyone agrees to analysis assistance.</p></section><div class="replicator-layout"><section class="replicator-board-wrap"><div class="replicator-board">${squares.join('')}${arrow}</div><div class="replicator-editor-tools"><label>Board tool<select data-replicator-tool aria-label="Board editing tool"><option value="move" ${replicatorTool === 'move' ? 'selected' : ''}>Move / replace piece</option><option value="place" ${replicatorTool === 'place' ? 'selected' : ''}>Place piece</option><option value="erase" ${replicatorTool === 'erase' ? 'selected' : ''}>Erase square</option></select></label><label>Piece to place<select data-replicator-piece aria-label="Piece to place">${[['wK','White King'],['wQ','White Queen'],['wR','White Rook'],['wB','White Bishop'],['wN','White Knight'],['wP','White Pawn'],['bK','Black King'],['bQ','Black Queen'],['bR','Black Rook'],['bB','Black Bishop'],['bN','Black Knight'],['bP','Black Pawn']].map(([value,label]) => `<option value="${value}" ${replicatorPiece === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label></div><div class="replicator-board-actions"><button class="secondary-button" data-action="replicator-turn">⇄ Analyze for ${replicatorSideToMove === 'w' ? 'White' : 'Black'}</button><button class="secondary-button" data-action="replicator-clear">↺ Reset position</button><button class="secondary-button" data-action="replicator-save">▣ Save position</button><button class="secondary-button" data-action="replicator-load-save">↥ Load saved position</button></div><p class="replicator-hint">Free editor: drag or tap pieces anywhere, place new pieces, or erase squares. Legal-move rules only apply when you press Generate Move.</p></section><aside class="replicator-panel"><div class="replicator-panel-card"><p class="eyebrow">MOVE REPLICATOR</p><h2>Load real moves</h2><p>Enter moves in chess notation, separated by spaces. Example: <code>e4 e5 Nf3 Nc6</code></p><textarea data-replicator-input rows="4" placeholder="e4 e5 Nf3 Nc6">${replicatorMovesInput}</textarea><button class="primary-button" data-action="replicator-load">Load move sequence</button><button class="secondary-button" data-action="replicator-generate">✨ Generate Move</button>${replicatorError ? `<div class="replicator-error" role="alert"><b>ILLEGAL POSITION</b><p>${replicatorError}</p><small>Fix the board setup, then generate again. Manual editing remains enabled.</small></div>` : ''}${replicatorSuggestion ? `<div class="replicator-result"><span class="eyebrow">SUGGESTED CANDIDATE</span><strong>${replicatorSuggestion.san}</strong><p>${replicatorSuggestion.from} → ${replicatorSuggestion.to}</p><p>${replicatorSuggestion.reason}</p><p><b>Candidate line:</b> ${replicatorSuggestion.line.join(' ') || replicatorSuggestion.san}</p><small>Evaluation: ${replicatorSuggestion.score > 0 ? '+' : ''}${(replicatorSuggestion.score/100).toFixed(2)} pawns · depth ${replicatorSuggestion.depth} · ${replicatorSuggestion.nodes.toLocaleString()} nodes searched. Still an estimate, not a guaranteed best move.</small></div>` : '<p class="replicator-hint">Your generated move and arrow will appear here.</p>'}<p class="replicator-disclaimer">This is CHEZZ’s local evaluation engine, not Stockfish or a grandmaster guarantee. For fair play, use it for practice, post-game review, or mutually agreed analysis.</p></div></aside></div></div>`;
  const board = app!.querySelector<HTMLElement>('.replicator-board');
  if (board) { const rect = board.getBoundingClientRect(); board.style.setProperty('--replicator-board-size', `${rect.width}px`); }
  app!.querySelector<HTMLElement>('.replicator-screen')?.style.setProperty('--board-focus', replicatorFocusBoard ? '1' : '0');
}

function render(): void {
  document.documentElement.dataset.theme = boardTheme;
  if (showMoveReplicator) { renderMoveReplicator(); return; }
  if (showHomeScreen) {
    app!.innerHTML = `<div class="home-screen"><header class="home-topbar"><a href="#" class="brand" data-action="dev-tap"><span class="brand-mark">♞</span><span>CHEZZ</span></a><span class="offline-pill"><i></i> LOCAL CHESS · OFFLINE</span><button type="button" class="wallet-pill" data-action="toggle-shop">🪙 ${vuzzUnlimited ? '∞' : vuzzBalance} VUZZ · SHOP</button></header><section class="home-hero"><p class="eyebrow">YOUR CHESS WORLD</p><h1>Choose your <em>opponent.</em></h1><p>Pick a challenger and jump straight into the match. No setup maze.</p><div class="home-quick-actions">${resumeAvailable ? '<button type="button" class="primary-button" data-action="resume-saved">↩ Resume saved game</button>' : ''}<button type="button" class="primary-button" data-action="home-local">♟ Local 2 Player</button><button type="button" class="secondary-button" data-action="home-challenge">🏆 Challenge Mode</button><button type="button" class="secondary-button" data-action="home-graphics">⚙ Graphics & Board</button><button type="button" class="secondary-button" data-action="history-open">📚 Match History (${matchHistory.length})</button><button type="button" class="secondary-button" data-action="replicator-open">♟ Move Replicator</button></div></section>${showColorChoice ? `<div class="color-choice-backdrop" role="dialog" aria-modal="true" aria-label="Choose your color"><section class="color-choice-card"><p class="eyebrow">NEW MATCH · ${bots.find(bot => bot.id === colorChoiceBot)?.name ?? 'BOT'}</p><h2>Choose your side</h2><p>Pick a color, or let a fair random coin toss decide.</p><div class="coin-flip ${coinFlipBusy ? 'flipping' : ''}" aria-hidden="true">${coinFlipBusy ? '🪙' : playerColor === 'w' ? '♔' : '♚'}</div><div class="color-choice-actions"><button class="primary-button" data-action="choose-white">♔ Play White</button><button class="secondary-button" data-action="choose-black">♚ Play Black</button><button class="secondary-button" data-action="choose-random" ${coinFlipBusy ? 'disabled' : ''}>🪙 Random coin flip</button></div><button class="tool-button" data-action="cancel-color-choice">Cancel</button></section></div>` : ''}${showMatchHistory ? `<div class="history-backdrop" role="dialog" aria-modal="true" aria-label="Match history"><section class="history-dialog"><div class="history-heading"><div><p class="eyebrow">YOUR LOCAL ARCHIVE</p><h2>Match History</h2><p>Completed games saved on this device.</p></div><button type="button" class="secondary-button" data-action="history-close">✕ Close</button></div>${matchHistory.length ? `<div class="history-list">${matchHistory.map(record => `<article class="history-item"><div class="history-item-copy"><b>${record.bot === 'rookie' ? 'Rookie Ray' : (bots.find(bot => bot.id === record.bot)?.name ?? record.bot)}</b><strong>${record.result}</strong><small>${new Date(record.createdAt).toLocaleString()} · ${record.moves} half-moves · ${record.mode === 'local' ? 'Local 2 Player' : 'vs bot'}</small></div><div class="history-item-actions"><button type="button" class="secondary-button" data-action="history-replay" data-history-id="${record.id}">▶ Replay</button><button type="button" class="primary-button" data-action="history-play-again" data-history-id="${record.id}">↻ Play again</button></div></article>`).join('')}</div>` : '<p class="history-empty">No completed matches yet. Finish a game and it will appear here.</p>'}</section></div>` : ''}<section class="game-hub-section"><div class="home-section-heading"><div><p class="eyebrow">BOARD GAME HUB</p><h2>More than chess</h2></div><span>4 games · 6+ bots each · local play</span></div><div class="game-hub-grid"><button class="game-hub-card" data-action="launch-chekerz"><span class="game-hub-icon">🔴</span><b>CHEKERZ</b><small>Checkers · 6 bots · Local 2 Player</small><span>Forced captures, combo jumps, king promotions and pass-and-play.</span></button><button class="game-hub-card" data-action="launch-tictactoe"><span class="game-hub-icon">✕</span><b>TIC TAC TOE</b><small>6 bots · Local 2 Player</small><span>Quick tactical rounds with instant-win and threat-blocking bot logic.</span></button><button class="game-hub-card" data-action="launch-connect4"><span class="game-hub-icon">🔵</span><b>CONNECT FOUR</b><small>6 bots · Local 2 Player</small><span>Drop counters, build four-in-a-row and block opponent threats.</span></button><button class="game-hub-card chess-hub-card" data-action="hub-chess"><span class="game-hub-icon">♞</span><b>CHEZZ CHESS</b><small>28+ bots · Local 2 Player</small><span>The full chess roster, including Mahoraga's persistent adaptation.</span></button></div></section><section class="home-bot-section"><div class="home-section-heading"><div><p class="eyebrow">LOCAL BOT ROSTER</p><h2>Pick your rival</h2></div><button type="button" class="home-browse-button" data-action="home-all-bots">${showAllHomeBots ? 'Show featured' : `Browse all ${bots.length} opponents`}</button></div><div class="home-bot-grid">${(showAllHomeBots ? bots : bots.filter(profile => ['rookie', 'human-style', 'chatgpt-style', 'grandmaster'].includes(profile.id))).map(profile => `<button type="button" class="home-bot-card ${profile.id === selectedBot ? 'selected' : ''}" data-home-bot="${profile.id}"><span class="home-bot-icon">${profile.icon}</span><span class="home-bot-copy"><b>${profile.name}</b><small>${profile.className ?? 'Strategic'} · ${profile.difficulty}</small><span>${profile.description}</span></span><span class="home-play-arrow">▶</span></button>`).join('')}<button type="button" class="home-bot-card custom-home-card" data-home-bot="custom"><span class="home-bot-icon">⚙</span><span class="home-bot-copy"><b>Custom Bot</b><small>BUILD YOUR OWN RIVAL</small><span>Adjust depth, thinking time, aggression, defense, and more.</span></span><span class="home-play-arrow">▶</span></button></div></section><footer class="home-footer">CHEZZ · LOCAL ENGINE · NO API REQUIRED FOR LOCAL BOTS</footer>${showShop ? `<div class="home-shop-note">Piece Shop is available inside a match. Start a game, then open the Vuzz shop.</div>` : ''}</div>`;
    return;
  }
  if (activeGame === 'checkers') { renderCheckers(); return; }
  if (activeGame === 'tictactoe' || activeGame === 'connect4') { renderArcadeGame(); return; }
  const squares: string[] = [];
  const flipBoard = gameMode !== 'local' && playerColor === 'b';
  const facePiecesTowardBlack = gameMode === 'local' && game.turn() === 'b';
  const inspectingOutOfTurn = gameMode === 'local' && selected !== null && game.get(selected)?.color !== game.turn();
  for (let rowIndex = 0; rowIndex < 8; rowIndex++) {
    const rank = flipBoard ? rowIndex + 1 : 8 - rowIndex;
    for (let columnIndex = 0; columnIndex < 8; columnIndex++) {
      const fileIndex = flipBoard ? 7 - columnIndex : columnIndex;
      const file = files[fileIndex];
      const square = `${file}${rank}` as Square;
      const piece = game.get(square);
      const isLight = (fileIndex + rank) % 2 === 0; // a1 is dark (standard)
      const isSelected = selected === square;
      const isTarget = targets.includes(square);
      const isLastMove = lastMove?.from === square || lastMove?.to === square;
      const isPreviousMove = lastMove?.from === square;
      const isCurrentMove = lastMove?.to === square;
      const isPreviewSquare = inspectingOutOfTurn && (isSelected || isTarget);
      const sprite = piece ? sculptedPiece(piece.color, piece.type, pieceDetail) : '';
      const label = piece
        ? `${piece.color === 'w' ? 'White' : 'Black'} ${pieceName[piece.type]} at ${square}`
        : `Empty square ${square}`;
      const impactClass = impactSquare === square ? 'capture-impact' : '';
      const movingTo = activeMoveAnimation?.to === square;
      const movingClass = '';
      const moveStyle = '';
      const attackingClass = '';
      const rankLabel = columnIndex === 0 ? `<span class="coordinate rank-coordinate">${rank}</span>` : '';
      const fileLabel = rowIndex === 7 ? `<span class="coordinate file-coordinate">${file}</span>` : '';
      const canPreviewDuringThink = thinking && ((gameMode === 'bot' && game.turn() !== playerColor) || gameMode === 'battle');
      const squareDisabled = (thinking && !canPreviewDuringThink) || animating || pendingPromotion;
      squares.push(
        `<button type="button" class="square ${isLight ? 'light' : 'dark'} ${isSelected ? 'selected' : ''} ${isPreviewSquare ? 'preview-only' : ''} ${isTarget ? 'target' : ''} ${isTarget && piece ? 'capture-target' : ''} ${isLastMove ? 'last-move' : ''} ${isPreviousMove ? 'previous-move' : ''} ${isCurrentMove ? 'current-move' : ''} ${impactClass}" data-square="${square}" aria-label="${label}" draggable="false" ${squareDisabled ? 'disabled' : ''}><span class="piece ${piece?.color === 'w' ? 'white-piece' : 'black-piece'} ${facePiecesTowardBlack ? 'piece-facing-black' : ''} ${attackingClass} ${movingClass} ${movingTo ? 'piece-hidden-for-animation' : ''}" ${moveStyle}>${sprite}</span>${isTarget && !piece ? '<span class="move-dot"></span>' : ''}${rankLabel}${fileLabel}</button>`,
      );
    }
  }

  const bot = currentBot();
  const turnText = game.isGameOver()
    ? 'GAME OVER'
    : thinking
      ? `${gameMode === 'gemini' ? 'VOX AI' : bot.name.toUpperCase()} THINKING`
      : gameMode === 'local'
        ? (game.turn() === 'w' ? 'PLAYER 1 · WHITE' : 'PLAYER 2 · BLACK')
        : game.turn() === playerColor
          ? (playerColor === 'w' ? 'YOUR TURN · WHITE' : 'YOUR TURN · BLACK')
          : (gameMode === 'gemini' ? 'VOX TURN · BLACK' : `${bot.name.toUpperCase()} · ${game.turn() === 'w' ? 'WHITE' : 'BLACK'}`);
  const checked = game.isCheck();
  const moveHistory = game.history();
  const historyCount = moveHistory.length;
  const playerWonMate = game.isCheckmate() && game.turn() !== playerColor;
  const playerLostMate = game.isCheckmate() && game.turn() === playerColor;
  const resultTitle = clockFlagged
    ? (clockFlagged === playerColor ? 'You ran out of time' : (clockFlagged === 'w' ? 'White ran out of time' : 'Black ran out of time'))
    : game.isCheckmate()
      ? (gameMode === 'local'
          ? (game.turn() === 'w' ? 'White is checkmated' : 'Black is checkmated')
          : (playerWonMate ? 'Checkmate! You win!' : 'You got checkmated'))
      : game.isDraw() ? 'Draw game' : 'Game over';
  const resultDetail = clockFlagged
    ? (clockFlagged === playerColor ? 'Time forfeited. Opponent wins on the clock.' : 'Opponent flagged. You win on time.')
    : game.isCheckmate()
      ? (gameMode === 'local'
          ? (game.turn() === 'w' ? 'Black wins this game.' : 'White wins this game.')
          : (playerWonMate ? 'You delivered checkmate. Beautiful finish.' : 'The bot found the winning move. Run it back?'))
    : game.isStalemate() ? 'Stalemate. Neither side can make a legal move.'
    : game.isThreefoldRepetition() ? 'The same position occurred three times.'
    : game.isInsufficientMaterial() ? 'There is not enough material to force checkmate.' : 'The game ended in a draw.';
  const moveRows: string[] = [];
  const preset = clockPresets.find(item => item.id === clockPreset) ?? clockPresets[3];
  const clocksEnabled = clockPreset !== 'untimed';
  const activeClock = game.turn() === 'w' ? 'w' : 'b';
  for (let index = 0; index < moveHistory.length; index += 2) {
    moveRows.push(`<div class="move-row"><span class="move-number">${Math.floor(index / 2) + 1}.</span><span class="move-white">${moveHistory[index]}</span><span class="move-black">${moveHistory[index + 1] ?? '…'}</span></div>`);
  }

  app!.innerHTML = `
    <div class="app-shell">
      <header class="topbar">
        <a class="brand" href="#" data-action="dev-tap" aria-label="CHEZZ home"><span class="brand-mark">♞</span><span>CHEZZ</span></a>
        <div class="topbar-actions"><span class="offline-pill"><i></i> ${gameMode === 'gemini' ? 'VOX AI · OFFLINE' : gameMode === 'local' ? '2 PLAYERS · OFFLINE' : gameMode === 'battle' ? 'BOT BATTLE · OFFLINE' : 'LOCAL BOTS · OFFLINE'}</span><button type="button" class="wallet-pill" data-action="toggle-shop">🪙 ${vuzzUnlimited ? '∞' : vuzzBalance} VUZZ · SHOP</button></div>
      </header>
      ${showDevConsole ? `<div class="dev-console-backdrop" role="dialog" aria-modal="true" aria-label="Developer unlock"><form class="dev-console" data-dev-form><p class="eyebrow">RESTRICTED ACCESS</p><h2>Developer Unlock</h2><p>Enter your developer code to unlock every piece set and unlimited Vuzz on this device.</p><label for="dev-code-input">Developer code</label><input id="dev-code-input" data-dev-code type="password" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Enter code" value="${devCodeInput.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}" ${devUnlockBusy ? 'disabled' : ''} /><small class="dev-code-status" role="status">${devCodeStatus}</small><div class="dev-console-actions"><button type="button" class="secondary-button" data-action="close-dev-console" ${devUnlockBusy ? 'disabled' : ''}>Cancel</button><button type="submit" class="primary-button" ${devUnlockBusy ? 'disabled' : ''}>${devUnlockBusy ? 'Checking…' : 'Unlock CHEZZ'}</button></div></form></div>` : ''}
      <main class="layout">
        <section class="play-area">
          <div class="section-heading">
            <div><p class="eyebrow">THE CLASSIC, YOUR WAY</p><h1>Make your <em>move.</em></h1></div>
            <div class="play-tools"><button type="button" class="tool-button" data-action="home-screen">⌂ Home</button><button type="button" class="tool-button fullscreen-button" data-action="fullscreen" aria-label="Toggle fullscreen">⛶ Fullscreen</button><button type="button" class="tool-button ${showMoves ? 'active' : ''}" data-action="toggle-moves" aria-expanded="${showMoves}">☷ Moves <span>${historyCount}</span></button><button type="button" class="tool-button ${showGraphics ? 'active' : ''}" data-action="toggle-graphics" aria-expanded="${showGraphics}">⚙ Graphics</button></div>
          </div>
          ${showMoves ? `<section class="tool-drawer move-drawer" aria-label="Move history"><div class="drawer-heading"><b>MOVE HISTORY</b><span>${historyCount} plies</span></div>${moveRows.length ? `<div class="move-list">${moveRows.join('')}</div>` : '<p class="empty-moves">Your moves will appear here in chess notation.</p>'}</section>` : ''}
          ${showGraphics ? `<section class="tool-drawer graphics-settings" aria-label="Graphics style settings"><div class="drawer-heading"><b>GRAPHICS STYLE</b><button type="button" class="tiny-button" data-action="reset-graphics">Reset</button></div><p class="settings-intro">Choose a color theme, piece design, and battlefield board style.</p><div class="setting-group"><label for="theme-setting">Board color theme</label><select id="theme-setting" data-setting="theme">${boardThemes.map(theme => `<option value="${theme.id}" ${boardTheme === theme.id ? 'selected' : ''}>${theme.label}</option>`).join('')}</select><small>${boardThemes.find(theme => theme.id === boardTheme)?.hint ?? ''}</small></div><div class="setting-group"><label for="piece-detail-setting">Chess piece detail</label><select id="piece-detail-setting" data-setting="pieces">${detailLevels.map(level => `<option value="${level.id}" ${pieceDetail === level.id ? 'selected' : ''}>${level.label}</option>`).join('')}</select><small>${detailLevels.find(level => level.id === pieceDetail)?.hint ?? ''}</small></div><div class="setting-group"><label for="board-detail-setting">Board detail</label><select id="board-detail-setting" data-setting="board">${detailLevels.map(level => `<option value="${level.id}" ${boardDetail === level.id ? 'selected' : ''}>${level.label}</option>`).join('')}</select><small>${boardDetail === 'simplified' ? 'Flat squares for lightweight play' : boardDetail === 'extreme' ? 'Maximum layered terrain, deep shadows, bevels and cinematic highlights' : boardDetail === 'super' ? 'Layered battlefield terrain, borders and dramatic lighting' : boardDetail === 'very' ? 'Deep forest-green terrain and field markings' : boardDetail === 'normal' ? 'Clean classic green and ivory' : 'Textured green-and-ivory battlefield'}</small></div></section>` : ''}
          <section class="clock-panel" aria-label="Chess clocks"><div class="clock-card ${activeClock === 'b' && !game.isGameOver() ? 'clock-active' : ''} ${clockFlagged === 'b' ? 'clock-flagged' : ''}"><span>♟ BLACK</span><strong>${clocksEnabled ? formatClock(blackTimeMs) : '∞'}</strong><small>${gameMode === 'local' ? 'PLAYER 2' : playerColor === 'b' ? 'YOU' : (gameMode === 'gemini' ? 'VOX' : bot.name)}</small></div><div class="clock-settings"><label for="clock-preset-setting">TIME CONTROL</label><select id="clock-preset-setting" data-setting="clock-preset">${clockPresets.map(item => `<option value="${item.id}" ${clockPreset === item.id ? 'selected' : ''}>${item.label}</option>`).join('')}</select></div><div class="clock-card ${activeClock === 'w' && !game.isGameOver() ? 'clock-active' : ''} ${clockFlagged === 'w' ? 'clock-flagged' : ''}"><span>♙ WHITE</span><strong>${clocksEnabled ? formatClock(whiteTimeMs) : '∞'}</strong><small>${gameMode === 'local' ? 'PLAYER 1' : playerColor === 'w' ? 'YOU' : (gameMode === 'gemini' ? 'VOX' : bot.name)}</small></div></section>
          <div class="board-wrap board-detail-${boardDetail} skin-${selectedPieceSkin}">
            <div class="board" role="group" aria-label="Chess board">${squares.join('')}</div>
          </div>
          ${chessReplayActive ? `<div class="replay-controls"><span>Replay ${chessReplayIndex}/${chessReplayMoves.length}</span><button class="secondary-button" data-action="chess-replay-toggle">${chessReplayPaused ? '▶ Resume' : 'Ⅱ Pause'}</button><button class="secondary-button" data-action="chess-replay-exit">↩ Exit replay</button></div>` : ''}
          <div class="move-tracker" aria-live="polite"><span class="move-tracker-icon">↗</span><span class="move-tracker-copy"><b>LAST MOVE</b><strong>${lastMove ? `${lastMove.from.toUpperCase()} → ${lastMove.to.toUpperCase()}` : 'No moves yet'}</strong></span>${queuedPremove ? `<span class="premove-pill">PREMOVE · ${queuedPremove.from.toUpperCase()} → ${queuedPremove.to.toUpperCase()}</span>` : ''}</div>
          <div class="board-footer">
            <span>${playerColor === 'b' && gameMode !== 'local' ? '♟ YOU · BLACK' : `♙ ${gameMode === 'local' ? 'PLAYER 1' : 'YOU'} · WHITE`}</span>
            <span class="turn-indicator">${turnText}</span>
            <span>${playerColor === 'b' && gameMode !== 'local' ? `♙ ${gameMode === 'gemini' ? 'GEMINI AI' : bot.name.toUpperCase()} · WHITE` : `♟ ${gameMode === 'local' ? 'PLAYER 2' : gameMode === 'gemini' ? 'GEMINI AI' : bot.name.toUpperCase()}`}</span>
          </div>
          ${pendingPromotion ? `<div class="promotion-backdrop" role="dialog" aria-modal="true" aria-label="Choose pawn promotion"><div class="promotion-dialog"><p class="eyebrow">PAWN PROMOTION</p><h2>Choose your fighter</h2><p class="promotion-copy">Your pawn reached the final rank. Pick its new chess role.</p><div class="promotion-options">${(['q', 'r', 'b', 'n'] as const).map(kind => `<button type="button" class="promotion-option" data-promotion="${kind}"><span class="promotion-sprite">${sculptedPiece('w', kind, pieceDetail)}</span><b>${({ q: 'Queen', r: 'Rook', b: 'Bishop', n: 'Knight' } as Record<string, string>)[kind]}</b></button>`).join('')}</div><button type="button" class="secondary-button" data-action="cancel-promotion">Cancel</button></div></div>` : ''}
          ${showTrainerGuide && gameMode === 'trainer' ? `<div class="trainer-guide-backdrop" role="dialog" aria-modal="true" aria-label="How to play chess"><div class="trainer-guide-dialog"><p class="eyebrow">BOT TRAINER · QUICK LESSON</p><h2>How the pieces move</h2><p class="trainer-guide-lead">Learn the moves, then practice against the coach bot. Tips appear after every move you play.</p><div class="trainer-piece-grid">
<article class="trainer-piece-card"><span class="trainer-piece-icon">♟</span><b>Pawn</b><small>Moves 1 square forward (2 from the start). Captures one square diagonally. Promotes on the last rank.</small></article>
<article class="trainer-piece-card"><span class="trainer-piece-icon">♞</span><b>Knight</b><small>Moves in an L: 2 squares one way, then 1 to the side. The only piece that jumps over others.</small></article>
<article class="trainer-piece-card"><span class="trainer-piece-icon">♝</span><b>Bishop</b><small>Any number of squares diagonally. Stays on the same color squares forever.</small></article>
<article class="trainer-piece-card"><span class="trainer-piece-icon">♜</span><b>Rook</b><small>Any number of squares horizontally or vertically. Great for open files.</small></article>
<article class="trainer-piece-card"><span class="trainer-piece-icon">♛</span><b>Queen</b><small>Combines rook + bishop power. Any direction, any distance.</small></article>
<article class="trainer-piece-card"><span class="trainer-piece-icon">♚</span><b>King</b><small>One square any direction. Protect it — checkmate ends the game. Castling: king moves 2 toward a rook.</small></article>
</div><div class="trainer-tips"><b>Remember</b><ul><li>White always moves first.</li><li>Check = your king is attacked. You must get out of check.</li><li>Checkmate = king is attacked and has no escape.</li><li>Scan checks, captures, and threats before every move.</li></ul></div><div class="trainer-guide-actions"><button type="button" class="primary-button" data-action="close-trainer-guide">Got it — start training</button></div></div></div>` : ''}
${(game.isGameOver() || clockFlagged) && !dismissedResultForCurrentGame && !chessReplayActive ? `<div class="result-backdrop" role="dialog" aria-modal="true" aria-label="Game result"><div class="result-dialog"><span class="result-mark">${game.isCheckmate() ? '♛' : '½'}</span><p class="eyebrow">GAME COMPLETE</p><h2>${resultTitle}</h2><p class="result-copy">${resultDetail}</p><div class="result-actions"><button type="button" class="primary-button" data-action="new">↻ <span>Retry / New Game</span></button><button type="button" class="secondary-button" data-action="chess-replay-start">▶ <span>Replay Game</span></button><button type="button" class="secondary-button" data-action="review-moves">☷ <span>Review Moves (${historyCount})</span></button></div></div></div>` : ''}
        </section>
        <aside class="side-panel">
          <section class="panel-card mode-card">
            <div class="panel-title"><span class="eyebrow">GAME MODE</span><span class="free-label">CHEZZ</span></div>
            <div class="mode-options">
              <button type="button" class="mode-option ${gameMode === 'bot' ? 'active' : ''}" data-mode="bot" aria-pressed="${gameMode === 'bot'}">Local Bot</button>
              <button type="button" class="mode-option ${gameMode === 'local' ? 'active' : ''}" data-mode="local" aria-pressed="${gameMode === 'local'}">2 Player</button>
              <button type="button" class="mode-option ${gameMode === 'gemini' ? 'active' : ''}" data-mode="gemini" aria-pressed="${gameMode === 'gemini'}">Vox AI</button>
              <button type="button" class="mode-option ${gameMode === 'battle' ? 'active' : ''}" data-mode="battle" aria-pressed="${gameMode === 'battle'}">Bot Battle</button>
              <button type="button" class="mode-option ${gameMode === 'lasting' ? 'active' : ''}" data-mode="lasting" aria-pressed="${gameMode === 'lasting'}">Lasting King</button>
              <button type="button" class="mode-option ${gameMode === 'trainer' ? 'active' : ''}" data-mode="trainer" aria-pressed="${gameMode === 'trainer'}">Bot Trainer</button>
            </div>
            <p class="mode-hint">${gameMode === 'local' ? 'Pass the same device between White and Black. Fully offline.' : gameMode === 'gemini' ? 'Vox runs fully offline on the CHEZZ local engine. Pick a difficulty and play with no internet.' : gameMode === 'battle' ? 'Watch two local bots play one another. Choose both sides and let the match run offline.' : gameMode === 'lasting' ? 'Survive 20 full moves against Grandmaster and keep your king safe.' : gameMode === 'trainer' ? 'Practice against a local bot and receive coaching tips after each move.' : 'Play a local chess engine with no cloud calls.'}</p>
          </section>
          ${gameMode === 'gemini' ? `<section class="panel-card gemini-card"><div class="panel-title"><span class="eyebrow">OFFLINE AI OPPONENT</span><span class="free-label">VOX · LOCAL</span></div><div class="status-box"><span class="status-icon">✦</span><div><b>Vox is ready offline</b><p>Fully local engine — no API key, no backend, no internet required. Works even when you're offline.</p></div></div><div class="setting-group"><label for="vox-level-setting">Vox difficulty</label><select id="vox-level-setting" data-setting="vox-level">${voxLevels.map(level => `<option value="${level.id}" ${voxLevel === level.id ? 'selected' : ''}>${level.label}</option>`).join('')}</select><small>${voxLevels.find(level => level.id === voxLevel)?.hint ?? ''}</small></div><button type="button" class="primary-button" data-action="new">↻ <span>New game vs Vox</span></button>${game.turn() === 'b' && !game.isGameOver() && !thinking ? '<button type="button" class="secondary-button" data-action="retry-gemini">↻ <span>Retry Vox move</span></button>' : ''}<p class="panel-footnote">Vox is powered by the CHEZZ local search engine. Higher difficulties think deeper and make fewer mistakes.</p></section>` : ''}
          ${gameMode === 'battle' ? `<section class="panel-card bot-battle-card"><div class="panel-title"><span class="eyebrow">BOT ARENA</span><span class="free-label">AUTOPLAY</span></div><div class="setting-group"><label for="battle-white-bot">White bot</label><select id="battle-white-bot" data-setting="battle-white">${bots.map(profile => `<option value="${profile.id}" ${whiteBattleBot === profile.id ? 'selected' : ''}>${profile.name}</option>`).join('')}</select></div><div class="setting-group"><label for="battle-black-bot">Black bot</label><select id="battle-black-bot" data-setting="battle-black">${bots.map(profile => `<option value="${profile.id}" ${blackBattleBot === profile.id ? 'selected' : ''}>${profile.name}</option>`).join('')}</select></div><button type="button" class="primary-button" data-action="start-battle">▶ <span>Start / Resume Bot Battle</span></button><button type="button" class="secondary-button" data-action="pause-battle">Ⅱ <span>Pause Bot Battle</span></button><p class="panel-footnote">Both bots play legal moves automatically. The match stops at checkmate, draw, or time-out.</p></section>` : ''}
          ${gameMode === 'trainer' ? `<section class="panel-card trainer-card"><div class="panel-title"><span class="eyebrow">BOT TRAINER</span><span class="free-label">COACHING</span></div><div class="status-box"><span class="status-icon">♟</span><div><b>Coach’s note</b><p>${trainerFeedback}</p></div></div><button type="button" class="secondary-button" data-action="trainer-hint">✦ <span>Get a move hint</span></button><p class="panel-footnote">Hints use legal moves and CHEZZ’s local evaluation. They are guidance, not perfect analysis.</p></section>` : ''}
          ${gameMode === 'lasting' ? `<section class="panel-card lasting-card"><div class="panel-title"><span class="eyebrow">LASTING KING</span><span class="free-label">SURVIVAL</span></div><h3>${lastingKingComplete ? 'Challenge survived!' : `Move ${Math.min(20, Math.floor(game.history().length / 2) + 1)} of 20`}</h3><p class="mode-hint">${lastingKingComplete ? 'You outlasted Grandmaster. Run it again?' : 'Survive 20 full moves against the strongest local profile.'}</p><button type="button" class="primary-button" data-action="new">↻ <span>Restart challenge</span></button></section>` : ''}
          ${gameMode === 'local' ? `<section class="panel-card"><div class="panel-title"><span class="eyebrow">LOCAL TWO-PLAYER</span><span class="free-label">OFFLINE</span></div><div class="status-box"><span class="status-icon">♟</span><div><b>${game.turn() === 'w' ? 'Player 1 · White' : 'Player 2 · Black'}</b><p>${note}</p></div></div><button type="button" class="primary-button" data-action="new">↻ <span>New two-player game</span></button><p class="panel-footnote">One board, two people, alternating turns. No internet, accounts, or servers.</p></section>` : ''}
          <section class="panel-card opponent-card">
            <div class="opponent-icon">${bot.icon}</div>
            <div class="opponent-copy"><span class="eyebrow">CURRENT OPPONENT</span><h2>${bot.name}</h2><p>${bot.style}</p></div>
            <span class="status-dot" title="Runs on this device"></span>
          </section>
          ${gameMode === 'bot' ? `<section class="panel-card bot-card">
            <div class="panel-title"><span class="eyebrow">BOT ARENA · ${bots.length - 1} OPPONENTS</span><span class="free-label">OFFLINE</span></div>
            <div class="bot-directory-controls">
              <input type="search" data-bot-search placeholder="Search bots, classes, styles…" value="${botSearch.replace(/"/g,'&quot;')}" aria-label="Search opponents"/>
              <div class="bot-class-tabs">${botClasses.map(className => `<button type="button" data-class-filter="${className}" class="${botClassFilter === className ? 'active' : ''}">${className}</button>`).join('')}</div>
              <small>${bots.filter(botMatchesFilter).length} opponents match your search</small>
            </div>
            <div class="bot-options">
              ${bots.map(profile => `
                <button type="button" data-bot="${profile.id}" data-bot-class="${profile.className ?? 'Strategic'}" data-bot-search-text="${`${profile.name} ${profile.title} ${profile.style} ${profile.className ?? ''} ${profile.difficulty}`.toLowerCase()}" class="bot-option ${selectedBot === profile.id ? 'active' : ''}" ${!botMatchesFilter(profile) ? 'hidden' : ''} ${thinking ? 'disabled' : ''} aria-pressed="${selectedBot === profile.id}">
                  <span class="bot-avatar">${profile.icon}</span>
                  <span class="bot-info"><b>${profile.name}</b><small>${profile.className ?? 'Strategic'} · ${profile.style}</small></span>
                  <span class="bot-level ${profile.difficulty.toLowerCase()}">${profile.difficulty}</span>
                </button>
              `).join('')}
            </div>
            <div class="bot-description"><b>${bot.title}</b><p>${bot.description}</p>${selectedBot === 'grandmaster' ? `<button type="button" class="secondary-button" data-action="more-thinking">${grandmasterMoreThinking ? '✓ More Thinking: 10s' : 'Enable More Thinking: 10s'}</button>` : ''}${selectedBot === 'mahoraga' ? `<div class="mahoraga-memory"><b>🎡 ADAPTATION MEMORY · ${mahoragaMemory.moves} moves observed</b><span>Center control ${adaptationPercent(mahoragaMemory.centerMoves)}% · captures ${adaptationPercent(mahoragaMemory.captures)}% · checks ${adaptationPercent(mahoragaMemory.checks)}%</span><small>Wheel phase ${mahoragaMemory.lastWheel + 1}/8 · memory stays on this device after closing CHEZZ.</small><button type="button" class="secondary-button" data-action="reset-mahoraga">Reset Adaptation Memory</button></div>` : ''}</div>
            <section class="custom-bot-settings ${selectedBot === 'custom' ? 'custom-settings-visible' : ''}" ${selectedBot === 'custom' ? '' : 'hidden'}><div class="drawer-heading"><b>CUSTOM DIFFICULTY</b><span>SAVED ON THIS DEVICE</span></div><p class="settings-intro">Tune your own offline opponent. Think time is capped at 10 seconds.</p><div class="setting-group"><label for="custom-think-setting">Thinking time: ${customBotSettings.thinkSeconds}s</label><input id="custom-think-setting" data-custom="thinkSeconds" type="range" min="1" max="10" step="1" value="${customBotSettings.thinkSeconds}"/><small>Longer thinking gives the local search more time, but does not guarantee perfect play.</small></div><div class="setting-group"><label for="custom-depth-setting">Search depth: ${customBotSettings.depth}</label><input id="custom-depth-setting" data-custom="depth" type="range" min="1" max="10" step="1" value="${customBotSettings.depth}"/></div><div class="setting-group"><label for="custom-margin-setting">Mistake tolerance: ${customBotSettings.mistakeMargin}</label><input id="custom-margin-setting" data-custom="mistakeMargin" type="range" min="0" max="800" step="10" value="${customBotSettings.mistakeMargin}"/><small>Lower means it more often chooses the top-scored move; higher allows more variety and errors.</small></div>${([{key:'aggression',label:'Aggression',hint:'Seek checks, captures, and attacking chances.'},{key:'defense',label:'Defensive caution',hint:'Value safe replies.'},{key:'positional',label:'Positional play',hint:'Favor long-term placement and structure.'},{key:'centerControl',label:'Center control',hint:'Prefer central squares.'},{key:'kingSafety',label:'King safety',hint:'Avoid unnecessary king exposure.'},{key:'development',label:'Piece development',hint:'Bring undeveloped pieces into play.'},{key:'randomness',label:'Move randomness',hint:'Higher values make choices less predictable.'}] as const).map(option => `<div class="setting-group"><label for="custom-${option.key}">${option.label}: ${customBotSettings[option.key]}</label><input id="custom-${option.key}" data-custom="${option.key}" type="range" min="0" max="100" step="5" value="${customBotSettings[option.key]}"/><small>${option.hint}</small></div>`).join('')}<button type="button" class="primary-button" data-action="save-custom">Save Custom Difficulty</button></section>
            <div class="status-box"><span class="status-icon">${checked ? '!' : '♟'}</span><div><b>${checked ? 'King in check' : game.isGameOver() ? 'Game finished' : 'Game status'}</b><p>${note}</p></div></div>
            <button type="button" class="primary-button" data-action="new">↻ <span>New game vs ${bot.name}</span></button>
            ${gameMode === 'trainer' ? '<button type="button" class="secondary-button" data-action="open-trainer-guide">📘 <span>How pieces move</span></button>' : ''}
            <button type="button" class="secondary-button" data-action="undo" ${thinking || historyCount === 0 ? 'disabled' : ''}>↶ <span>Undo last turn</span></button>
            <p class="panel-footnote">Every bot runs on this device. No account, no cloud calls. Choose a different bot any time between turns.</p>
          </section>` : ''}
          ${showShop ? `<section class="panel-card shop-card"><div class="panel-title"><span class="eyebrow">PIECE SKIN SHOP</span><span class="free-label">${vuzzUnlimited ? '∞' : vuzzBalance} VUZZ</span></div><p class="shop-intro">${vuzzUnlimited ? 'Developer mode is active on this device. All piece sets are unlocked and Vuzz spending is disabled.' : 'Win games against bots to earn Vuzz. Unlock a set once, then equip it for every mode on this device.'}</p><div class="skin-grid">${skinCatalog.map(skin => { const owned = ownedSkins.includes(skin.id); const equipped = selectedPieceSkin === skin.id; return `<article class="skin-card ${equipped ? 'equipped' : ''}"><div class="skin-preview"><span>${sculptedPiece('w','q',pieceDetail,skin.id)}</span><span>${sculptedPiece('b','n',pieceDetail,skin.id)}</span></div><div class="skin-copy"><b>${skin.name}</b><small>${skin.description}</small></div><button type="button" class="skin-action ${equipped ? 'equipped' : ''}" data-skin="${skin.id}" ${!owned && !vuzzUnlimited && vuzzBalance < skin.price ? 'disabled' : ''}>${equipped ? '✓ Equipped' : owned ? 'Equip set' : skin.price === 0 ? 'Free' : `Buy · ${skin.price} Vuzz`}</button></article>`; }).join('')}</div></section>` : ''}
          ${gameMode === 'bot' ? `<section class="panel-card feature-card"><span class="feature-icon">⌘</span><div><b>28 fixed bots + Custom</b><p>Browse Newbie through Legends classes, challenge specialized styles, and earn Vuzz for piece skins.</p></div></section>` : ''}
        </aside>
      </main>
      <footer class="footer"><span>MADE FOR THE LOVE OF THE GAME</span><span>${gameMode === 'gemini' ? 'VOX · LOCAL ENGINE · OFFLINE' : gameMode === 'local' ? 'LOCAL TWO-PLAYER · OFFLINE' : 'LOCAL ENGINE · OFFLINE'}</span></footer>
    </div>`;
}

app.addEventListener('input', event => {
  const target = event.target;
  if (!(target instanceof HTMLInputElement)) return;
  if (target.dataset.devCode !== undefined) {
    devCodeInput = target.value;
    return;
  }
  if (target.dataset.botSearch !== undefined) {
    botSearch = target.value;
    for (const button of app!.querySelectorAll<HTMLButtonElement>('[data-bot]')) {
      const classMatch = botClassFilter === 'All' || button.dataset.botClass === botClassFilter;
      const textMatch = (button.dataset.botSearchText ?? '').includes(botSearch.trim().toLowerCase());
      button.hidden = !(classMatch && textMatch);
    }
    const count = app!.querySelector<HTMLElement>('.bot-directory-controls > small');
    if (count) count.textContent = `${app!.querySelectorAll<HTMLButtonElement>('[data-bot]:not([hidden])').length} opponents match your search`;
    return;
  }
  if (!target.dataset.custom) return;
  const key = target.dataset.custom as keyof CustomBotSettings;
  const value = Number(target.value);
  if (key === 'thinkSeconds') customBotSettings.thinkSeconds = Math.max(1, Math.min(10, value));
  else if (key === 'depth') customBotSettings.depth = Math.max(1, Math.min(10, value));
  else if (key === 'mistakeMargin' || key === 'aggression' || key === 'defense' || key === 'positional' || key === 'centerControl' || key === 'kingSafety' || key === 'development' || key === 'randomness') customBotSettings[key] = Math.max(0, Math.min(key === 'mistakeMargin' ? 800 : 100, value));
  const labels: Record<string,string> = {thinkSeconds:'Thinking time',depth:'Search depth',mistakeMargin:'Mistake tolerance',aggression:'Aggression',defense:'Defensive caution',positional:'Positional play',centerControl:'Center control',kingSafety:'King safety',development:'Piece development',randomness:'Move randomness'};
  const label = target.closest('.setting-group')?.querySelector('label');
  if (label) label.textContent = `${labels[key]}: ${customBotSettings[key]}`;
});

app.addEventListener('change', event => {
  const target = event.target;
  if (!(target instanceof HTMLSelectElement)) return;
  const setting = target.dataset.setting;
  if (target.hasAttribute('data-replicator-tool')) { if (['move','place','erase'].includes(target.value)) replicatorTool = target.value as 'move' | 'place' | 'erase'; render(); return; }
  if (target.hasAttribute('data-replicator-piece')) { if (/^[wb][KQRBNP]$/.test(target.value)) replicatorPiece = target.value; render(); return; }
  if (setting === 'checker-bot') { if (checkerBots.some(bot => bot.id === target.value)) checkerBotId = target.value; render(); return; }
  if (setting === 'arcade-bot') { if (arcadeBots.some(bot => bot.id === target.value)) arcadeBotId = target.value; render(); return; }
  if (setting === 'battle-white') { const value = target.value as BotId; if (!bots.some(bot => bot.id === value)) return; whiteBattleBot = value; render(); return; }
  if (setting === 'battle-black') { const value = target.value as BotId; if (!bots.some(bot => bot.id === value)) return; blackBattleBot = value; render(); return; }
  if (setting === 'clock-preset') {
    const value = target.value as ClockPreset;
    if (!clockPresets.some(item => item.id === value)) return;
    clockPreset = value;
    try { localStorage.setItem('chezz-clock-preset', value); } catch { /* Session-only fallback. */ }
    resetClocks();
    render();
    return;
  }
  if (setting === 'theme') {
    const value = target.value as BoardTheme;
    if (!boardThemes.some(item => item.id === value)) return;
    boardTheme = value;
    try { localStorage.setItem('chezz-theme', value); } catch { /* Session-only fallback. */ }
    render();
    return;
  }
  if (setting === 'vox-level') {
    const value = target.value as VoxLevel;
    if (!voxLevels.some(level => level.id === value)) return;
    voxLevel = value;
    render();
    return;
  }
  const value = target.value as DetailLevel;
  if (!setting || !detailLevels.some(level => level.id === value)) return;
  if (setting === 'pieces') {
    pieceDetail = value;
    try { localStorage.setItem('chezz-piece-detail', value); } catch { /* Session-only fallback. */ }
  } else if (setting === 'board') {
    boardDetail = value;
    try { localStorage.setItem('chezz-board-detail', value); } catch { /* Session-only fallback. */ }
  }
  render();
});

async function toggleFullscreen(): Promise<void> {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  } catch {
    note = 'Fullscreen is not available in this browser view. Try opening CHEZZ in your browser menu.';
    const status = app?.querySelector<HTMLElement>('.status-box p');
    if (status) status.textContent = note;
  }
}

document.addEventListener('fullscreenchange', () => {
  const button = app?.querySelector<HTMLButtonElement>('[data-action="fullscreen"]');
  if (button) button.textContent = document.fullscreenElement ? '⛶ Exit fullscreen' : '⛶ Fullscreen';
});

app.addEventListener('submit', event => {
  const target = event.target;
  if (target instanceof HTMLFormElement && target.matches('[data-dev-form]')) {
    event.preventDefault();
    void unlockDeveloperMode();
  }
});

app.addEventListener('dragstart', event => {
  const target = event.target;
  if (!(target instanceof Element)) return;
  const squareButton = target.closest<HTMLButtonElement>('[data-replicator-square]');
  if (!squareButton?.dataset.replicatorSquare || !showMoveReplicator) return;
  if (!replicatorGame.get(squareButton.dataset.replicatorSquare as Square)) { event.preventDefault(); return; }
  event.dataTransfer?.setData('text/plain', squareButton.dataset.replicatorSquare);
  if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
});
app.addEventListener('dragover', event => {
  const target = event.target;
  if (target instanceof Element && target.closest('[data-replicator-square]') && showMoveReplicator) event.preventDefault();
});
app.addEventListener('drop', event => {
  const target = event.target;
  if (!(target instanceof Element) || !showMoveReplicator) return;
  const squareButton = target.closest<HTMLButtonElement>('[data-replicator-square]');
  const from = event.dataTransfer?.getData('text/plain') as Square | '';
  const to = squareButton?.dataset.replicatorSquare as Square | undefined;
  if (!from || !to || !replicatorGame.get(from)) return;
  event.preventDefault();
  const piece = replicatorGame.get(from);
  if (!piece) return;
  replicatorGame.remove(from);
  replicatorGame.remove(to);
  replicatorGame.put(piece, to);
  replicatorSelected = null;
  replicatorSuggestion = null;
  replicatorError = '';
  replicatorMovesInput = '';
  render();
});

type BoardDrag = { from: Square; startX: number; startY: number; moved: boolean; legalTargets: Square[] };
let boardDrag: BoardDrag | null = null;
function clearBoardDragMarks(): void {
  app?.querySelectorAll('.square.drag-origin, .square.drag-target, .square.drag-capture-target').forEach(square => square.classList.remove('drag-origin', 'drag-target', 'drag-capture-target'));
  app?.querySelectorAll('.move-dot.drag-dot').forEach(dot => dot.remove());
}
function cancelBoardDrag(): void { boardDrag = null; clearBoardDragMarks(); }
app.addEventListener('pointerdown', event => {
  if (!(event.target instanceof Element)) return;
  const button = event.target.closest<HTMLButtonElement>('[data-square]');
  const from = button?.dataset.square as Square | undefined;
  if (!from || button?.disabled || animating || pendingPromotion || game.isGameOver() || clockFlagged || chessReplayActive) return;
  const piece = game.get(from);
  if (!piece) return;
  if (gameMode === 'bot' && piece.color !== playerColor) return;
  const preview = thinking && ((gameMode === 'bot' && game.turn() !== playerColor) || gameMode === 'battle');
  if (thinking && !preview) return;
  if (gameMode !== 'local' && piece.color !== game.turn() && !(gameMode === 'bot' && thinking && piece.color === playerColor) && !(gameMode === 'battle' && thinking)) return;
  boardDrag = { from, startX: event.clientX, startY: event.clientY, moved: false, legalTargets: legalTargetsForPiece(from, piece.color) };
});
app.addEventListener('pointermove', event => {
  if (!boardDrag || (event.pointerType === 'mouse' && !(event.buttons & 1))) return;
  if (!boardDrag.moved && Math.hypot(event.clientX - boardDrag.startX, event.clientY - boardDrag.startY) < 9) return;
  boardDrag.moved = true;
  event.preventDefault();
  clearBoardDragMarks();
  app?.querySelector<HTMLElement>(`[data-square="${boardDrag.from}"]`)?.classList.add('drag-origin');
  for (const to of boardDrag.legalTargets) {
    const square = app?.querySelector<HTMLElement>(`[data-square="${to}"]`);
    if (!square) continue;
    square.classList.add(game.get(to) ? 'drag-capture-target' : 'drag-target');
    if (!game.get(to)) { const dot = document.createElement('span'); dot.className = 'move-dot drag-dot'; square.appendChild(dot); }
  }
});
app.addEventListener('pointerup', event => {
  if (!boardDrag) return;
  const drag = boardDrag;
  const hit = document.elementFromPoint(event.clientX, event.clientY);
  const toButton = hit instanceof Element ? hit.closest<HTMLButtonElement>('[data-square]') : null;
  const to = toButton?.dataset.square as Square | undefined;
  cancelBoardDrag();
  if (!drag.moved) return;
  event.preventDefault();
  suppressNextSquareClick = true;
  if (!to || !drag.legalTargets.includes(to)) { selected = drag.from; targets = drag.legalTargets; note = 'Drop on a highlighted legal square.'; render(); return; }
  onSquare(drag.from);
  onSquare(to);
});
app.addEventListener('pointercancel', cancelBoardDrag);
window.addEventListener('blur', cancelBoardDrag);

app.addEventListener('click', event => {
  const target = event.target;
  if (!(target instanceof Element)) return;

  // Never let anchors with app actions navigate / refresh the page
  const actionAnchor = target.closest('a[data-action], a.brand');
  if (actionAnchor instanceof HTMLAnchorElement) {
    event.preventDefault();
  }
  // Buttons inside forms / default behaviors
  const actionBtn = target.closest('button[data-action], button[data-checker-square], button[data-square], button[data-arcade-cell], button[data-home-bot], button[data-mode], button[data-checker-bot], button[data-arcade-bot], button[data-bot]');
  if (actionBtn instanceof HTMLButtonElement) {
    event.preventDefault();
  }

  const devTap = target.closest<HTMLAnchorElement>('[data-action="dev-tap"]');
  if (devTap) {
    event.preventDefault();
    const now = Date.now();
    devTapCount = now - lastDevTapAt > 2500 ? 1 : devTapCount + 1;
    lastDevTapAt = now;
    if (devTapCount >= 7) {
      devTapCount = 0;
      showDevConsole = true;
      devCodeInput = '';
      devCodeStatus = '';
      render();
      window.setTimeout(() => app?.querySelector<HTMLInputElement>('[data-dev-code]')?.focus(), 0);
    }
    return;
  }

  const replicatorSquareButton = target.closest<HTMLButtonElement>('[data-replicator-square]');
  if (replicatorSquareButton?.dataset.replicatorSquare) {
    const square = replicatorSquareButton.dataset.replicatorSquare as Square;
    replicatorError = '';
    replicatorSuggestion = null;
    replicatorMovesInput = '';
    if (replicatorTool === 'erase') {
      replicatorGame.remove(square);
      replicatorSelected = null;
    } else if (replicatorTool === 'place') {
      const color = replicatorPiece[0] as 'w' | 'b';
      const type = replicatorPiece[1].toLowerCase() as 'k' | 'q' | 'r' | 'b' | 'n' | 'p';
      replicatorGame.remove(square);
      replicatorGame.put({ color, type }, square);
      replicatorSelected = null;
    } else if (replicatorSelected) {
      const piece = replicatorGame.get(replicatorSelected);
      if (piece && replicatorSelected !== square) {
        replicatorGame.remove(replicatorSelected);
        replicatorGame.remove(square);
        replicatorGame.put(piece, square);
        replicatorSelected = null;
      } else {
        replicatorSelected = null;
      }
    } else {
      const pieceAtSquare = replicatorGame.get(square);
      if (pieceAtSquare) {
        replicatorSelected = square;
      } else {
        const color = replicatorPiece[0] as 'w' | 'b';
        const type = replicatorPiece[1].toLowerCase() as 'k' | 'q' | 'r' | 'b' | 'n' | 'p';
        replicatorGame.put({ color, type }, square);
      }
    }
    render(); return;
  }
  const checkerSquareButton = target.closest<HTMLButtonElement>('[data-checker-square]');
  if (checkerSquareButton?.dataset.checkerSquare !== undefined) { onCheckerSquare(Number(checkerSquareButton.dataset.checkerSquare)); return; }
  const checkerBotButton = target.closest<HTMLButtonElement>('[data-checker-bot]');
  if (checkerBotButton?.dataset.checkerBot) { if (checkerBots.some(bot => bot.id === checkerBotButton.dataset.checkerBot)) { checkerBotId = checkerBotButton.dataset.checkerBot; render(); } return; }
  const arcadeBotButton = target.closest<HTMLButtonElement>('[data-arcade-bot]');
  if (arcadeBotButton?.dataset.arcadeBot) { if (arcadeBots.some(bot => bot.id === arcadeBotButton.dataset.arcadeBot)) { arcadeBotId = arcadeBotButton.dataset.arcadeBot; render(); } return; }
  const arcadeCellButton = target.closest<HTMLButtonElement>('[data-arcade-cell]');
  if (arcadeCellButton?.dataset.arcadeCell !== undefined) { arcadePlay(Number(arcadeCellButton.dataset.arcadeCell)); return; }
  const homeBotButton = target.closest<HTMLButtonElement>('[data-home-bot]');
  if (homeBotButton?.dataset.homeBot && !thinking) {
    const chosen = homeBotButton.dataset.homeBot as BotId;
    if (chosen !== 'custom' && !bots.some(profile => profile.id === chosen)) return;
    colorChoiceBot = chosen; showColorChoice = true; coinFlipBusy = false; render(); return;
  }

  const squareButton = target.closest<HTMLButtonElement>('[data-square]');
  if (squareButton?.dataset.square) {
    if (suppressNextSquareClick) { suppressNextSquareClick = false; return; }
    onSquare(squareButton.dataset.square as Square);
    return;
  }

  const modeButton = target.closest<HTMLButtonElement>('[data-mode]');
  if (modeButton?.dataset.mode && ['bot', 'local', 'gemini', 'battle', 'lasting', 'trainer'].includes(modeButton.dataset.mode) && !thinking && !animating) {
    showHomeScreen = false;
    gameMode = modeButton.dataset.mode as GameMode;
    lastingKingComplete = false;
    trainerFeedback = 'Welcome to Bot Trainer. Make a move and I will explain the idea.';
    showTrainerGuide = modeButton.dataset.mode === 'trainer';
    if (gameMode === 'lasting' || gameMode === 'trainer') selectedBot = 'grandmaster';
    dismissedResultForCurrentGame = false;
    turnToken++;
    game.reset();
    matchSavedForCurrentGame = false;
    resetGameStrategy();
    resetClocks();
    vuzzAwardedForGame = false;
    selected = null;
    targets = [];
    queuedPremove = null;
    lastMove = null;
    pendingPromotion = null;
    thinking = false;
    animating = false;
    impactSquare = null;
    if (gameMode === 'local') note = 'White to move. Pass the device to Player 1.';
    else if (gameMode === 'gemini') { note = 'New game vs Vox. You play White.'; checkGeminiStatus(); }
    else if (gameMode === 'lasting') note = 'Lasting King challenge started. Survive 20 full moves.';
    else if (gameMode === 'trainer') note = trainerFeedback;
    else if (gameMode === 'battle') note = 'Bot battle running…';
    else note = playerColor === 'b' ? `Playing as Black vs ${currentBot().name}. Bot moves first.` : `Playing as White vs ${currentBot().name}. Your move.`;
    render();
    ensureBotToMove();
    return;
  }

  const classFilterButton = target.closest<HTMLButtonElement>('[data-class-filter]');
  if (classFilterButton?.dataset.classFilter) { botClassFilter = classFilterButton.dataset.classFilter; render(); return; }

  const botButton = target.closest<HTMLButtonElement>('[data-bot]');
  if (botButton?.dataset.bot && !thinking) {
    selectedBot = botButton.dataset.bot as BotId;
    note = `Opponent changed to ${currentBot().name}. Your move.`;
    render();
    return;
  }

  const promotionButton = target.closest<HTMLButtonElement>('[data-promotion]');
  if (promotionButton?.dataset.promotion && pendingPromotion) {
    const move = pendingPromotion;
    makePlayerMove(move.from, move.to, promotionButton.dataset.promotion as 'q' | 'r' | 'b' | 'n');
    return;
  }

  const skinButton = target.closest<HTMLButtonElement>('[data-skin]');
  if (skinButton?.dataset.skin) {
    const skin = skinCatalog.find(item => item.id === skinButton.dataset.skin);
    if (!skin) return;
    if (ownedSkins.includes(skin.id)) { selectedPieceSkin = skin.id; boardTheme = skinThemeMap[skin.id]; try { localStorage.setItem('chezz-theme', boardTheme); } catch { /* Session-only fallback. */ } saveEconomy(); note = `${skin.name} equipped. Matching ${boardThemes.find(theme => theme.id === boardTheme)?.label ?? 'board'} theme applied.`; }
    else if (vuzzUnlimited || vuzzBalance >= skin.price) { if (!vuzzUnlimited) vuzzBalance -= skin.price; ownedSkins.push(skin.id); selectedPieceSkin = skin.id; boardTheme = skinThemeMap[skin.id]; try { localStorage.setItem('chezz-theme', boardTheme); } catch { /* Session-only fallback. */ } saveEconomy(); note = `${skin.name} unlocked and equipped! Matching board theme applied.`; }
    else { note = `You need ${skin.price - vuzzBalance} more Vuzz for ${skin.name}. Win a game to earn more.`; }
    render(); return;
  }
  const actionButton = target.closest<HTMLButtonElement>('[data-action]');
  const action = actionButton?.dataset.action;
  if (action === 'replicator-open') { showMoveReplicator = true; replicatorGame.reset(); replicatorSelected = null; replicatorSuggestion = null; replicatorMovesInput = ''; replicatorSideToMove = 'w'; replicatorError = ''; render();
  } else if (action === 'replicator-board-focus') { replicatorFocusBoard = !replicatorFocusBoard; render();
  } else if (action === 'replicator-exit') { showMoveReplicator = false; showHomeScreen = true; render();
  } else if (action === 'replicator-clear') { replicatorGame.reset(); replicatorSelected = null; replicatorSuggestion = null; replicatorMovesInput = ''; replicatorSideToMove = 'w'; replicatorError = ''; render();
  } else if (action === 'replicator-save') { try { localStorage.setItem('chezz-replicator-position', JSON.stringify({ fen: `${replicatorGame.fen().split(' ')[0]} ${replicatorSideToMove} - - 0 1`, savedAt: new Date().toISOString() })); note = 'Position saved on this device.'; } catch { replicatorError = 'Could not save this position on the device.'; } render();
  } else if (action === 'replicator-load-save') { try { const saved = JSON.parse(localStorage.getItem('chezz-replicator-position') ?? 'null') as { fen?: string } | null; if (!saved?.fen) throw new Error('No saved position'); replicatorGame = new Chess(saved.fen); replicatorSideToMove = saved.fen.split(' ')[1] === 'b' ? 'b' : 'w'; replicatorSelected = null; replicatorSuggestion = null; replicatorError = ''; replicatorMovesInput = ''; } catch { replicatorError = 'No valid saved position was found on this device.'; } render();
  } else if (action === 'replicator-load') { const input = app!.querySelector<HTMLTextAreaElement>('[data-replicator-input]'); replicatorMovesInput = input?.value ?? ''; replicatorGame.reset(); replicatorSelected = null; replicatorSuggestion = null; try { for (const san of replicatorMovesInput.trim().split(/\\s+/).filter(Boolean)) replicatorGame.move(san); replicatorSideToMove = replicatorGame.turn(); replicatorError = ''; note = 'Move sequence loaded.'; } catch { replicatorGame.reset(); replicatorSideToMove = 'w'; replicatorError = 'The move sequence contains notation that is illegal in the current position.'; note = 'Could not load the full sequence. Check the move notation and try again.'; } render();
  } else if (action === 'replicator-turn') { replicatorSideToMove = replicatorSideToMove === 'w' ? 'b' : 'w'; replicatorSuggestion = null; replicatorError = ''; render();
  } else if (action === 'replicator-generate') { try { const placement = replicatorGame.fen().split(' ')[0]; replicatorGame = new Chess(`${placement} ${replicatorSideToMove} - - 0 1`); replicatorError = ''; } catch (error) { replicatorSuggestion = null; replicatorError = error instanceof Error ? error.message : 'This board is not a valid chess position.'; render(); return; } const side = replicatorSideToMove; const moves = replicatorGame.moves({ verbose: true }); if (!moves.length) { replicatorSuggestion = null; replicatorError = 'No legal moves are available. The position may be checkmate, stalemate, or otherwise invalid.'; render(); return; } const budget = { nodes: 0, maxNodes: 18000 }; const depth = moves.length <= 12 ? 4 : 3; let best: { from: Square; to: Square; san: string; score: number; reason: string; line: string[] } | null = null; let alpha = -Infinity, beta = Infinity; for (const move of moves) { replicatorGame.move(move); const result = replicatorSearch(depth - 1, alpha, beta, budget); replicatorGame.undo(); const reason = move.san.includes('#') ? 'Checkmate found in the searched line.' : move.san.includes('+') ? 'Forces the opponent to answer check.' : move.captured ? `Wins the opponent’s ${pieceName[move.captured]}.` : move.promotion ? 'Promotes a pawn into a stronger piece.' : move.flags.includes('k') || move.flags.includes('q') ? 'Castles to improve king safety.' : 'Selected by searching legal continuations and evaluating the resulting position.'; if (!best || (side === 'w' ? result.score > best.score : result.score < best.score)) best = { from: move.from, to: move.to, san: move.san, score: result.score, reason, line: [move.san, ...result.line] }; if (side === 'w') alpha = Math.max(alpha, result.score); else beta = Math.min(beta, result.score); if (budget.nodes >= budget.maxNodes) break; } replicatorSuggestion = best ? { ...best, depth, nodes: budget.nodes } : null; replicatorSelected = null; replicatorError = ''; render();
  } else if (action === 'checker-analyze') { checkerAnalyzeMove();
  } else if (action === 'launch-chekerz') { showHomeScreen = false; activeGame = 'checkers'; checkerMode = 'bot'; checkerResetBoard(); render();
  } else if (action === 'launch-tictactoe') { showHomeScreen = false; arcadeMode = 'bot'; arcadeReset('tictactoe'); render();
  } else if (action === 'launch-connect4') { showHomeScreen = false; arcadeMode = 'bot'; arcadeReset('connect4'); render();
  } else if (action === 'hub-chess') { activeGame = 'chess'; showHomeScreen = true; render();
  } else if (action === 'hub-home') { activeGame = 'chess'; showHomeScreen = true; render();
  } else if (action === 'checker-replay-start') { if (checkerReplayFrames.length > 1) { checkerReplayBoard = checkerReplayFrames[0].slice(); checkerReplayIndex = 0; checkerReplayPaused = false; if (checkerReplayTimer !== null) window.clearInterval(checkerReplayTimer); checkerReplayTimer = window.setInterval(() => { if (!checkerReplayPaused && checkerReplayBoard) { if (checkerReplayIndex < checkerReplayFrames.length - 1) { checkerReplayIndex++; checkerReplayBoard = checkerReplayFrames[checkerReplayIndex].slice(); render(); } else { if (checkerReplayTimer !== null) window.clearInterval(checkerReplayTimer); checkerReplayTimer = null; checkerReplayPaused = true; render(); } } }, 850); render(); }
  } else if (action === 'checker-replay-toggle') { checkerReplayPaused = !checkerReplayPaused; render();
  } else if (action === 'checker-replay-exit') { if (checkerReplayTimer !== null) window.clearInterval(checkerReplayTimer); checkerReplayTimer = null; checkerReplayBoard = null; checkerReplayPaused = false; render();
  } else if (action === 'checker-new') { checkerResetBoard(); render();
  } else if (action === 'checker-bot-mode') { checkerMode = 'bot'; checkerResetBoard(); render();
  } else if (action === 'checker-local-mode') { checkerMode = 'local'; checkerResetBoard(); render();
  } else if (action === 'arcade-new') { arcadeReset(); render();
  } else if (action === 'arcade-bot-mode') { arcadeMode = 'bot'; arcadeReset(); render();
  } else if (action === 'arcade-local-mode') { arcadeMode = 'local'; arcadeReset(); render();
  } else if (action === 'close-dev-console') {
    showDevConsole = false;
    devCodeInput = '';
    devCodeStatus = '';
    render();
  } else if (action === 'reset-mahoraga') { mahoragaMemory = blankAdaptationProfile(); saveMahoragaMemory(); note = 'Mahoraga adaptation memory reset.'; render();
  } else if (action === 'home-screen') { saveActiveGame(); showHomeScreen = true; showAllHomeBots = false; resumeAvailable = Boolean(localStorage.getItem('chezz-active-game')); render();
  } else if (action === 'resume-saved') { if (!resumeSavedGame()) { note = 'No recoverable saved game was found.'; showHomeScreen = true; render(); }
  } else if (action === 'cancel-color-choice') { showColorChoice = false; coinFlipBusy = false; render();
  } else if (action === 'choose-white' || action === 'choose-black' || action === 'choose-random') {
    const launch = () => { showColorChoice = false; showHomeScreen = false; selectedBot = colorChoiceBot; gameMode = 'bot'; showGraphics = false; showShop = false; turnToken++; game.reset(); matchSavedForCurrentGame = false; resetGameStrategy(); resetClocks(); selected = null; targets = []; lastMove = null; queuedPremove = null; pendingPromotion = null; dismissedResultForCurrentGame = false; vuzzAwardedForGame = false; thinking = false; animating = false; impactSquare = null; note = `New match vs ${currentBot().name}. You play ${playerColor === 'w' ? 'White' : 'Black'}.`; render(); ensureBotToMove(); };
    if (action === 'choose-random') { coinFlipBusy = true; render(); window.setTimeout(() => { playerColor = Math.random() < 0.5 ? 'w' : 'b'; coinFlipBusy = false; launch(); }, 1100); }
    else { playerColor = action === 'choose-white' ? 'w' : 'b'; launch(); }
  } else if (action === 'home-all-bots') { showAllHomeBots = !showAllHomeBots; render();
  } else if (action === 'home-local') { showHomeScreen = false; gameMode = 'local'; turnToken++; game.reset(); matchSavedForCurrentGame = false; resetGameStrategy(); resetClocks(); selected = null; targets = []; lastMove = null; dismissedResultForCurrentGame = false; note = 'White to move. Pass the device to Player 1.'; render();
  } else if (action === 'home-challenge') { showHomeScreen = false; gameMode = 'lasting'; selectedBot = 'rookie'; lastingKingComplete = false; turnToken++; game.reset(); matchSavedForCurrentGame = false; resetGameStrategy(); resetClocks(); selected = null; targets = []; lastMove = null; dismissedResultForCurrentGame = false; note = 'Challenge Level 1: beat Rookie to unlock the next opponent.'; render();
  } else if (action === 'home-graphics') { showHomeScreen = false; showGraphics = true; render();
  } else if (action === 'toggle-shop') { showShop = !showShop; render(); } else if (action === 'save-custom') {
    try { localStorage.setItem('chezz-custom-bot', JSON.stringify(customBotSettings)); } catch { /* Settings still apply for this session. */ }
    selectedBot = 'custom';
    note = 'Custom difficulty saved on this device. Choose Custom Bot to use it.';
    render();
  } else if (action === 'start-battle') {
    gameMode = 'battle'; turnToken++; game.reset(); matchSavedForCurrentGame = false; resetGameStrategy(); resetClocks(); lastMove = null; selected = null; targets = []; thinking = false; animating = false; impactSquare = null; dismissedResultForCurrentGame = false; note = 'Bot battle running…'; render(); window.setTimeout(computerMove, 260);
  } else if (action === 'pause-battle') {
    turnToken++; thinking = false; note = 'Bot battle paused. Press Start / Resume to continue.'; render();
  } else if (action === 'more-thinking') {
    grandmasterMoreThinking = !grandmasterMoreThinking;
    thinkingBudgets.grandmaster = grandmasterMoreThinking ? 10000 : 6500;
    searchDepthCaps.grandmaster = grandmasterMoreThinking ? 10 : 8;
    note = grandmasterMoreThinking ? 'Grandmaster More Thinking enabled: up to 10 seconds and depth cap 10.' : 'Grandmaster standard analysis enabled: up to 6.5 seconds and depth cap 8.';
    render();
  } else if (action === 'trainer-hint' && gameMode === 'trainer' && game.turn() === 'w' && !thinking && !game.isGameOver()) {
    const moves = game.moves({ verbose: true });
    const scored = moves.map(move => { const bias = styleBias(move, bots.find(profile => profile.id === 'grandmaster')!); game.move(move); const score = evaluate() + bias; game.undo(); return { move, score }; });
    scored.sort((a, b) => b.score - a.score);
    trainerFeedback = scored[0] ? `Hint: consider ${scored[0].move.san}. It scores best in CHEZZ’s quick local evaluation. Check the opponent’s forcing replies before playing it.` : 'No legal moves. The game may be over.';
    note = trainerFeedback;
    render();
  } else if (action === 'fullscreen') {
    void toggleFullscreen();
  } else if (action === 'retry-gemini' && gameMode === 'gemini' && !thinking && game.turn() === 'b') {
    void requestGeminiMove();
  } else if (action === 'chess-replay-start') {
    if (game.isGameOver() || clockFlagged) beginChessReplay(game.history());
  } else if (action === 'chess-replay-toggle') { chessReplayPaused = !chessReplayPaused; render();
  } else if (action === 'chess-replay-exit') { if (chessReplayTimer !== null) window.clearInterval(chessReplayTimer); chessReplayTimer = null; chessReplayActive = false; chessReplayPaused = false; game.reset(); lastMove = null; dismissedResultForCurrentGame = false; note = 'Replay closed. Start a new game to play again.'; render();
  } else if (action === 'history-open') { showMatchHistory = true; render();
  } else if (action === 'history-close') { showMatchHistory = false; render();
  } else if (action === 'history-replay') {
    const record = matchHistory.find(item => item.id === actionButton?.dataset.historyId);
    if (record) { try { const replaySource = new Chess(); replaySource.loadPgn(record.pgn); showMatchHistory = false; showHomeScreen = false; activeGame = 'chess'; beginChessReplay(replaySource.history()); } catch { note = 'This saved replay could not be loaded.'; render(); } }
  } else if (action === 'history-play-again') {
    const record = matchHistory.find(item => item.id === actionButton?.dataset.historyId);
    if (record) { const botId = bots.some(bot => bot.id === record.bot) ? record.bot as BotId : selectedBot; selectedBot = botId; playerColor = record.playerColor; gameMode = 'bot'; showMatchHistory = false; showHomeScreen = false; activeGame = 'chess'; chessReplayActive = false; if (chessReplayTimer !== null) window.clearInterval(chessReplayTimer); chessReplayTimer = null; matchSavedForCurrentGame = false; turnToken++; game.reset(); resetGameStrategy(); resetClocks(); selected = null; targets = []; lastMove = null; queuedPremove = null; pendingPromotion = null; thinking = false; animating = false; dismissedResultForCurrentGame = false; vuzzAwardedForGame = false; note = `Rematch vs ${currentBot().name}. You play ${playerColor === 'w' ? 'White' : 'Black'}.`; render(); ensureBotToMove(); }
  } else if (action === 'review-moves') {
    dismissedResultForCurrentGame = true;
    showMoves = true;
    render();
  } else if (action === 'toggle-moves') {
    showMoves = !showMoves;
    render();
  } else if (action === 'toggle-graphics') {
    showGraphics = !showGraphics;
    render();
  } else if (action === 'reset-graphics') {
    pieceDetail = 'detailed';
    boardDetail = 'detailed';
    boardTheme = 'forest';
    try { localStorage.removeItem('chezz-piece-detail'); localStorage.removeItem('chezz-board-detail'); localStorage.setItem('chezz-theme', 'forest'); } catch { /* Settings still reset for this session. */ }
    render();
  } else if (action === 'cancel-promotion') {
    pendingPromotion = null;
    note = 'Promotion cancelled. Choose another move.';
    render();
  } else if (action === 'new') {
    try { localStorage.removeItem('chezz-active-game'); } catch { /* Ignore unavailable storage. */ }
    resumeAvailable = false;
    showHomeScreen = false;
    dismissedResultForCurrentGame = false;
    turnToken++;
    game.reset();
    matchSavedForCurrentGame = false;
    resetGameStrategy();
    resetClocks();
    selected = null;
    targets = [];
    lastMove = null;
    queuedPremove = null;
    thinking = false;
    animating = false;
    impactSquare = null;
    pendingPromotion = null;
    if (gameMode === 'local') note = 'White to move. Pass the device to Player 1.';
    else if (gameMode === 'gemini') { note = 'New game vs Vox. You play White.'; checkGeminiStatus(); }
    else if (gameMode === 'lasting') note = 'Lasting King challenge started. Survive 20 full moves.';
    else if (gameMode === 'trainer') note = trainerFeedback;
    else if (gameMode === 'battle') note = 'Bot battle running…';
    else note = playerColor === 'b' ? `New match vs ${currentBot().name}. Bot (White) moves first.` : `New match vs ${currentBot().name}. Your move — White starts.`;
    render();
    ensureBotToMove();
  } else if (action === 'undo' && !thinking && !animating && !pendingPromotion && game.history().length > 0) {
    turnToken++;
    // Undo a full ply pair in vs-bot modes so the player always gets their turn back.
    if (gameMode === 'bot' || gameMode === 'gemini' || gameMode === 'trainer' || gameMode === 'lasting') {
      const before = game.history().length;
      game.undo();
      // If it is still the opponent's turn (or we only removed our half), undo once more when possible.
      if (game.history().length > 0 && game.turn() !== playerColor) game.undo();
      // If still not player's turn (e.g. undid into bot-to-move), leave it — ensureBot will reply.
    } else {
      game.undo();
    }
    selected = null;
    targets = [];
    queuedPremove = null;
    const history = game.history({ verbose: true });
    const previous = history[history.length - 1];
    lastMove = previous ? { from: previous.from, to: previous.to } : null;
    note = 'Last turn undone.';
    thinking = false;
    render();
    ensureBotToMove();
  }
});

window.setInterval(() => {
  if (!showHomeScreen && !showMoveReplicator && !game.isGameOver()) saveActiveGame();
  if (clockPreset === 'untimed' || game.isGameOver() || clockFlagged) return;
  syncClock();
  if (clockFlagged) {
    note = clockFlagged === 'w' ? 'White ran out of time. Black wins on time.' : 'Black ran out of time. White wins on time.';
    finishGame();
    render();
    return;
  }
  updateClockDisplay();
}, 1000);

window.addEventListener('pagehide', saveActiveGame);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveActiveGame(); });
checkerResetBoard();
render();
void checkGeminiStatus();

if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => undefined);
  });
}
